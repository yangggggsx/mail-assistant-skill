# Deploy a new instance

This is a single-owner self-hosted service. Use separate resources for each owner. Existing deployments should be inspected and backed up instead of initialized again. The source includes compatibility endpoints for a former Mac implementation; a fresh deployment needs no Mac worker.

## Prerequisites and settings

- Node.js 24, npm, Python 3, Cloudflare access and Wrangler. Use an available Wrangler version; the original build was validated with Wrangler 4.152.0.
- Cloudflare Workers, D1, two Queues, and Images capability for HEIC conversion. Availability, plan requirements and current costs must be checked with the provider before provisioning; this package does not promise a free tier.
- An OpenAI API project and an available model supporting the structured-output, PDF/image-input and streaming requests used by this source. `MAIL_AI_MODEL` is configurable; this package does not silently substitute models or claim every model works.
- Pushover application token and user key for notifications.
- Microsoft app registration for Outlook mail/calendar and/or Google OAuth client for Gmail. Calendar uses one explicitly configured Outlook account, even when several inboxes are connected.

Copy `assets/deployment.example.json` to a private `deployment.local.json` and fill it. It contains **no secrets**: Worker origin/name, calendar account, D1 resource identifiers, queue names, model and optional Gmail push resources. The example origin and zero database ID are intentionally rejected by the generator.

Create distinct D1 and queue resources using the Cloudflare account authorized by the user. Record the actual database ID. Then:

```sh
python3 scripts/configure.py --config /absolute/path/deployment.local.json --output /absolute/path/new-mail-assistant
cd /absolute/path/new-mail-assistant
npm ci
npm test
wrangler deploy --dry-run
```

The output directory must not already exist. The generator never updates the installed skill or an existing production checkout. It writes the origin and intended account into `src/deployment-config.js` and generates `wrangler.toml` with the queues, D1, Images and a five-minute cron. Treat the generated checkout as private if it contains personal settings.

## Secrets and initial deployment

Use `wrangler secret put NAME` interactively, or an authorized secret manager supplying stdin without logging values. Names:

| Secret | Used for |
|---|---|
| `API_TOKEN` | Random administrator bearer token and signed action proofs |
| `TOKEN_ENCRYPTION_KEY` | Random 32-byte base64url key for encrypted OAuth refresh tokens |
| `OPENAI_API_KEY` | Classification, translation, event extraction |
| `PUSHOVER_API_TOKEN`, `PUSHOVER_USER_KEY` | Notification delivery |
| `GOOGLE_CLIENT_ID`, `GOOGLE_CLIENT_SECRET` | Gmail OAuth, if used |
| `MICROSOFT_CLIENT_ID`, `MICROSOFT_CLIENT_SECRET` | Outlook OAuth, if used |

Keep encryption keys stable for existing deployments; changing the key without migrating tokens breaks mailbox access. Initialize the base D1 schema with `wrangler d1 execute <database-name> --remote --file schema.sql`, then deploy using `wrangler deploy`. Module-specific schemas initialize through their existing setup paths. Deployment and resource creation require the user's authorized account/scope.

## OAuth and startup

Administrator API requests use `Authorization: Bearer <API_TOKEN>`; never put this token in browser URLs or screenshots. For HTTP calls, use a tool that supplies the header without printing secrets. OAuth consent itself is completed by the user.

1. Configure provider web redirect URIs to exactly `<origin>/oauth/google/callback` and/or `<origin>/oauth/microsoft/callback`. Inspect `cloud-mail.js` scopes; calendar separately requests `Calendars.ReadWrite` and `User.Read` via `outlook-calendar-auth.js`.
2. POST `/api/oauth/google/start` or `/api/oauth/microsoft/start`; open the returned authorization URL for the user. Read GET `/api/cloud/accounts` and POST `/api/cloud/sync` to check sync before activation. Initial connections are in shadow mode.
3. When old senders/scanners are stopped (or absent in a fresh install), POST `/api/delivery/handoff` with `{"owner":"cloud","confirm_mac_sender_stopped":true}`. The legacy flag means no competing sender; do not assert it for an unknown existing installation.
4. POST `/api/cloud/pipeline/activate` with `confirm_mac_inboxes_stopped:true` and a current ISO-8601 `cutover`. This enables real classification and notifications. Check healthy account status first. The timestamp must be within an hour of server time; never use a fixed example date.
5. Optional Outlook JunkEmail review: POST `/api/cloud/pipeline/junk/activate` with `confirm_outlook_mac_junk_stopped:true` and a current `cutover`. Do not describe this as universal spam-folder coverage for all providers.
6. POST `/api/cloud/realtime/enable` to enable subscriptions; GET its `/status` endpoint. Microsoft Graph validates callbacks at `<origin>/hooks/microsoft`. Gmail push requires a Pub/Sub topic with the Gmail publisher authorized, an authenticated push subscription aimed at `<origin>/hooks/google`, exact matching JWT audience, and the configured service-account identity. Consult current official Google setup requirements when provisioning. If Gmail push is omitted, periodic sync remains the fallback.
7. For calendar: POST `/api/calendar/connect`, let the user authorize the configured calendar account, then POST `/api/calendar/setup` with `{"confirm":true}`. This creates/binds the dedicated calendar. Verify GET `/api/calendar/status` before enabling user flows.
8. POST `/api/schedules/access-link` to obtain an expiring upload capability URL. Keep it private. File uploads do not need the administrator token; callers possessing that URL can submit files.

Fresh instances have no historical delivery receipts. Migrating an existing service requires reviewing the handoff/import endpoints in `cloud-migration.js`, `delivery-queue.js` and `calendar-migration.js`; never reset old task state just to make startup succeed.

## Acceptance checks

- `/health` returns `ok:true`; unauthenticated administrator requests return 401.
- Provider/account status has no unresolved error; inspect pipeline, delivery and realtime status.
- Only if authorized, send one controlled test through `/api/delivery/test` with a stable unique `test_id`; do not change the ID and retry an uncertain delivery.
- Test a user-provided PDF or HEIC, edit the preview, confirm one event, then verify it through Graph and the user's calendar. Tests in the package use mocked services and do not replace this check.
- Configure/test the iPhone shortcut separately. The skill cannot install it on the user's phone merely by being installed on a computer.
