// Safe template values. Regenerate with the skill's configure.py before deployment.
export const ORIGIN = 'https://mail-assistant.example.com';
export const CALENDAR_ACCOUNT = 'calendar@example.com';
