// Presentation only: never controls routing, priority, or whether a mail is sent.
export const notificationInstructions=`
额外生成 notification 推送展示，不改变原有分类、重要性、路由或是否推送的判断。
label 选最具体的邮件类别；退款进展使用退款售后，纯订单/付款使用订单交易，课程成绩与课程通知区分。仅用于展示。
财务消费：银行账户、信用卡、余额/利息、消费汇总、积分返现、已获得的会员等级或消费权益变动（例如已升级 Preferred Plus tier）。明确待缴账单仍用账单缴费，具体订单/支付凭证用订单交易，退款进展用退款售后；泛化优惠、办卡招揽、促销仍用推广营销，异常交易/盗刷风险仍用账户安全。类别不决定重要程度；无行动、无明确风险的会员升级通知通常普通，不因涉及金钱自动判紧急。
title：简短中文标题，尽量 12–30 字，保留 Quiz#4、商家、金额等辨识信息，不照抄长商品名，不加类别前缀或重要程度。
lead：一句简洁中文，先说最关键的结果或邮件明确要求的行动，最多 80 字。不要写“摘要”“建议”标签，不重复堆叠标题。
details：0–3 条必要事实，每条最多 50 字，例如课程、地点、金额、取件码、明确期限；不重复 lead，没有就空数组。
source：发件机构或姓名，最多 24 字；不确定用空字符串。不能包含邮箱地址。
所有字段仅依据邮件事实，不编造分数、截止时间、取件码或行动。退款已发起不等于到账，运输中不等于可取件；没有必要行动不硬加建议。不包含收件邮箱、长订单号、网址、HTML 或 Markdown。`;

export const notificationSchema={type:'object',additionalProperties:false,properties:{
  label:{type:'string',enum:['快递物流','订单交易','退款售后','账单缴费','财务消费','课程成绩','课程通知','日程会议','申请进展','账户安全','验证码','验证成功','确认回执','截止提醒','需要回复','待处理事项','一般通知','订阅资讯','推广营销','垃圾邮件','其他']},
  title:{type:'string'},lead:{type:'string'},details:{type:'array',items:{type:'string'},maxItems:3},source:{type:'string'}
},required:['label','title','lead','details','source']};

const labels={shipping:'快递物流',transaction:'订单交易',billing_notice:'账单缴费',academic_result:'课程成绩',calendar_event:'日程会议',security_alert:'账户安全',verification_code:'验证码',verification_success:'验证成功',newsletter:'订阅资讯',marketing:'推广营销',spam:'垃圾邮件',application_update:'申请进展',receipt_confirmation:'确认回执',deadline:'截止提醒',needs_reply:'需要回复',action_request:'待处理事项',routine_notice:'一般通知',other:'其他'};
const clean=(v,n)=>Array.from(typeof v==='string'?v.replace(/https?:\/\/\S+/gi,'').replace(/[^\s<>]+@[^\s<>]+/g,'').replace(/[\u0000-\u001f\u007f]/g,' ').replace(/\s+/g,' ').trim():'').slice(0,n).join('');
export function notificationContent(mail,c){
  const n=c.notification||{};
  const label=notificationSchema.properties.label.enum.includes(n.label)?n.label:labels[c.mail_type]||'其他';
  const name=String(mail.sender||'').replace(/\s*<[^>]*@[^>]*>\s*/g,'').replace(/^"|"$/g,'');
  const domain=String(mail.sender||'').match(/@([a-z0-9.-]+)/i)?.[1]||'';
  return {label,title:clean(n.title,60)||clean(mail.subject,100)||'邮件通知',
    lead:clean(n.lead,160)||clean(c.summary,240)||'请查看原邮件了解详情。',
    details:(Array.isArray(n.details)?n.details:[]).map(x=>clean(x,70)).filter(Boolean).slice(0,3),
    source:clean(n.source,32)||clean(name,40)||domain||'未知发件人'};
}
