#!/usr/bin/env python3
"""Package an explicitly selected commit; never include untracked local data."""
import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parents[1]
ROOT_FILES = {'.gitignore', 'README.md', 'VALIDATION.md', 'RELEASE_READINESS.md',
              'SOURCE_IMPORT.md', 'SECURITY.md', 'LICENSE'}


def git(*args):
    return subprocess.check_output(['git', '-C', str(ROOT), *args])


def build(ref, output):
    commit = git('rev-parse', '--verify', ref + '^{commit}').decode().strip()
    entries = git('ls-tree', '-rz', '--full-tree', commit).split(b'\0')
    files = []
    for entry in filter(None, entries):
        meta, raw_path = entry.split(b'\t', 1)
        mode, kind, oid = meta.decode().split()
        path = raw_path.decode('utf-8')
        parts = PurePosixPath(path).parts
        if mode not in ('100644', '100755') or kind != 'blob':
            raise ValueError('Unsupported entry (symlink/submodule): ' + path)
        allowed = (path in ROOT_FILES or path.startswith('skills/mail-assistant/')
                   or path == 'tools/package_release.py')
        forbidden = any(p in ('node_modules', '.git', '.wrangler', '__pycache__', 'backups')
                        or p.startswith(('.env', '.dev.vars')) for p in parts)
        forbidden |= path.endswith(('.log', '.sqlite', '.sqlite3', '.db', '.zip', '.pyc'))
        forbidden |= parts[-1] in ('deployment.local.json', 'wrangler.toml')
        if not allowed or forbidden:
            raise ValueError('File outside publication allowlist: ' + path)
        files.append((path, mode, oid))
    required = {'README.md', 'skills/mail-assistant/SKILL.md',
                'skills/mail-assistant/assets/worker/package-lock.json'}
    if not required.issubset({path for path, _, _ in files}):
        raise ValueError('Required source files are missing')
    # Build from Git objects, not working files. This is a packaging allowlist,
    # not a credential/content scanner or a replacement for security review.
    output = Path(output).resolve()
    if output.exists():
        raise ValueError('Destination already exists; refusing to overwrite')
    output.mkdir(parents=True)
    archive = output / 'mail-assistant-skill.zip'
    manifest = {}
    with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for path, mode, oid in sorted(files):
            data = git('cat-file', 'blob', oid)
            info = zipfile.ZipInfo('mail-assistant-skill/' + path, (1980, 1, 1, 0, 0, 0))
            info.create_system = 3
            info.external_attr = (int(mode, 8) << 16)
            info.compress_type = zipfile.ZIP_DEFLATED
            z.writestr(info, data)
            manifest[path] = hashlib.sha256(data).hexdigest()
    digest = hashlib.sha256(archive.read_bytes()).hexdigest()
    (output / 'SHA256SUMS').write_text(digest + '  mail-assistant-skill.zip\n')
    (output / 'source-manifest.json').write_text(json.dumps(
        {'source_commit': commit, 'zip_sha256': digest, 'files': manifest},
        indent=2, sort_keys=True) + '\n')
    return commit, digest


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--ref', required=True, help='Reviewed commit or tag (not working tree)')
    p.add_argument('--output', required=True, help='New output directory')
    a = p.parse_args()
    try:
        commit, digest = build(a.ref, a.output)
    except (ValueError, OSError, subprocess.CalledProcessError) as e:
        p.exit(1, str(e) + '\n')
    print('Source commit: ' + commit + '\nZIP SHA-256: ' + digest)
