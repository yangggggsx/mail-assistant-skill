import test from 'node:test';
import assert from 'node:assert/strict';
import {toolPage,handleMailTools} from './mail-tools.js';
test('copy page escapes untrusted email and protects clipboard action',async()=>{
  const r=toolPage('A'.repeat(32),'copy',{status:'completed',result:'</textarea><script>alert(1)</script>'});
  const body=await r.text();
  assert.ok(body.includes('&lt;/textarea&gt;'));
  assert.ok(!body.includes('<script>alert(1)'));
  assert.match(r.headers.get('content-security-policy'),/frame-ancestors 'none'/);
  assert.equal(r.headers.get('cache-control'),'no-store');
});
test('API cannot be read without secret',async()=>{
  const url=new URL('https://example.test/api/mail-tools/pull');
  const r=await handleMailTools(new Request(url),{},url,false);
  assert.equal(r.status,401);
});
test('GET is read-only, cross-site submission blocked',async()=>{
  const statements=[];
  const env={API_TOKEN:'test-secret-only',DB:{prepare(sql){statements.push(sql);return {run:async()=>({}),bind(){return this},first:async()=>sql.includes('feedback_links')?{message_key:'a'.repeat(64),expires_at:'2099-01-01'}:null};}}};
  const url=new URL('https://example.test/f/'+'A'.repeat(32)+'/todo');
  assert.equal((await handleMailTools(new Request(url),env,url,false)).status,200);
  assert.ok(!statements.some(s=>s.includes('INSERT')));
  assert.equal((await handleMailTools(new Request(url,{method:'POST',headers:{origin:'https://evil.test'}}),env,url,false)).status,403);
  for (const kind of ['copy','todo']) {
    const action=new URL(url); action.pathname=action.pathname.replace(/todo$/,kind);
    const page=await (await handleMailTools(new Request(action),env,action,false)).text();
    const expires=page.match(/name="expires" value="([^"]+)"/)[1];
    const proof=page.match(/name="proof" value="([^"]+)"/)[1];
    const submit=(origin,signature=proof,expiry=expires,site='same-origin')=>handleMailTools(new Request(action,{method:'POST',headers:{origin,'sec-fetch-site':site},body:new URLSearchParams({expires:expiry,proof:signature})}),env,action,false);
    assert.equal((await submit('null')).status,303);
    assert.equal((await submit(action.origin)).status,303);
    assert.equal((await submit('null','invalid')).status,403);
    assert.equal((await submit('null',proof,'1000000000')).status,403);
    assert.equal((await submit('https://evil.test')).status,403);
    assert.equal((await submit('null',proof,expires,'cross-site')).status,403);
  }
});
test('single-click pages omit duplicate navigation and auto-start only fresh tasks',async()=>{
  for(const kind of ['copy','todo']) {
    const fresh=await toolPage('A'.repeat(32),kind,null,{expires:'1234567890',signature:'proof'}).text();
    assert.ok(fresh.includes('requestSubmit()'));
    assert.ok(!fresh.includes('<nav>'));
    assert.ok(!fresh.includes('刷新状态'));
    assert.ok(!fresh.includes('确认加入待办'));
    assert.ok(fresh.includes('max-width:480px'));
    const pending=await toolPage('A'.repeat(32),kind,{status:'pending'}).text();
    assert.ok(pending.includes('location.replace(location.pathname)'));
    assert.ok(!pending.includes('requestSubmit()'));
    const failed=await toolPage('A'.repeat(32),kind,{status:'failed',error:'failed'}).text();
    assert.ok(failed.includes('<button>重试</button>'));
    assert.ok(!failed.includes('requestSubmit()'));
    const completed=await toolPage('A'.repeat(32),kind,{status:'completed',result:'text'}).text();
    assert.ok(!completed.includes('location.replace'));
  }
});
