import test from 'node:test';
import assert from 'node:assert/strict';
import {prepareCourseImage} from './course-images.js';
import {scheduleTestHelpers} from './schedules.js';
const heic={filename:'iPhone.HEIC',content_type:'image/heic',bytes:new Uint8Array([1,2]).buffer};
test('HEIC privately converts to bounded JPEG before model input',async()=>{
 let input,transform,output;
 const env={IMAGES:{input(stream){input=stream;return {transform(options){transform=options;return this;},async output(options){output=options;return {response:()=>new Response(new Uint8Array([255,216,255,1]),{headers:{'content-type':'image/jpeg'}})};}};}}};
 const result=await prepareCourseImage(env,heic);
 assert.equal(result.filename,'iPhone.jpg');assert.equal(result.content_type,'image/jpeg');
 assert.deepEqual([...new Uint8Array(await new Response(input).arrayBuffer())],[1,2]);
 assert.deepEqual(transform,{width:4096,height:4096,fit:'scale-down'});assert.equal(output.quality,95);
 assert.equal(heic.content_type,'image/heic');
});
test('normal formats bypass decoder; missing binding and bad bytes fail closed',async()=>{
 const png={...heic,content_type:'image/png'};assert.equal(await prepareCourseImage({},png),png);
 await assert.rejects(prepareCourseImage({},heic),/暂不可用/);
 const env={IMAGES:{input(){return {transform(){return this;},output:async()=>({response:()=>new Response('not JPEG')})};}}};
 await assert.rejects(prepareCourseImage(env,heic),/解码失败/);
});
test('HEIC detection relies on bytes not filename or MIME',()=>{
 const b=new Uint8Array([0,0,0,24,...new TextEncoder().encode('ftypheic'),0,0,0,0,...new TextEncoder().encode('mif1heic')]);
 assert.equal(scheduleTestHelpers.detectInputType(b),'image/heic');
 assert.equal(scheduleTestHelpers.detectInputType(new TextEncoder().encode('photo.heic')),null);
});
