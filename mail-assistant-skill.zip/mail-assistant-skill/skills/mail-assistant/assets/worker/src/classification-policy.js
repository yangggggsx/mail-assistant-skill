// Priority, message purpose and delivery are independent. Keep old category values
// so existing feedback links and Mac downstream consumers remain compatible.
export const policyInstructions=`补充用户最新偏好（优先于旧偏好）：
重要性分为 urgent（有明确迫近风险/时限）、important（成绩、申请结果、账务或实质权益）、normal（一般待办或信息）、low（无行动低价值信息）。不能因为发件人为学校或官方就判重要，也不能把所有含 verification 的邮件判验证码。
mail_type 新增 verification_success（仅验证成功、账号已可用，无后续动作）、academic_result（成绩或学业结果）、application_update（申请状态）、billing_notice（账单付款）、action_request（需执行事项）、routine_notice（一般通知）。纯验证成功回执必须 low、normal、action_required=false、suppress。验证码 verification_code 同样 suppress。付款成功、申请回执和一般确认回执不能据此一概静默。
真正异常登录、安全设置修改和失败验证风险归 security_alert；普通验证码中的“如果不是本人请求请忽略”模板不等于发现安全异常。仅含验证链接且需要点击的邮件不是 verification_success，按 action_request 处理。
邮件类别与紧急程度独立判断。shipping（快递物流）用于包裹发货、运输、派送、送达、取件及投递异常；不能只因发件人是购物平台就使用 shipping，促销仍为 marketing，单纯下单/付款凭证仍为 transaction。正常物流更新通常 normal、action_required=false；明确需取件、补充地址、联系承运商则 action_required=true，根据实际截止时间和不处理的后果判断 normal/important/urgent，不能因“今天送达”就判紧急。限时取件、有退回风险可为 important；迫近且有明确后果的截止才为 urgent。退款退货如果主要是款项进展归 transaction，如果主要是退货包裹运输归 shipping。摘要保留明确的预计到达/取件期限，不编造时间；取件码不是登录验证码，不得按 verification_code 静默。
普通邮件仍即时推送供用户确认；订阅营销及垃圾进入简报。不得仅因 importance=low 或推荐 suppress 就隐藏其他类型邮件。`;
export function securityAnomaly(mail){
 return /(?:unusual|suspicious|unrecognized|unauthori[sz]ed|compromised).{0,60}(?:login|sign[ -]?in|activity|account)|(?:password|security settings?|recovery (?:email|phone)).{0,35}(?:changed|updated)|(?:异常|可疑|未经授权).{0,40}(?:登录|活动|操作)|(?:密码|安全设置).{0,20}(?:修改|更改)/is.test((mail.subject||'')+'\n'+(mail.body||''));
}
export function otpOnly(mail){
 if(securityAnomaly(mail))return false;
 const text=((mail.subject||'')+'\n'+(mail.body||'')).replace(/https?:\/\/\S+/g,'');
 return /(?:verification|security|authentication|login|sign[ -]?in|one[ -]?time|otp)\s*(?:code|passcode|password)|验证码|校验码|动态码|登录码|认证码|一次性密码/i.test(mail.subject||'') || /\b\d{4,10}\b.{0,48}\bpasscode\b|\b(?:one[ -]?time passcode|verification code|security code|login code|otp)\b.{0,48}\b\d{4,10}\b/is.test(text);
}
export function applyPolicy(mail,c){
 if(securityAnomaly(mail))return {...c,mail_type:'security_alert',category:c.category==='urgent'?'urgent':'important',importance:c.category==='urgent'?'urgent':'important',delivery_recommendation:'immediate'};
 if(c.mail_type==='verification_code' || (c.mail_type==='verification_success' && c.action_required===false && !c.calendar?.candidate && !(c.calendar?.events?.length) && c.confidence>=.9))
  return {...c,category:'normal',importance:'low',delivery_recommendation:'suppress'};
 if(c.mail_type==='verification_success')return {...c,delivery_recommendation:'confirm'};
 return c;
}
export const typeLabels={shipping:'快递物流',verification_code:'一次性验证码',verification_success:'验证成功回执',security_alert:'安全异常',academic_result:'学业结果',application_update:'申请进展',billing_notice:'账单付款',action_request:'待处理事项',routine_notice:'一般通知',receipt_confirmation:'确认回执',deadline:'截止提醒',calendar_event:'日程活动',needs_reply:'需要回复',transaction:'交易通知'};
