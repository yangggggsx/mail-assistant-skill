import test from 'node:test';
import assert from 'node:assert/strict';
import {notificationContent,notificationSchema,notificationInstructions} from './notification-format.js';
import {feedbackCategories,compatibilityLabel} from './feedback-fields.js';
test('financial category is shared by classifier, push display and feedback without priority coupling',()=>{
 assert.ok(notificationSchema.properties.label.enum.includes('财务消费'));
 assert.ok(feedbackCategories.includes('财务消费'));
 for(const importance of ['normal','important','urgent']){
  const c={importance,mail_type:'routine_notice',notification:{label:'财务消费',title:'会员等级升级'}};
  assert.equal(notificationContent({},c).label,'财务消费');
  assert.equal(c.importance,importance);
  assert.equal(compatibilityLabel('财务消费',importance),importance);
 }
 assert.match(notificationInstructions,/Preferred Plus tier/);
 assert.match(notificationInstructions,/异常交易\/盗刷风险仍用账户安全/);
});
