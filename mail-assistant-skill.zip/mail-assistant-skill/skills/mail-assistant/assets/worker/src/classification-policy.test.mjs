import test from 'node:test';
import assert from 'node:assert/strict';
import {otpOnly,applyPolicy} from './classification-policy.js';
import {disposition,notification} from './cloud-pipeline.js';
import config from './classification-config.json' with {type:'json'};
const base={category:'normal',importance:'normal',mail_type:'receipt_confirmation',action_required:false,delivery_recommendation:'confirm',confidence:.99,calendar:{candidate:false,events:[]}};
test('shipping is a separate type preserving normal and urgent routing',()=>{
 assert.ok(config.schema.properties.mail_type.enum.includes('shipping'));
 for(const priority of ['normal','important','urgent']){
  const c=applyPolicy({subject:'Package update'}, {...base,mail_type:'shipping',category:priority,importance:priority,summary:'包裹状态',suggested_action:'查看物流'});
  assert.equal(c.mail_type,'shipping');assert.equal(c.importance,priority);assert.equal(disposition(c),'notify');
  const n=notification({subject:'Package update',account_email:'test@example.com',sender:'Carrier'},c,'A'.repeat(32));
  assert.match(n.title,/^【快递物流/);assert.equal(n.priority,priority==='urgent'?1:0);
 }
 assert.equal(otpOnly({subject:'Your package pickup code',body:'取件码 123456，请及时取件'}),false);
});
test('passcode forms are silent but verification links are not OTP',()=>{
 assert.equal(otpOnly({subject:'123456 is your UNiDAYS passcode'}),true);
 assert.equal(otpOnly({subject:'Welcome',body:'One-time passcode 123456'}),true);
 assert.equal(otpOnly({subject:'Verification success!'}),false);
 assert.equal(otpOnly({subject:'Verify your email',body:'Click this link to verify'}),false);
});
test('model OTP is suppressed independently of its delivery recommendation',()=>{
 assert.equal(disposition(applyPolicy({}, {...base,mail_type:'verification_code'})),'suppressed');
});
test('only confident action-free verification success is silent',()=>{
 const c={...base,mail_type:'verification_success'};
 assert.equal(disposition(applyPolicy({},c)),'suppressed');
 assert.equal(disposition(applyPolicy({}, {...c,action_required:true})),'notify');
 assert.equal(disposition(applyPolicy({}, {...c,action_required:true,delivery_recommendation:'suppress'})),'notify');
 assert.equal(disposition(applyPolicy({}, {...c,confidence:.6})),'notify');
 assert.equal(disposition(applyPolicy({},base)),'notify');
});
test('security abnormality overrides silent classification',()=>{
 const c=applyPolicy({subject:'Suspicious login detected'}, {...base,mail_type:'verification_code'});
 assert.equal(c.mail_type,'security_alert');assert.equal(disposition(c),'notify');
});
