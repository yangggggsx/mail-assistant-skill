import test from 'node:test';
import assert from 'node:assert/strict';
import {normalizeGeneral,coursePayload} from './course-extraction.js';
import {localInstant} from './outlook-calendar.js';
import {cloudSchedulePage} from './cloud-schedules.js';
const job={token:'duration-test',timezone:'America/Chicago'};
const item={action:'create',kind:'activity',milestone:'event',title:'比赛',start:'2026-10-30T19:30',end:null,all_day:false,timezone:'America/New_York',suggested_duration_minutes:180,duration_reason:'篮球比赛的预计占位时长，实际可能提前或延后'};
const normalize=async extra=>(await normalizeGeneral({events:[{...item,...extra}],warnings:[]},job)).events[0];
test('suggestions vary by event and convert ET to St Louis before preview',async()=>{
 const basketball=await normalize({});
 assert.equal(basketball.start,'2026-10-30T18:30');
 assert.equal(basketball.end,'2026-10-30T21:30');
 assert.equal(basketball.timezone,'America/Chicago');
 assert.equal(basketball.duration_estimate.minutes,180);
 assert.equal(basketball.issue,undefined);
 const football=await normalize({suggested_duration_minutes:120,duration_reason:'足球常规比赛预计占位'});
 assert.equal(football.end,'2026-10-30T20:30');
 const page=await(await cloudSchedulePage({API_TOKEN:'test'},{token:job.token,status:'cloud_preview',preview_json:JSON.stringify({mode:'general',events:[basketball],warnings:[]})})).text();
 assert.match(page,/AI 建议，非原文结束时间/);
 assert.match(page,/全选新增与更新/);
 assert.match(page,/name="0_end" value="2026-10-30T21:30"/);
 assert.equal(coursePayload({...football,end:'2026-10-30T21:00'}).end.dateTime,'2026-10-30T21:00:00');
});
test('explicit end wins; missing dates, deadlines, all-day and invalid suggestions are not estimated',async()=>{
 const explicit=await normalize({end:'2026-10-30T21:00'});
 assert.equal(explicit.end,'2026-10-30T20:00');
 assert.equal(explicit.duration_estimate,undefined);
 for(const extra of [{start:''},{kind:'deadline'},{milestone:'due'},{kind:'homework'},{suggested_duration_minutes:null},{suggested_duration_minutes:0},{suggested_duration_minutes:721},{suggested_duration_minutes:2.5},{duration_reason:''}]){
  const event=await normalize(extra);
  assert.equal(event.duration_estimate,undefined);assert.equal(event.end,'');assert.ok(event.issue);
 }
 const allDay=await normalize({all_day:true,start:'2026-10-30'});
 assert.equal(allDay.duration_estimate,undefined);assert.equal(allDay.end,'2026-10-31T00:00');
});
test('elapsed estimated duration handles DST and date rollover without a fixed offset',async()=>{
 const event=await normalize({start:'2026-11-01T00:30',suggested_duration_minutes:240});
 assert.equal(localInstant(event.end,event.timezone)-localInstant(event.start,event.timezone),240*60000);
 assert.equal(event.start,'2026-10-31T23:30');
 const winter=await normalize({start:'2027-01-01T23:00'});
 assert.equal(winter.end,'2027-01-02T01:00');
 const invalid=await normalize({start:'2027-03-14T02:30'});
 assert.ok(invalid.issue);assert.equal(invalid.end,'');
});
