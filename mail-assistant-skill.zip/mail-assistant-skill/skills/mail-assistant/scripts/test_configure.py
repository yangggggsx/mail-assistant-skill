#!/usr/bin/env python3
import json
from pathlib import Path
import tempfile
import unittest
import subprocess
import sys
from configure import configure, validate, SKILL

class ConfigureTests(unittest.TestCase):
    def test_check_only_does_not_create_workspace(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            config = root/'config.json'
            config.write_text(json.dumps(self.settings()))
            command = [sys.executable, str(SKILL/'scripts/configure.py'), '--config', str(config), '--check-only']
            result = subprocess.run(command, capture_output=True, text=True)
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(list(root.iterdir()), [config])
            self.assertIn('have not been checked', result.stdout)
            config.write_text(json.dumps({**self.settings(), 'origin': 'https://example.com'}))
            self.assertNotEqual(subprocess.run(command, capture_output=True).returncode, 0)
            self.assertFalse((root/'worker').exists())
            self.assertNotEqual(subprocess.run(command + ['--output', str(root/'worker')], capture_output=True).returncode, 0)

    def settings(self):
        c = json.loads((SKILL/'assets/deployment.example.json').read_text())
        c.update(origin='https://mail.test-instance.workers.dev',calendar_account='calendar@sample.org',database_id='12345678-1234-4234-8234-123456789012',model='model-from-operator')
        return c

    def test_examples_cannot_be_deployed(self):
        with self.assertRaises(ValueError):
            validate(json.loads((SKILL/'assets/deployment.example.json').read_text()))

    def test_new_workspace_and_no_overwrite(self):
        before=(SKILL/'assets/worker/src/deployment-config.js').read_bytes()
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);p=root/'config.json';p.write_text(json.dumps(self.settings()))
            out=configure(p,root/'worker')
            self.assertTrue((out/'src/index.js').is_file())
            config=(out/'src/deployment-config.js').read_text()
            self.assertIn('https://mail.test-instance.workers.dev',config)
            self.assertIn('calendar@sample.org',config)
            self.assertIn('12345678-1234-4234-8234-123456789012',(out/'wrangler.toml').read_text())
            (out/'preserve.txt').write_text('existing work')
            with self.assertRaises(ValueError): configure(p,out)
            self.assertEqual((out/'preserve.txt').read_text(),'existing work')
        self.assertEqual((SKILL/'assets/worker/src/deployment-config.js').read_bytes(),before)

    def test_reject_credential_urls_and_partial_google(self):
        for url in ['https://user:secret@sample.org','https://sample.org/?token=x','http://sample.org','https://sample.org/path']:
            with self.assertRaises(ValueError): validate({**self.settings(),'origin':url})
        with self.assertRaises(ValueError): validate({**self.settings(),'gmail_topic':'projects/project/topics/topic'})
        with self.assertRaises(ValueError): validate({**self.settings(),'OPENAI_API_KEY':'do-not-accept-secrets'})

if __name__=='__main__': unittest.main()
