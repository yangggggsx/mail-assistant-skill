const esc = v => String(v ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const json = (v, status=200) => new Response(JSON.stringify(v), {status, headers:{'content-type':'application/json','cache-control':'no-store'}});
import {cloudMessage,runCloudAction,enqueueCloudAction} from './cloud-actions.js';
import {aiLaunchers,copyLaunchScript} from './copy-launch.js';
import {questionSuggestions} from './copy-intent.js';
import {handleIphoneTodo,iphoneTodoLaunch} from './iphone-todo.js';
import {ensureDelivery,enqueueDelivery,drainDelivery} from './delivery-queue.js';
export async function ensureMailTools(env) {
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS mail_tools (
    message_key TEXT NOT NULL, kind TEXT NOT NULL, token TEXT NOT NULL,
    status TEXT NOT NULL, result TEXT, error TEXT, requested_at TEXT NOT NULL,
    completed_at TEXT, PRIMARY KEY(message_key,kind))`).run();
}
async function formSignature(env, token, kind, expires) {
  const key = await crypto.subtle.importKey('raw', new TextEncoder().encode(env.API_TOKEN), {name:'HMAC',hash:'SHA-256'}, false, ['sign']);
  const bytes = await crypto.subtle.sign('HMAC', key, new TextEncoder().encode(`${token}:${kind}:${expires}`));
  return Array.from(new Uint8Array(bytes), b=>b.toString(16).padStart(2,'0')).join('');
}
export function toolPage(token, kind, task, proof = {}) {
  const nonce = crypto.randomUUID();
  const copy = kind === 'copy';
  const title = copy ? '复制到 AI' : '加入苹果提醒事项';
  let content;
  if (task?.status === 'completed') {
    content = copy ? `<p>直接复制即可了解邮件；也可以带着具体问题问 AI。</p>
      <label for="question"><strong>我想问……（可选）</strong></label>
      <textarea id="question" maxlength="2000" placeholder="例如：我已经联系过客服，这次想问接下来该怎么跟进。"></textarea>
      <div class="suggestions">${questionSuggestions(task.mail).map(q=>`<button type="button" data-question="${esc(q)}">${esc(q)}</button>`).join('')}</div>
      <button id="clear-question" class="clear" type="button">清空问题，使用通用分析</button>
      <p class="privacy">方向仅供参考，点击会替换问题，可继续编辑。问题仅在本页用于复制，不上传或保存为偏好。需要的附件或其他资料，可到 AI 中补充。</p>
      <details><summary>编辑邮件与基础提示词</summary><textarea id="payload" aria-label="邮件与基础提示词">${esc(task.result)}</textarea></details>
      <details id="preview-panel"><summary>查看实际复制内容</summary><textarea id="copy-preview" aria-label="实际复制内容" readonly></textarea></details>
      <div class="ai-actions">${aiLaunchers.map(a=>`<button type="button" data-ai-url="${esc(a.url)}" data-ai-label="${esc(a.label)}">复制并打开 ${a.label}</button>`).join('')}</div>
      <button id="copy" type="button">仅复制全部</button><p id="status" role="status"></p>
      <a id="launch-fallback" class="launch" hidden>已复制，点击打开 App</a>
      <details><summary>首次设置 / 手动打开</summary><p>在 iPhone「快捷指令」中新建以下两个快捷指令，名称须完全一致。每个只添加一个「打开 App」动作，选择对应 App；不需要读取剪贴板或调用 AI。</p>
      ${aiLaunchers.map(a=>`<p><strong>${esc(a.shortcut)}</strong> → 打开 ${esc(a.label)}<br><a href="${esc(a.url)}">手动打开 ${esc(a.label)}（不复制）</a></p>`).join('')}
      <p>如果浏览器未跳转，点击备用入口；如果提示找不到快捷指令，请核对名称。系统可能要求确认打开。</p></details>
      <p class="privacy">先复制当前编辑后的文本，再打开 App；请自行粘贴并发送。不调用模型，不自动发送，不在跳转链接中包含邮件正文。附件与图片不包含，正文临时缓存七天。</p>`
      : '<p>已加入「邮件待办」✓</p><p>请在苹果提醒事项中查看、编辑或完成。此处记录创建结果，不同步完成/删除状态；iPhone 同步取决于列表是否属于 iCloud。</p>';
  } else if (task?.status === 'pending') {
    content = `<div class="state" role="status"><span class="spinner"></span>${copy ? '正在准备正文' : '正在添加待办'}</div><p>${task.cloud ? '云端正在提取正文，无需 Mac 在线。' : '等待 Mac 处理，在线时通常约两分钟；休眠时保留排队。'}本页会自动更新。</p>`;
  } else {
    content = copy ? '<p>提取原邮件可读正文与分析提示词。附件、图片不会自动复制。</p>' : '<p>创建到「邮件待办」，包含摘要及邮件操作链接，不设置截止或提醒时间。同一邮件只创建一次。</p>';
    if (task?.error) content += `<p role="alert">上次未完成：${esc(task.error)}</p>`;
    content += `<form id="start" method="post" action="/f/${token}/${kind}"><input type="hidden" name="expires" value="${esc(proof.expires)}"><input type="hidden" name="proof" value="${esc(proof.signature)}">${task?.status === 'failed' ? '<button>重试</button>' : '<div class="state" role="status"><span class="spinner"></span>正在提交…</div><noscript><button>继续（浏览器未启用 JavaScript）</button></noscript>'}</form>`;
  }
  return new Response(`<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${title}</title>
  <meta name="color-scheme" content="light dark"><style>
  body{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;margin:0;background:#f4f5f7;color:#171717}
  main{max-width:480px;margin:0 auto;padding:32px 20px}.card{background:#fff;border-radius:22px;padding:24px;box-shadow:0 10px 35px #0001}
  h1{font-size:25px;margin:0 0 8px}p{color:#666;line-height:1.5;margin:0 0 22px}
  button{width:100%;min-height:52px;border:0;border-radius:14px;background:#eef0f4;color:#111;font-size:17px;font-weight:650}button:active{transform:scale(.98);background:#dfe3e9}
  textarea{box-sizing:border-box;width:100%;height:320px;margin:0 0 14px;padding:12px;border:1px solid #d8dbe2;border-radius:12px;font:15px -apple-system,sans-serif;resize:vertical}
  #question{height:96px;margin-top:10px}.suggestions{display:grid;gap:8px}.suggestions button{font-size:14px;font-weight:400;text-align:left;padding:10px 12px;min-height:42px}.clear{font-size:13px;width:auto;min-height:36px;padding:6px 10px;margin-top:10px}.ai-actions{margin-top:20px}
  .ai-actions{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px;margin-bottom:12px}.ai-actions button{padding:12px 8px;font-size:15px;background:#1877f2;color:white}a{color:#1877f2}.launch{display:block;margin:12px 0;line-height:1.5}.launch[hidden]{display:none}details{margin-top:18px;color:#666;line-height:1.5}details p{font-size:14px;margin:14px 0}summary{cursor:pointer}#status{margin-top:12px}
  .privacy{font-size:12px;margin-top:20px;color:#888}.state{display:flex;align-items:center;gap:10px;font-size:17px;font-weight:650;margin:20px 0}.spinner{width:16px;height:16px;border:2px solid #d8dbe2;border-top-color:#1877f2;border-radius:50%;animation:spin 1s linear infinite}@keyframes spin{to{transform:rotate(360deg)}}
  @media(prefers-color-scheme:dark){body{background:#111;color:#f5f5f5}.card{background:#202124}button{background:#303238;color:#fff}p{color:#bbb}textarea{background:#202124;color:#f5f5f5;border-color:#555}}
  @media(prefers-reduced-motion:reduce){.spinner{animation:none}}
  </style><main><div class="card"><h1>${title}</h1>${content}</div></main>
  <script nonce="${nonce}">
  let started=false;
  const start=()=>{if(document.visibilityState!=='visible'||started)return;started=true;${!task ? "document.getElementById('start').requestSubmit();" : task.status === 'pending' ? "setTimeout(()=>{started=false;if(document.visibilityState==='visible')location.replace(location.pathname);},2000);" : ''}};
  start();document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible')start();});
  </script>
  <script nonce="${nonce}">${copyLaunchScript}</script></html>`, {headers:{'content-type':'text/html; charset=utf-8','cache-control':'no-store','referrer-policy':'no-referrer','x-content-type-options':'nosniff','content-security-policy':`default-src 'none'; script-src 'nonce-${nonce}'; style-src 'unsafe-inline'; form-action 'self'; frame-ancestors 'none'; base-uri 'none'`}});
}
export async function handleMailTools(request, env, url, authenticated, ctx) {
  if(/^\/f\/[A-Za-z0-9_-]{32}\/iphone-todo(?:\/|$)/.test(url.pathname)) {
    await ensureMailTools(env);
    return handleIphoneTodo(request,env,url);
  }
  const match = url.pathname.match(/^\/f\/([A-Za-z0-9_-]{32})\/(copy|todo)$/);
  if (!match && !url.pathname.startsWith('/api/mail-tools/')) return null;
  if (!match && !authenticated) return json({error:'unauthorized'},401);
  await ensureMailTools(env);
  if(url.pathname==='/api/mail-tools/iphone-direct-test' && request.method==='POST') {
    let b;try{b=await request.json();}catch{return json({error:'json'},400);}
    if(b.confirm!==true||!/^iphone-direct-[a-z0-9-]{8,40}$/.test(b.test_id||''))return json({error:'confirmation_required'},400);
    await ensureDelivery(env);
    const key='test:'+b.test_id;
    const existing=await env.DB.prepare('SELECT status FROM delivery_queue WHERE delivery_key=?1').bind(key).first();
    if(existing)return json({duplicate:true,status:existing.status});
    const mail=await env.DB.prepare(`SELECT m.subject,f.token FROM cloud_messages m JOIN feedback_links f ON f.token=m.feedback_token
      WHERE f.expires_at>?1 AND NOT EXISTS(SELECT 1 FROM mail_tools t WHERE t.message_key=m.message_key AND t.kind='todo')
      ORDER BY m.created_at DESC LIMIT 1`).bind(new Date().toISOString()).first();
    if(!mail)return json({error:'no_available_message'},409);
    const launch=await iphoneTodoLaunch(env,url.origin,mail.token);
    await enqueueDelivery(env,key,{title:'【测试】直接加入待办',message:`关联邮件：${String(mail.subject||'邮件').slice(0,160)}\n\n请在30分钟内点击下方「直接加入待办」。这会真实创建一条提醒事项。成功后应自动回到 Pushover；请确认没有打开中转网页。正式邮件入口未改变。`,priority:0,html:false,url:launch,url_title:'直接加入待办（测试）'});
    await drainDelivery(env,{testOnly:true});
    return json(await env.DB.prepare('SELECT status,attempts,accepted_at FROM delivery_queue WHERE delivery_key=?1').bind(key).first());
  }
  if (match) {
    const [,token,kind] = match;
    const row = await env.DB.prepare('SELECT message_key,expires_at FROM feedback_links WHERE token=?1').bind(token).first();
    if (!row || row.expires_at < new Date().toISOString()) return json({error:'链接无效或已过期'},410);
    if (!['GET','POST'].includes(request.method)) return json({error:'method'},405);
    // Existing Mac work keeps its owner. New cloud-mail tasks go to the phone,
    // including stale POSTs from pages opened before the cutover.
    if (kind === 'todo') {
      const existing = await env.DB.prepare("SELECT status FROM mail_tools WHERE message_key=?1 AND kind='todo'").bind(row.message_key).first();
      const cloud = await env.DB.prepare('SELECT message_key FROM cloud_messages WHERE message_key=?1').bind(row.message_key).first();
      if (cloud && !['pending','completed'].includes(existing?.status)) {
        return new Response(null,{status:303,headers:{location:`/f/${token}/iphone-todo`,'cache-control':'no-store'}});
      }
    }
    if (request.method === 'POST') {
      const origin = request.headers.get('origin');
      // WebKit may send Origin: null for a privacy-restricted form submission.
      // Never trust that alone: require a short-lived, action-bound signed form.
      if ((origin && origin !== 'null' && origin !== url.origin) || request.headers.get('sec-fetch-site') === 'cross-site') return json({error:'origin'},403);
      let form;
      try { form = await request.formData(); } catch { return json({error:'请返回并刷新页面后重新确认'},403); }
      const expires = String(form.get('expires') || '');
      const proof = String(form.get('proof') || '');
      const now = Math.floor(Date.now()/1000);
      if (!env.API_TOKEN || !/^\d{10}$/.test(expires) || Number(expires)<now || Number(expires)>now+1800 ||
          proof !== await formSignature(env,token,kind,expires)) return json({error:'确认页面已失效，请返回并刷新后重试'},403);
      await env.DB.prepare(`INSERT INTO mail_tools(message_key,kind,token,status,requested_at) VALUES(?1,?2,?3,'pending',?4)
        ON CONFLICT(message_key,kind) DO UPDATE SET status='pending',token=excluded.token,error=NULL,requested_at=excluded.requested_at
        WHERE mail_tools.status='failed'`).bind(row.message_key,kind,token,new Date().toISOString()).run();
      const mail=kind==='copy'?await cloudMessage(env,row.message_key):null;
      if(mail) {
        if(mail.body) await runCloudAction(env,'copy',row.message_key);
        else await enqueueCloudAction(env,'copy',row.message_key);
      }
      return new Response(null,{status:303,headers:{location:url.pathname,'cache-control':'no-store'}});
    }
    let task = await env.DB.prepare('SELECT * FROM mail_tools WHERE message_key=?1 AND kind=?2').bind(row.message_key,kind).first();
    if(task && kind==='copy') {const mail=await cloudMessage(env,row.message_key);task.cloud=Boolean(mail);task.mail=mail?{subject:mail.subject,classification_json:mail.classification_json}:{};}
    const expires = String(Math.floor(Date.now()/1000)+1800);
    const signature = await formSignature(env,token,kind,expires);
    return toolPage(token,kind,task,{expires,signature});
  }
  if (url.pathname === '/api/mail-tools/pull' && request.method === 'GET') {
    const rows = await env.DB.prepare("SELECT message_key,kind,token FROM mail_tools t WHERE status='pending' AND (kind='todo' OR NOT EXISTS(SELECT 1 FROM cloud_messages m WHERE m.message_key=t.message_key)) ORDER BY requested_at LIMIT 10").all();
    return json({tasks:rows.results || []});
  }
  if (url.pathname === '/api/mail-tools/result' && request.method === 'POST') {
    let b;try{b=await request.json();}catch{return json({error:'json'},400);}
    if (!/^[0-9a-f]{64}$/.test(b.message_key || '') || !['copy','todo'].includes(b.kind) || !['completed','failed'].includes(b.status)) return json({error:'invalid'},400);
    const r=await env.DB.prepare(`UPDATE mail_tools SET status=?1,result=?2,error=?3,completed_at=?4 WHERE message_key=?5 AND kind=?6 AND status='pending'
      AND (kind='todo' OR NOT EXISTS(SELECT 1 FROM cloud_messages m WHERE m.message_key=mail_tools.message_key))`)
      .bind(b.status,String(b.result || '').slice(0,24000),String(b.error || '').slice(0,500),new Date().toISOString(),b.message_key,b.kind).run();
    return json({updated:r.meta?.changes || 0});
  }
  return json({error:'not_found'},404);
}
export async function cleanupMailTools(env) {
  await ensureMailTools(env);
  await env.DB.prepare("DELETE FROM mail_tools WHERE kind='copy' AND requested_at<?1").bind(new Date(Date.now()-7*86400000).toISOString()).run();
}
