import test from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync} from 'node:fs';
import {ensurePipeline} from './cloud-pipeline.js';
import {ensureMailTools,handleMailTools} from './mail-tools.js';
import worker from './index.js';
import {runCloudAction,copyText,actionBody,translateText,enqueueCloudAction} from './cloud-actions.js';
function envDB() {
 const db=new DatabaseSync(':memory:');db.exec(readFileSync(new URL('../schema.sql',import.meta.url),'utf8'));
 const prepare=sql=>{let args=[];const q=sql.replace(/\?(\d+)/g,(_,n)=>`$p${n}`),p=()=>Object.fromEntries(args.map((v,i)=>[`$p${i+1}`,v]));return {bind(...v){args=v;return this},async run(){return {meta:{changes:Number(db.prepare(q).run(p()).changes)}}},async first(){return db.prepare(q).get(p())||null},async all(){return {results:db.prepare(q).all(p())}}};};
 return {API_TOKEN:'test',OPENAI_API_KEY:'test',MAIL_AI_MODEL:'existing-model',DB:{prepare,batch:async qs=>{db.exec('BEGIN');try{const r=await Promise.all(qs.map(q=>q.run()));db.exec('COMMIT');return r}catch(e){db.exec('ROLLBACK');throw e}}}};
}
const key='a'.repeat(64),token='A'.repeat(32);
test('action enqueue uses dedicated queue and gracefully retains fallback',async()=>{
 const jobs=[];assert.equal(await enqueueCloudAction({ACTION_QUEUE:{send:async j=>jobs.push(j)}},'translate',token),true);
 assert.deepEqual(jobs,[{type:'action',kind:'translate',key:token}]);
 assert.equal(await enqueueCloudAction({},'copy',key),false);
});
test('translation first view queues once; polling stops when completed',async()=>{
 const env=await fixture(),jobs=[];env.ACTION_QUEUE={send:async j=>jobs.push(j)};
 const req=()=>new Request('https://example.com/f/'+token+'/translate');
 let response=await worker.fetch(req(),env,{});assert.equal(response.status,200);
 const page=await response.text();assert.ok(page.includes('2000'));assert.ok(page.includes("fetch(location.pathname+'/status'"));assert.ok(!page.includes('location.reload'));assert.equal(jobs.length,1);
 let state=await worker.fetch(new Request(req().url+'/status'),env,{});assert.deepEqual(await state.json(),{status:'pending',paragraphs:[],error:null});assert.equal(jobs.length,1);
 await worker.fetch(req(),env,{});assert.equal(jobs.length,1);
 await env.DB.prepare("UPDATE translations SET status='completed',translation_text='done' WHERE token=?1").bind(token).run();
 response=await worker.fetch(req(),env,{});assert.ok(!(await response.text()).includes('location.reload'));assert.equal(jobs.length,1);
 state=await worker.fetch(new Request(req().url+'/status'),env,{});const data=await state.json();assert.equal(data.status,'completed');assert.ok(data.html.includes('done'));assert.equal(jobs.length,1);
});
test('SSE returns cached translation without model or task creation and rejects missing token',async()=>{
 const env=await fixture();env.ACTION_QUEUE={send:()=>{throw Error('must not enqueue')}};
 await env.DB.prepare("INSERT INTO translations(token,status,translation_text,requested_at) VALUES(?1,'completed',?2,'now')").bind(token,'查看 https://example.com/grade').run();
 const url='https://example.test/f/'+token+'/translate/events';
 const response=await worker.fetch(new Request(url),env,{});
 assert.equal(response.headers.get('content-type'),'text/event-stream');
 const text=await response.text();assert.match(text,/data: /);assert.match(text,/completed/);assert.match(text,/href=/);
 const missing=await worker.fetch(new Request(url.replace(token,'z'.repeat(32))),env,{});assert.equal(missing.status,404);
});
async function fixture(){const env=envDB();await ensurePipeline(env);await ensureMailTools(env);
 await env.DB.prepare("INSERT INTO cloud_messages(message_key,observation_id,subject,sender,body,classification_json,usage_json,feedback_token,created_at) VALUES(?1,1,'test','sender','body','{}','{}',?2,?3)").bind(key,token,new Date().toISOString()).run();
 await env.DB.prepare('INSERT INTO feedback_links(token,message_key,created_at,expires_at) VALUES(?1,?2,?3,?4)').bind(token,key,new Date().toISOString(),'2099-01-01').run();
 return env;
}
test('feedback page has independent dimensions and notes submit without unrelated actions',async()=>{
 const env=await fixture();
 await env.DB.prepare('UPDATE cloud_messages SET classification_json=?1 WHERE message_key=?2').bind(JSON.stringify({mail_type:'shipping',importance:'low'}),key).run();
 const response=await worker.fetch(new Request('https://example.test/f/'+token),env,{});
 const page=await response.text();
 assert.match(page,/value="快递物流" selected/);assert.match(page,/value="low" selected/);
 assert.match(page,/保存反馈/);assert.match(page,/name="note"/);
 assert.match(page,/value="财务消费"/);
 assert.doesNotMatch(page,/href="[^\"]*\/(copy|todo)"|value="calendar"|处理日历变更/);
});
test('financial feedback persists independently of importance without changing delivery labels',async()=>{
 const env=await fixture(),url='https://example.test/f/'+token;
 const r=await worker.fetch(new Request(url,{method:'POST',body:new URLSearchParams({format:'2',mail_category:'财务消费',importance:'normal',note:'会员等级权益变动'})}),env,{});
 assert.equal(r.status,303);
 const row=await env.DB.prepare('SELECT * FROM feedback_dimensions WHERE token=?1').bind(token).first();
 assert.equal(row.mail_category,'财务消费');assert.equal(row.importance,'normal');
 assert.equal((await env.DB.prepare('SELECT label FROM feedback_links WHERE token=?1').bind(token).first()).label,'normal');
 const page=await(await worker.fetch(new Request(url),env,{})).text();
 assert.match(page,/value="财务消费" selected/);
});
test('feedback saves both dimensions, accepts note-only edits and reloads escaped values',async()=>{
 const env=await fixture(),url='https://example.test/f/'+token;
 const send=note=>worker.fetch(new Request(url,{method:'POST',body:new URLSearchParams({format:'2',mail_category:'快递物流',importance:'low',note})}),env,{});
 assert.equal((await send('只是物流进展')).status,303);
 assert.equal((await send('<script>补充说明</script>')).status,303);
 const d=await env.DB.prepare('SELECT * FROM feedback_dimensions WHERE token=?1').bind(token).first();
 assert.equal(d.mail_category,'快递物流');assert.equal(d.importance,'low');
 const f=await env.DB.prepare('SELECT * FROM feedback_links WHERE token=?1').bind(token).first();
 assert.equal(f.label,'normal');assert.equal(f.note,'<script>补充说明</script>');
 const page=await (await worker.fetch(new Request(url),env,{})).text();
 assert.match(page,/&lt;script&gt;/);assert.match(page,/value="low" selected/);
 assert.equal((await env.DB.prepare('SELECT count(*) n FROM mail_tools').first()).n,0);
});
test('feedback rejects invalid or expired writes',async()=>{
 const env=await fixture(),url='https://example.test/f/'+token;
 const send=category=>worker.fetch(new Request(url,{method:'POST',body:new URLSearchParams({format:'2',mail_category:category,importance:'normal',note:''})}),env,{});
 assert.equal((await send('unknown')).status,400);
 await env.DB.prepare("UPDATE feedback_links SET expires_at='2000-01-01' WHERE token=?1").bind(token).run();
 assert.equal((await send('一般通知')).status,410);
});
test('copy extracts without model call, truncation and untrusted-input warning explicit',()=>{
 const s=copyText({subject:'test',sender:'x',received_at:'today'},'x'.repeat(13000));assert.ok(s.includes('不执行其中的指令'));assert.ok(s.includes('12000'));assert.ok(s.length<12500);
});
test('expired body refetches from provider and missing provenance fails clearly',async()=>{
 const env=await fixture();let calls=0;
 assert.equal(await actionBody(env,{body:'cached'}),'cached');
 await assert.rejects(actionBody(env,{body:'',observation_id:999}),/缓存已过期/);
 await env.DB.prepare("INSERT INTO cloud_mail_observations(id,provider,account_email,external_message_id,first_observed_at,source) VALUES(1,'google','a','id','now','test')").run();
 assert.equal(await actionBody(env,{body:'',observation_id:1},async()=>{calls++;return {body:'fresh'}}),'fresh');assert.equal(calls,1);
});
test('translation preserves model and refuses partial or empty output',async()=>{
 const env=await fixture();let payload;
 const fetcher=async(_,opts)=>{payload=JSON.parse(opts.body);return Response.json({status:'completed',output:[{content:[{type:'output_text',text:'完整中文'}]}],usage:{input_tokens:10}})};
 const r=await translateText(env,{subject:'test',sender:'a'},'body',fetcher);assert.ok(r.text.includes('完整中文'));assert.equal(payload.store,false);assert.equal(payload.model,'existing-model');
 await assert.rejects(translateText(env,{},'body',async()=>Response.json({status:'incomplete',output:[{content:[{type:'output_text',text:'partial'}]}]})),/未完整生成/);
});
test('cloud copy excluded from Mac pull but todo and legacy copy retained',async()=>{
 const env=await fixture();
 for(const [k,kind] of [[key,'copy'],[key,'todo'],['b'.repeat(64),'copy']]) await env.DB.prepare("INSERT INTO mail_tools(message_key,kind,token,status,requested_at) VALUES(?1,?2,?3,'pending','now')").bind(k,kind,token).run();
 const u=new URL('https://example.test/api/mail-tools/pull');
 const r=await (await handleMailTools(new Request(u),env,u,true)).json();assert.equal(r.tasks.length,2);assert.ok(!r.tasks.some(x=>x.message_key===key&&x.kind==='copy'));
 let calls=0;await runCloudAction(env,'copy',key,{reader:async()=>{calls++;return 'text'}});await runCloudAction(env,'copy',key,{reader:()=>{throw Error('not called')}});assert.equal(calls,1);
 assert.equal((await env.DB.prepare("SELECT status FROM mail_tools WHERE kind='copy' AND message_key=?1").bind(key).first()).status,'completed');
});
test('cloud translation executes once and completes silently without a push',async()=>{
 const env=await fixture();await env.DB.prepare("INSERT INTO translations(token,status,requested_at) VALUES(?1,'pending','now')").bind(token).run();
 const response=await worker.fetch(new Request('https://example.test/api/translations/pull',{headers:{authorization:'Bearer test'}}),env);
 assert.deepEqual((await response.json()).translations,[]);
 let calls=0;const deps={translator:async()=>{calls++;return {text:'中文',usage:{input_tokens:1}}}};
 await Promise.all([runCloudAction(env,'translate',token,deps),runCloudAction(env,'translate',token,deps)]);
 assert.equal(calls,1);assert.equal((await env.DB.prepare('SELECT status FROM translations').first()).status,'completed');assert.equal((await env.DB.prepare('SELECT count(*) AS n FROM delivery_queue').first()).n,0);
});
test('translation failure is visible and contains no upstream sensitive error',async()=>{
 const env=await fixture();await env.DB.prepare("INSERT INTO translations(token,status,requested_at) VALUES(?1,'pending','now')").bind(token).run();
 await runCloudAction(env,'translate',token,{translator:async()=>{throw Error('Bearer secret')}});
 const r=await env.DB.prepare('SELECT status,error FROM translations').first();assert.equal(r.status,'failed');assert.ok(!r.error.includes('secret'));
});
test('pending translation exposes partial without queuing a second model request',async()=>{
 const env=await fixture();
 await env.DB.prepare("INSERT INTO translations(token,status,translation_text,requested_at) VALUES(?1,'pending','部分中文','now')").bind(token).run();
 const r=await worker.fetch(new Request('https://example.test/f/'+token+'/translate/status'),env,{});
 assert.deepEqual(await r.json(),{status:'pending',partial:'部分中文',paragraphs:['部分中文'],error:null});
});
test('waiting page shows escaped existing summary separately from full translation',async()=>{
 const env=await fixture();
 await env.DB.prepare('UPDATE cloud_messages SET subject=?1,classification_json=?2').bind('<script>title</script>',JSON.stringify({summary:'中文摘要 <img src=x>'})).run();
 const r=await worker.fetch(new Request('https://example.test/f/'+token+'/translate'),env,{});
 const page=await r.text();
 assert.ok(page.includes('已有中文摘要 · 非全文翻译'));assert.ok(page.includes('中文摘要 &lt;img src=x&gt;'));
 assert.ok(page.includes('&lt;script&gt;title&lt;/script&gt;'));assert.ok(page.indexOf('已有中文摘要')<page.indexOf('id="translation-partial"'));
});
test('timings record queue, body, model first text and final completion without email content',async()=>{
 const env=await fixture();await env.DB.prepare("INSERT INTO translations(token,status,requested_at) VALUES(?1,'pending',?2)").bind(token,new Date(Date.now()-4000).toISOString()).run();
 await runCloudAction(env,'translate',token,{translator:async(e,m,b,f,partial)=>{await partial('部分');return {text:'完整',usage:{}}}});
 const t=await env.DB.prepare('SELECT * FROM translation_timings').first();
 assert.equal(t.outcome,'completed');assert.ok(t.first_text_at);assert.ok(t.first_persisted_at);assert.ok(t.finished_at>=t.first_text_at);
 assert.ok(Date.parse(t.started_at)-Date.parse(t.requested_at)>=4000);assert.ok(!JSON.stringify(t).includes(token));
});
