# iPhone shortcuts

These are manual setup instructions, not a signed/installable `.shortcut` artifact. Name the reminder shortcut exactly `邮件助手-加入待办`, matching the generated launch URL. The phone must use the intended iCloud Reminders list.

## Add reminder

1. Create the Reminders list `邮件待办`. Create the shortcut above, accepting text input (the signed claim URL from the web flow). With no input, stop.
2. Get Contents of Shortcut Input: POST, JSON body with **Number** `format: 2`. Save the returned dictionary as `任务`. If `claim` is empty, show the returned error and stop.
3. Get `marker` from `任务`. Find Reminders where **Any** of `Notes contains marker` or `URL contains marker` is true. Do not filter out completed reminders.
4. Count results. More than one: ask the user to reconcile and stop. One: use the existing reminder. Zero: Add Reminder with `title` to `邮件待办`, `notes` in Notes and `url` in URL. No alert, guessed deadline or edit sheet.
5. After a successful add or finding exactly one existing item, POST to `receipt_url` with JSON `claim` equal to the task claim and `status` equal to `completed`.
6. Read the response's `ok` boolean. Return to Pushover on success; do not send an additional “added” push. If false or the request fails, explain that the reminder may already exist and must be checked before retrying.

The website shows server receipt state; returning to Pushover alone is not success. Existing format-1 shortcuts need both Notes/URL search and URL storage configured before switching to format 2. Never insert the admin API token into this shortcut.

## Share a file for event extraction

1. Create `上传日程`, enable Share Sheet, accept Images, PDFs and Files.
2. Accept one input file; for multiple files use the upload website.
3. Store the private upload-page URL followed by `/upload` in a URL action.
4. Get Contents of URL: POST, Request Body File, File **Shortcut Input** (not the preceding URL action's output).
5. Read `status_url` from the response; open it. If missing, show the returned error. Do not automatically retry an ambiguous upload timeout.
6. The cloud extracts events and presents an editable preview. The user confirms selected items for Outlook insertion; the shortcut does not auto-confirm them.

Supported formats: PDF, JPEG, PNG, WebP, HEIC/HEIF. HEIC conversion needs the configured Cloudflare Images binding. Website uploads support up to ten files with a total 20 MB limit. Default timezone is America/Chicago; review or change it for another locale. Optional multipart fields are `files`, `course_hint`, `term_hint`, `timezone`; use the actual source parser when changing clients.

File analysis and Outlook writing do not require a Mac. Writing Apple Reminders still requires the iPhone shortcut.
