import {cloudSchedulePage,confirmCloudSchedule,enqueueSchedule} from './cloud-schedules.js';
const DAY_MS = 24 * 60 * 60 * 1000;
const MAX_UPLOAD_BYTES = 20 * 1024 * 1024;
const MAX_FILES = 10;
const JOB_RETENTION_DAYS = 30;
const ACCESS_RETENTION_DAYS = 365;
const D1_CHUNK_BYTES = 1024 * 1024;

function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      "content-type": "application/json; charset=utf-8",
      "cache-control": "no-store",
      "x-content-type-options": "nosniff",
    },
  });
}

export function html(body, status = 200) {
  return new Response(`<!doctype html><html lang="zh-CN"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><meta name="color-scheme" content="light dark">
<title>日程提取助手</title><style>
body{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;margin:0;background:#f4f5f7;color:#171717}
main{max-width:620px;margin:0 auto;padding:28px 18px 60px}.card{background:#fff;border-radius:22px;padding:24px;box-shadow:0 10px 35px #0001}
h1{font-size:26px;margin:0 0 10px}p{color:#666;line-height:1.55;margin:0 0 18px}
label{display:block;font-size:14px;font-weight:650;margin:14px 0 6px}input,select{box-sizing:border-box;width:100%;min-height:48px;padding:10px 12px;border:1px solid #d8dbe2;border-radius:12px;background:#fff;color:#111;font:16px inherit}
button,.button{box-sizing:border-box;display:inline-flex;align-items:center;justify-content:center;min-height:48px;padding:0 17px;border:0;border-radius:12px;background:#1877f2;color:#fff;text-decoration:none;font:650 16px inherit;cursor:pointer}
button[disabled]{opacity:.55}.secondary{min-height:40px;padding:0 13px;background:#eaf2ff;color:#155bb5;font-size:14px}.selection-tools{display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin:14px 0}.selection-count{font-size:13px;color:#777;margin-left:auto}.event{padding:14px 0;border-top:1px solid #e6e7eb}.event label{display:flex;gap:12px;align-items:flex-start;margin:0}.event input{width:22px;min-height:22px;margin-top:2px}.event strong{display:block}.meta,.privacy{font-size:13px;color:#777;line-height:1.5}.warning{padding:12px;border-radius:12px;background:#fff3cd;color:#7a5600;margin:12px 0}.success{padding:12px;border-radius:12px;background:#e8f7ed;color:#155f2f;margin:12px 0}.error{padding:12px;border-radius:12px;background:#fdecec;color:#8c2020;margin:12px 0}.progress{height:8px;background:#e9ebef;border-radius:999px;overflow:hidden;margin:16px 0}.progress span{display:block;height:100%;background:#1877f2;width:45%;animation:move 1.2s infinite alternate}@keyframes move{to{transform:translateX(120%)}}
@media(prefers-color-scheme:dark){body{background:#111;color:#f5f5f5}.card{background:#202124}p,.meta,.privacy{color:#bbb}input,select{background:#2b2d31;color:#fff;border-color:#444}.event{border-color:#383a40}}
</style></head><body><main><div class="card">${body}</div></main></body></html>`, {
    status,
    headers: {
      "content-type": "text/html; charset=utf-8",
      "cache-control": "no-store",
      "content-security-policy": "default-src 'none'; style-src 'unsafe-inline'; script-src 'unsafe-inline'; form-action 'self'; connect-src 'self'; base-uri 'none'; frame-ancestors 'none'",
      "referrer-policy": "no-referrer",
      "x-content-type-options": "nosniff",
      "x-frame-options": "DENY",
    },
  });
}

export function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>"']/g, (character) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;",
  })[character]);
}

function randomToken() {
  const bytes = new Uint8Array(24);
  crypto.getRandomValues(bytes);
  return btoa(String.fromCharCode(...bytes)).replaceAll("+", "-").replaceAll("/", "_").replaceAll("=", "");
}

function validToken(value) {
  return /^[A-Za-z0-9_-]{32}$/.test(String(value || ""));
}

function safeHeaderValue(request, name, limit) {
  const raw = String(request.headers.get(name) || "").slice(0, limit * 3);
  try { return decodeURIComponent(raw).trim().slice(0, limit); } catch { return raw.trim().slice(0, limit); }
}

export async function ensureScheduleSchema(env) {
  await env.DB.batch([
    env.DB.prepare(`CREATE TABLE IF NOT EXISTS schedule_access_links (
      token TEXT PRIMARY KEY, created_at TEXT NOT NULL, expires_at TEXT NOT NULL, last_used_at TEXT
    )`),
    env.DB.prepare(`CREATE TABLE IF NOT EXISTS schedule_uploads (
      id INTEGER PRIMARY KEY AUTOINCREMENT, token TEXT NOT NULL UNIQUE, access_token TEXT NOT NULL,
      object_key TEXT, filename TEXT NOT NULL, content_type TEXT NOT NULL, size_bytes INTEGER NOT NULL,
      course_hint TEXT, term_hint TEXT, timezone TEXT NOT NULL, status TEXT NOT NULL,
      preview_json TEXT, selected_json TEXT, result_json TEXT, error TEXT,
      created_at TEXT NOT NULL, expires_at TEXT NOT NULL, claimed_at TEXT,
      confirmed_at TEXT, completed_at TEXT
    )`),
    env.DB.prepare("CREATE INDEX IF NOT EXISTS idx_schedule_uploads_status ON schedule_uploads(status,created_at)"),
    env.DB.prepare(`CREATE TABLE IF NOT EXISTS schedule_file_chunks (
      job_token TEXT NOT NULL, chunk_index INTEGER NOT NULL, data BLOB NOT NULL,
      PRIMARY KEY(job_token,chunk_index)
    )`),
    env.DB.prepare(`CREATE TABLE IF NOT EXISTS schedule_files (
      job_token TEXT NOT NULL, file_index INTEGER NOT NULL, filename TEXT NOT NULL,
      content_type TEXT NOT NULL, size_bytes INTEGER NOT NULL, storage_key TEXT,
      PRIMARY KEY(job_token,file_index)
    )`),
    env.DB.prepare(`CREATE TABLE IF NOT EXISTS schedule_file_parts (
      job_token TEXT NOT NULL, file_index INTEGER NOT NULL, chunk_index INTEGER NOT NULL,
      data BLOB NOT NULL, PRIMARY KEY(job_token,file_index,chunk_index)
    )`),
  ]);
}

async function activeAccess(env, token) {
  if (!validToken(token)) return null;
  return env.DB.prepare("SELECT token,expires_at FROM schedule_access_links WHERE token=?1 AND expires_at>?2")
    .bind(token, new Date().toISOString()).first();
}

async function createAccessLink(env, url) {
  await ensureScheduleSchema(env);
  const token = randomToken();
  const now = new Date();
  const expiresAt = new Date(now.getTime() + ACCESS_RETENTION_DAYS * DAY_MS);
  await env.DB.prepare("INSERT INTO schedule_access_links(token,created_at,expires_at) VALUES(?1,?2,?3)")
    .bind(token, now.toISOString(), expiresAt.toISOString()).run();
  return json({ url: `${url.origin}/s/${token}`, expires_at: expiresAt.toISOString() });
}

async function uploadPage(env, token) {
  await ensureScheduleSchema(env);
  if (!await activeAccess(env, token)) return html("<h1>上传入口无效</h1><p>请让邮件助手重新生成入口。</p>", 404);
  return html(`<h1>提取日程</h1><p>上传会议、活动、预约或课程资料，预览并修改后再加入日历。</p>
    <label for="file">PDF 或图片（最多 10 个文件、合计 20 MB）</label><input id="file" type="file" multiple accept="application/pdf,image/png,image/jpeg,image/webp,image/heic,image/heif,.pdf,.png,.jpg,.jpeg,.webp,.heic,.heif"><p class="meta">支持 PDF、PNG、JPEG、WebP、HEIC/HEIF，可直接上传 iPhone 原照片。</p>
    <details><summary>课程专项同步（可选）</summary><p>默认通用提取，不要求课程或学期。需要关联已有课程、核对改期和取消时，请同时填写下列两项，并仅上传同一门课同一学期的资料。通用模式只新增，不自动修改或删除已有日程。</p>
    <label for="course">课程号 / 名称</label><input id="course" maxlength="120" placeholder="例如 ESE 5700">
    <label for="term">学期</label><input id="term" maxlength="80" placeholder="例如 Fall 2026"></details>
    <label for="timezone">默认时区（原文未指定时使用）</label><select id="timezone"><option value="America/Chicago">America/Chicago</option><option value="America/New_York">America/New_York</option><option value="America/Los_Angeles">America/Los_Angeles</option><option value="Asia/Shanghai">Asia/Shanghai</option></select>
    <div style="height:18px"></div><button id="upload">上传并分析</button><div id="status" class="meta" style="margin-top:14px"></div>
    <details class="privacy"><summary>文件与记录</summary>原文件和截图在提取完成后删除；预览保留 30 天。日历归属和同步记录持续保留，用于防止重复创建及核对改期。课程文件是不可信输入，不会执行其中的指令。</details>
    <script>const button=document.getElementById('upload'),status=document.getElementById('status'),input=document.getElementById('file');button.addEventListener('click',async()=>{const files=[...input.files];if(!files.length){status.textContent='请先选择 PDF 或截图。';return}if(files.length>10){status.textContent='一次最多选择 10 个文件。';return}const total=files.reduce((sum,file)=>sum+file.size,0);if(total>20*1024*1024){status.textContent='文件合计超过 20 MB。';return}const allowed=/\.(pdf|png|jpe?g|webp|heic|heif)$/i;if(files.some(file=>!allowed.test(file.name))){status.textContent='仅支持 PDF、PNG、JPEG、WebP、HEIC/HEIF。';return}button.disabled=true;status.textContent='正在安全上传 '+files.length+' 个文件…';try{const form=new FormData();files.forEach(file=>form.append('files',file,file.name));form.append('course_hint',document.getElementById('course').value);form.append('term_hint',document.getElementById('term').value);form.append('timezone',document.getElementById('timezone').value);const response=await fetch(location.pathname+'/upload',{method:'POST',body:form});const result=await response.json();if(!response.ok)throw new Error(result.error||'上传失败');location.href=result.status_url}catch(error){status.textContent='上传失败：'+error.message;button.disabled=false}});</script>`);
}

function ascii(bytes, start, length) {
  return String.fromCharCode(...bytes.slice(start, start + length));
}

function detectInputType(buffer) {
  const bytes = buffer instanceof Uint8Array ? buffer : new Uint8Array(buffer);
  if (bytes.length >= 5 && ascii(bytes, 0, 5) === "%PDF-") return "application/pdf";
  if (bytes.length >= 8 && bytes[0] === 0x89 && ascii(bytes, 1, 3) === "PNG"
      && bytes[4] === 0x0d && bytes[5] === 0x0a && bytes[6] === 0x1a && bytes[7] === 0x0a) return "image/png";
  if (bytes.length >= 3 && bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff) return "image/jpeg";
  if (bytes.length >= 12 && ascii(bytes, 0, 4) === "RIFF" && ascii(bytes, 8, 4) === "WEBP") return "image/webp";
  if (bytes.length >= 12 && ascii(bytes, 4, 4) === "ftyp") {
    const brands = ascii(bytes, 8, Math.min(bytes.length - 8, 56));
    if (/(heic|heix|hevc|hevx|heim|heis|hevm|hevs|mif1|msf1)/.test(brands)) return "image/heic";
  }
  return null;
}

function cleanFilename(value, fallback) {
  const leaf = String(value || "").replaceAll("\\", "/").split("/").pop().replace(/[\u0000-\u001f\u007f]/g, "").trim();
  return (leaf || fallback).slice(0, 180);
}

async function parseUploadedFiles(request) {
  const requestType = String(request.headers.get("content-type") || "");
  if (requestType.startsWith("multipart/form-data")) {
    const form = await request.formData();
    const inputs = form.getAll("files").filter((item) => item && typeof item.arrayBuffer === "function");
    const files = [];
    for (let index = 0; index < inputs.length; index += 1) {
      const input = inputs[index];
      const bytes = await input.arrayBuffer();
      files.push({ filename: cleanFilename(input.name, `schedule-${index + 1}`), bytes, contentType: detectInputType(bytes) });
    }
    return {
      files,
      courseHint: String(form.get("course_hint") || "").trim().slice(0, 120),
      termHint: String(form.get("term_hint") || "").trim().slice(0, 80),
      timezone: String(form.get("timezone") || "America/Chicago").trim().slice(0, 80),
    };
  }
  const bytes = await request.arrayBuffer();
  return {
    files: [{ filename: cleanFilename(safeHeaderValue(request, "x-file-name", 180), "schedule.pdf"), bytes, contentType: detectInputType(bytes) }],
    courseHint: safeHeaderValue(request, "x-course-hint", 120),
    termHint: safeHeaderValue(request, "x-term-hint", 80),
    timezone: safeHeaderValue(request, "x-timezone", 80) || "America/Chicago",
  };
}

export async function deleteStoredFiles(env, token, objectKey = "") {
  const rows = await env.DB.prepare("SELECT storage_key FROM schedule_files WHERE job_token=?1").bind(token).all();
  if (env.UPLOADS) {
    for (const row of rows.results || []) if (row.storage_key) await env.UPLOADS.delete(row.storage_key);
  }
  await env.DB.batch([
    env.DB.prepare("DELETE FROM schedule_file_parts WHERE job_token=?1").bind(token),
    env.DB.prepare("DELETE FROM schedule_files WHERE job_token=?1").bind(token),
    env.DB.prepare("DELETE FROM schedule_file_chunks WHERE job_token=?1").bind(token),
  ]);
  if (objectKey && !String(objectKey).startsWith("d1:") && !String(objectKey).startsWith("bundle:") && env.UPLOADS) {
    await env.UPLOADS.delete(objectKey);
  }
  return (rows.results || []).length;
}

async function receiveUpload(request, env, accessToken, url) {
  await ensureScheduleSchema(env);
  if (!await activeAccess(env, accessToken)) return json({ error: "上传入口无效或已过期" }, 404);
  if(Number(request.headers.get('content-length')||0)>MAX_UPLOAD_BYTES+1024*1024)return json({error:'文件合计超过 20 MB'},413);
  let parsed;
  try { parsed = await parseUploadedFiles(request); } catch { return json({ error: "无法解析上传内容" }, 400); }
  if (!parsed.files.length) return json({ error: "请至少选择一个 PDF 或截图" }, 400);
  if (parsed.files.length > MAX_FILES) return json({ error: `一次最多上传 ${MAX_FILES} 个文件` }, 413);
  const totalSize = parsed.files.reduce((sum, file) => sum + file.bytes.byteLength, 0);
  if (!totalSize || totalSize > MAX_UPLOAD_BYTES) return json({ error: "文件合计大小必须在 1 字节到 20 MB 之间" }, 413);
  if (parsed.files.some((file) => !file.bytes.byteLength || !file.contentType)) {
    return json({ error: "仅支持内容有效的 PDF、PNG、JPEG、WebP、HEIC/HEIF 文件" }, 415);
  }
  if (parsed.files.some(file=>file.contentType==='image/heic')&&!env.IMAGES) return json({error:'HEIC 云端解码服务暂不可用，请稍后重试'},503);
  if(!env.ACTION_QUEUE||!env.OPENAI_API_KEY) return json({error:'云端课程提取尚未配置'},503);
  const token = randomToken();
  const objectKey = `bundle:${token}`;
  const courseHint = parsed.courseHint;
  const termHint = parsed.termHint;
  if(Boolean(courseHint)!==Boolean(termHint))return json({error:'课程专项同步请同时填写课程和学期；通用提取请将两项留空'},400);
  const timezone = parsed.timezone;
  if (!/^[A-Za-z_]+\/[A-Za-z0-9_+.-]+$/.test(timezone)) return json({ error: "时区格式无效" }, 400);
  const now = new Date();
  const expiresAt = new Date(now.getTime() + JOB_RETENTION_DAYS * DAY_MS);
  const summaryName = parsed.files.length === 1 ? parsed.files[0].filename : `${parsed.files.length} 个课程文件`;
  const summaryType = parsed.files.length === 1 ? parsed.files[0].contentType : "application/x-mail-assistant-bundle";
  const uploadedKeys = [];
  try {
    const statements = [];
    for (let fileIndex = 0; fileIndex < parsed.files.length; fileIndex += 1) {
      const file = parsed.files[fileIndex];
      let storageKey = null;
      if (env.UPLOADS) {
        storageKey = `schedule/${now.toISOString().slice(0, 10)}/${token}/${fileIndex}`;
        await env.UPLOADS.put(storageKey, file.bytes, { httpMetadata: { contentType: file.contentType } });
        uploadedKeys.push(storageKey);
      }
      statements.push(env.DB.prepare("INSERT INTO schedule_files(job_token,file_index,filename,content_type,size_bytes,storage_key) VALUES(?1,?2,?3,?4,?5,?6)")
        .bind(token, fileIndex, file.filename, file.contentType, file.bytes.byteLength, storageKey));
      if (!env.UPLOADS) {
        for (let offset = 0, chunkIndex = 0; offset < file.bytes.byteLength; offset += D1_CHUNK_BYTES, chunkIndex += 1) {
          statements.push(env.DB.prepare("INSERT INTO schedule_file_parts(job_token,file_index,chunk_index,data) VALUES(?1,?2,?3,?4)")
            .bind(token, fileIndex, chunkIndex, file.bytes.slice(offset, Math.min(file.bytes.byteLength, offset + D1_CHUNK_BYTES))));
        }
      }
    }
    await env.DB.batch(statements);
    await env.DB.prepare(`INSERT INTO schedule_uploads
      (token,access_token,object_key,filename,content_type,size_bytes,course_hint,term_hint,timezone,status,created_at,expires_at)
      VALUES(?1,?2,?3,?4,?5,?6,?7,?8,?9,'cloud_pending',?10,?11)`)
      .bind(token, accessToken, objectKey, summaryName, summaryType, totalSize, courseHint || null, termHint || null, timezone, now.toISOString(), expiresAt.toISOString()).run();
    await env.DB.prepare("UPDATE schedule_access_links SET last_used_at=?1 WHERE token=?2").bind(now.toISOString(), accessToken).run();
  } catch (error) {
    if (env.UPLOADS) for (const key of uploadedKeys) await env.UPLOADS.delete(key);
    await deleteStoredFiles(env, token, objectKey);
    throw error;
  }
  await enqueueSchedule(env,token);
  return json({ token, file_count: parsed.files.length, status_url: `${url.origin}/schedule/${token}` }, 201);
}

async function schedulePage(env, token) {
  await ensureScheduleSchema(env);
  if (!validToken(token)) return html("<h1>链接无效</h1>", 404);
  const row = await env.DB.prepare(`SELECT token,filename,course_hint,term_hint,timezone,status,preview_json,selected_json,result_json,error,created_at,expires_at FROM schedule_uploads WHERE token=?1`).bind(token).first();
  if (!row) return html("<h1>任务不存在</h1><p>链接无效或记录已经清理。</p>", 404);
  if (row.expires_at < new Date().toISOString()) return html("<h1>任务已过期</h1><p>课程任务保留 30 天。</p>", 410);
  return cloudSchedulePage(env,row);
}

async function confirmSchedule(request, env, token) {
  await ensureScheduleSchema(env);
  const row = await env.DB.prepare("SELECT status,preview_json FROM schedule_uploads WHERE token=?1 AND expires_at>?2").bind(token, new Date().toISOString()).first();
  if (!row) return html("<h1>任务无效或已过期</h1>", 404);
  return confirmCloudSchedule(request,env,token,row);
}

async function scheduleFiles(env, token, url) {
  await ensureScheduleSchema(env);
  const upload = await env.DB.prepare("SELECT filename,content_type,size_bytes,status FROM schedule_uploads WHERE token=?1").bind(token).first();
  if (!upload || !["pending", "processing"].includes(upload.status)) return json({ error: "files_unavailable" }, 404);
  const result = await env.DB.prepare("SELECT file_index,filename,content_type,size_bytes FROM schedule_files WHERE job_token=?1 ORDER BY file_index").bind(token).all();
  const files = (result.results || []).length ? result.results : [{
    file_index: 0, filename: upload.filename, content_type: upload.content_type, size_bytes: upload.size_bytes,
  }];
  return json({ files: files.map((file) => ({
    ...file, download_url: `${url.origin}/api/schedules/file/${token}/${file.file_index}`,
  })) });
}

export async function scheduleFile(env, token, requestedIndex = null) {
  await ensureScheduleSchema(env);
  const row = await env.DB.prepare("SELECT object_key,filename,content_type,status FROM schedule_uploads WHERE token=?1").bind(token).first();
  if (!row || !["pending", "processing", "cloud_pending", "cloud_processing"].includes(row.status) || !row.object_key) return json({ error: "file_unavailable" }, 404);
  let body;
  let size;
  let filename = row.filename;
  let contentType = row.content_type || "application/pdf";
  const index = requestedIndex == null ? 0 : Number(requestedIndex);
  if (!Number.isInteger(index) || index < 0 || index >= MAX_FILES) return json({ error: "invalid_file_index" }, 400);
  const file = await env.DB.prepare("SELECT filename,content_type,size_bytes,storage_key FROM schedule_files WHERE job_token=?1 AND file_index=?2").bind(token, index).first();
  if (file) {
    filename = file.filename;
    contentType = file.content_type;
    if (file.storage_key) {
      if (!env.UPLOADS) return json({ error: "storage_binding_missing" }, 503);
      const object = await env.UPLOADS.get(file.storage_key);
      if (!object) return json({ error: "file_missing" }, 404);
      body = object.body;
      size = object.size;
    } else {
      const result = await env.DB.prepare("SELECT data FROM schedule_file_parts WHERE job_token=?1 AND file_index=?2 ORDER BY chunk_index").bind(token, index).all();
      if (!(result.results || []).length) return json({ error: "file_missing" }, 404);
      body = new Blob(result.results.map((item) => item.data instanceof ArrayBuffer ? item.data : new Uint8Array(item.data)));
      size = body.size;
    }
  } else if (requestedIndex != null && index !== 0) {
    return json({ error: "file_missing" }, 404);
  } else if (row.object_key.startsWith("d1:")) {
    const result = await env.DB.prepare("SELECT data FROM schedule_file_chunks WHERE job_token=?1 ORDER BY chunk_index").bind(token).all();
    if (!(result.results || []).length) return json({ error: "file_missing" }, 404);
    const parts = result.results.map((item) => item.data instanceof ArrayBuffer
      ? item.data : new Uint8Array(item.data));
    body = new Blob(parts);
    size = body.size;
  } else {
    if (!env.UPLOADS) return json({ error: "storage_binding_missing" }, 503);
    const object = await env.UPLOADS.get(row.object_key);
    if (!object) return json({ error: "file_missing" }, 404);
    body = object.body;
    size = object.size;
  }
  return new Response(body, { headers: { "content-type": contentType, "content-length": String(size), "content-disposition": `attachment; filename="${String(filename).replace(/["\\\r\n]/g, "_")}"`, "cache-control": "no-store", "x-content-type-options": "nosniff" } });
}

export async function cleanupScheduleRetention(env, now = new Date()) {
  await ensureScheduleSchema(env);
  const expired = await env.DB.prepare("SELECT token,object_key FROM schedule_uploads WHERE (expires_at<?1 OR status IN ('cloud_preview','cloud_failed','cloud_completed')) AND object_key IS NOT NULL").bind(now.toISOString()).all();
  let deletedObjects = 0;
  for (const row of expired.results || []) {
    deletedObjects += await deleteStoredFiles(env, row.token, row.object_key);
    await env.DB.prepare('UPDATE schedule_uploads SET object_key=NULL WHERE token=?1').bind(row.token).run();
  }
  const results = await env.DB.batch([
    env.DB.prepare("DELETE FROM schedule_uploads WHERE expires_at<?1").bind(now.toISOString()),
    env.DB.prepare("DELETE FROM schedule_access_links WHERE expires_at<?1").bind(now.toISOString()),
  ]);
  return { operations: results.length, deletedObjects };
}

export async function handleScheduleRoute(request, env, url, isAuthorized) {
  const accessMatch = url.pathname.match(/^\/s\/([A-Za-z0-9_-]{32})$/);
  if (accessMatch && request.method === "GET") return uploadPage(env, accessMatch[1]);
  const uploadMatch = url.pathname.match(/^\/s\/([A-Za-z0-9_-]{32})\/upload$/);
  if (uploadMatch && request.method === "POST") return receiveUpload(request, env, uploadMatch[1], url);
  const scheduleMatch = url.pathname.match(/^\/schedule\/([A-Za-z0-9_-]{32})$/);
  if (scheduleMatch && request.method === "GET") return schedulePage(env, scheduleMatch[1]);
  const confirmMatch = url.pathname.match(/^\/schedule\/([A-Za-z0-9_-]{32})\/confirm$/);
  if (confirmMatch && request.method === "POST") return confirmSchedule(request, env, confirmMatch[1]);
  if (!url.pathname.startsWith("/api/schedules/")) return null;
  if (!isAuthorized) return json({ error: "unauthorized" }, 401);
  if (url.pathname === "/api/schedules/access-link" && request.method === "POST") return createAccessLink(env, url);
  // Hard server-side fence: no Mac can claim/write any course job after cutover.
  if(['/api/schedules/pull','/api/schedules/confirmed'].includes(url.pathname))return json({schedules:[],executor:'cloud'});
  if(['/api/schedules/claim','/api/schedules/apply-claim','/api/schedules/result','/api/schedules/complete'].includes(url.pathname))return json({claimed:0,updated:0,error:'moved_to_cloud'},409);
  const filesMatch = url.pathname.match(/^\/api\/schedules\/files\/([A-Za-z0-9_-]{32})$/);
  if (filesMatch && request.method === "GET") return scheduleFiles(env, filesMatch[1], url);
  const indexedFileMatch = url.pathname.match(/^\/api\/schedules\/file\/([A-Za-z0-9_-]{32})\/(\d+)$/);
  if (indexedFileMatch && request.method === "GET") return scheduleFile(env, indexedFileMatch[1], indexedFileMatch[2]);
  const fileMatch = url.pathname.match(/^\/api\/schedules\/file\/([A-Za-z0-9_-]{32})$/);
  if (fileMatch && request.method === "GET") return scheduleFile(env, fileMatch[1]);
  return json({ error: "not_found" }, 404);
}

export const scheduleTestHelpers = { MAX_UPLOAD_BYTES, MAX_FILES, validToken, detectInputType, cleanFilename };
