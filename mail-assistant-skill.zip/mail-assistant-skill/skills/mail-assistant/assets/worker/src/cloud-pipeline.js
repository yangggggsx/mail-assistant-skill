// Direct provider ingestion. Classification is persisted before delivery; retries never
// need Apple Mail. Mac is a downstream consumer for Apple Calendar/Reminders only.
import {ensureCloudMailSchema, syncAllCloudMail} from './cloud-mail.js';
import {ensureMigrationSchema, readObservation, classifyProbe} from './cloud-migration.js';
import {ensureDelivery, enqueueDelivery, drainDelivery} from './delivery-queue.js';
import {otpOnly,applyPolicy} from './classification-policy.js';
import {notificationContent} from './notification-format.js';
import {ensureCalendar} from './outlook-calendar-auth.js';

import {ORIGIN} from './deployment-config.js';
const json=(v,s=200)=>new Response(JSON.stringify(v),{status:s,headers:{'content-type':'application/json','cache-control':'no-store'}});
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const token=()=>btoa(String.fromCharCode(...crypto.getRandomValues(new Uint8Array(24)))).replaceAll('+','-').replaceAll('/','_');

export async function ensurePipeline(env) {
  await ensureCloudMailSchema(env);await ensureMigrationSchema(env);await ensureDelivery(env);
  await ensureCalendar(env);
  await env.DB.batch([
    env.DB.prepare(`CREATE TABLE IF NOT EXISTS local_digest_pending(message_key TEXT PRIMARY KEY,subject TEXT,sender TEXT,classification_json TEXT,original_url TEXT,feedback_token TEXT,created_at TEXT,digest_token TEXT)`),
    env.DB.prepare(`CREATE TABLE IF NOT EXISTS digest_slots(slot TEXT PRIMARY KEY,digest_token TEXT NOT NULL)`),
    env.DB.prepare(`CREATE TABLE IF NOT EXISTS cloud_pipeline_config(id INTEGER PRIMARY KEY CHECK(id=1),enabled INTEGER NOT NULL DEFAULT 0,cutover TEXT,lease_token TEXT,lease_until TEXT,last_run TEXT,last_error TEXT)`),
    env.DB.prepare('INSERT OR IGNORE INTO cloud_pipeline_config(id) VALUES(1)'),
    env.DB.prepare(`CREATE TABLE IF NOT EXISTS cloud_processing(observation_id INTEGER PRIMARY KEY,status TEXT NOT NULL,attempts INTEGER NOT NULL DEFAULT 0,next_at TEXT NOT NULL,error_code TEXT)`),
    env.DB.prepare(`CREATE TABLE IF NOT EXISTS cloud_messages(seq INTEGER PRIMARY KEY AUTOINCREMENT,message_key TEXT NOT NULL UNIQUE,observation_id INTEGER NOT NULL,
      message_id TEXT,account_email TEXT,sender TEXT,subject TEXT,received_at TEXT,body TEXT,original_url TEXT,
      classification_json TEXT NOT NULL,usage_json TEXT NOT NULL,feedback_token TEXT NOT NULL,created_at TEXT NOT NULL,disposition TEXT NOT NULL DEFAULT 'ready',digest_token TEXT)`),
  ]);
}

export function verificationOnly(mail) {
  return otpOnly(mail);
}
export function disposition(c) {
  if(['verification_code','verification_success'].includes(c.mail_type) && c.delivery_recommendation==='suppress') return 'suppressed';
  if(['newsletter','spam'].includes(c.category)) return 'digest';
  if(c.category==='urgent' && c.confidence<.82 || c.category==='important' && c.confidence<.72) return 'review';
  return 'notify';
}
export function notification(mail,c,t,directUrl='',calendarEnabled=false) {
  const base=ORIGIN+'/f/'+t;
  const links=[['打开原邮件','/original'],['查看中文翻译','/translate'],['反馈/改分类',''],['复制到 AI','/copy'],['加入待办','/todo'],...(calendarEnabled?[['加入日程','/calendar']]:[])]
    .map(([label,path])=>`<a href="${base+path}">${label}</a>`).join(' ｜ ');
  const suffix='\n\n'+links;
  const content=notificationContent(mail,c);
  const badge=({urgent:'紧急',important:'重要'})[c.importance]||'';
  let lead=Array.from(content.lead),details=[...new Set(content.details)].filter(x=>x!==content.lead);
  let source=Array.from(content.source);
  const render=()=>`<b>${esc(lead.join(''))}</b>`+(details.length?'\n'+details.map(esc).join('\n'):'')+'\n来源：'+esc(source.join(''))+suffix;
  // Preserve all links and complete HTML entities/tags; discard background first.
  while(render().length>1024&&details.length)details.pop();
  while(render().length>1024&&lead.length>1)lead.pop();
  while(render().length>1024&&source.length)source.pop();
  return {title:`【${content.label}${badge?'｜'+badge:''}】${content.title}`.slice(0,250),message:render(),priority:c.category==='urgent'?1:0,html:true};
}

export async function processObservation(env,o,{reader=readObservation,classifier=classifyProbe}={}) {
  let saved=await env.DB.prepare('SELECT * FROM cloud_messages WHERE observation_id=?1').bind(o.id).first();
  if(!saved) {
    const mail=await reader(env,o);
    if(mail.matched_legacy || await env.DB.prepare('SELECT 1 FROM cloud_messages WHERE message_key=?1').bind(mail.message_key).first()) return 'duplicate';
    const isOtp=verificationOnly(mail);
    const result=isOtp?{classification:{category:'normal',importance:'normal',mail_type:'verification_code',action_required:false,delivery_recommendation:'suppress',confidence:.99,
      summary:'一次性验证码（静默处理）',reason:'验证码规则',suggested_action:'无需推送',calendar:{candidate:false,events:[]}},usage:{}}:await classifier(env,mail);
    result.classification=applyPolicy(mail,result.classification);
    const t=token(),now=new Date().toISOString();
    // Atomic save of the classification and its permanent action link.
    await env.DB.batch([
      env.DB.prepare(`INSERT OR IGNORE INTO cloud_messages(message_key,observation_id,message_id,account_email,sender,subject,received_at,body,original_url,classification_json,usage_json,feedback_token,created_at)
        VALUES(?1,?2,?3,?4,?5,?6,?7,?8,?9,?10,?11,?12,?13)`).bind(mail.message_key,o.id,mail.message_id,mail.account_email,mail.sender||'',mail.subject||'',mail.received_at,mail.body,mail.original_url,JSON.stringify(result.classification),JSON.stringify(result.usage),t,now),
      env.DB.prepare(`INSERT OR IGNORE INTO feedback_links(token,message_key,created_at,expires_at,mail_url) VALUES(?1,?2,?3,?4,?5)`)
        .bind(t,mail.message_key,now,new Date(Date.now()+365*86400000).toISOString(),mail.original_url||null),
    ]);
    saved=await env.DB.prepare('SELECT * FROM cloud_messages WHERE message_key=?1').bind(mail.message_key).first();
  }
  const c=JSON.parse(saved.classification_json),kind=disposition(c);
  if(kind==='notify') {
    const calendarReady=Boolean(await env.DB.prepare("SELECT 1 FROM outlook_calendar_connection WHERE id=1 AND status='ready' AND calendar_id IS NOT NULL").first());
    await enqueueDelivery(env,'mail:'+saved.message_key,notification(saved,c,saved.feedback_token,'',calendarReady));
  }
  await env.DB.prepare('UPDATE cloud_messages SET disposition=?1 WHERE message_key=?2').bind(kind,saved.message_key).run();
  return kind;
}

export async function queueCloudDigest(env,now=new Date()) {
  // Same morning/evening cadence as the local digest; only cloud-owned records.
  const parts=Object.fromEntries(new Intl.DateTimeFormat('en-CA',{timeZone:'America/Chicago',year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',hourCycle:'h23'}).formatToParts(now).map(x=>[x.type,x.value]));
  if(!['08','16'].includes(parts.hour)) return;
  const slot=`${parts.year}-${parts.month}-${parts.day}-${parts.hour}`;
  if(now.getUTCMinutes()<10 || await env.DB.prepare('SELECT slot FROM digest_slots WHERE slot=?1').bind(slot).first()) return;
  const rows=(await env.DB.prepare(`SELECT message_key,subject,sender,classification_json,original_url,feedback_token,created_at,'cloud' AS source FROM cloud_messages WHERE disposition IN ('digest','review') AND digest_token IS NULL
    UNION ALL SELECT message_key,subject,sender,classification_json,original_url,feedback_token,created_at,'local' AS source FROM local_digest_pending l WHERE digest_token IS NULL AND NOT EXISTS(SELECT 1 FROM cloud_messages c WHERE c.message_key=l.message_key)
    ORDER BY created_at LIMIT 40`).all()).results||[];
  if(!rows.length) return;
  // Stable batch identity closes the save/queue crash gap.
  const batch=rows.map(r=>r.message_key).join('|');
  const hash=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(batch))),b=>b.toString(16).padStart(2,'0')).join('');
  const t=hash.slice(0,32),created=now.toISOString(),expires=new Date(now.getTime()+7*86400000).toISOString();
  const statements=[env.DB.prepare('INSERT OR IGNORE INTO digest_pages VALUES(?1,?2,?3)').bind(t,created,expires)];
  for(const [i,r] of rows.entries()) {
    const c=JSON.parse(r.classification_json);
    statements.push(env.DB.prepare(`INSERT INTO digest_items(digest_token,position,message_key,subject,sender,category,summary,mail_url,feedback_token)
      SELECT ?1,?2,?3,?4,?5,?6,?7,?8,?9 WHERE NOT EXISTS(SELECT 1 FROM digest_items WHERE digest_token=?1 AND message_key=?3)`)
      .bind(t,i+1,r.message_key,r.subject,r.sender,c.category,c.summary,r.original_url,r.feedback_token));
  }
  const payload={title:'邮件简报',message:`本批 ${rows.length} 封订阅、垃圾候选或待核对邮件，含已同步的垃圾箱复查结果。原邮件均保留。`,priority:0,html:false,url:ORIGIN+'/d/'+t,url_title:'查看简报'};
  statements.push(env.DB.prepare("INSERT OR IGNORE INTO delivery_queue(delivery_key,payload_json,status,next_at,created_at) VALUES(?1,?2,'pending',?3,?3)").bind('digest:'+hash,JSON.stringify(payload),created));
  statements.push(...rows.map(r=>env.DB.prepare(`UPDATE ${r.source==='local'?'local_digest_pending':'cloud_messages'} SET digest_token=?1 WHERE message_key=?2`).bind(t,r.message_key)));
  statements.push(env.DB.prepare('INSERT INTO digest_slots(slot,digest_token) VALUES(?1,?2)').bind(slot,t));
  // All-or-nothing: new arrivals cannot re-bundle an old batch after a crash.
  await env.DB.batch(statements);
}

export async function collectLocalDigest(env,items) {
  await ensurePipeline(env);
  const now=new Date().toISOString(),expires=new Date(Date.now()+365*86400000).toISOString(),statements=[];
  for(const item of items) {
    const t=token();
    statements.push(env.DB.prepare(`INSERT OR IGNORE INTO local_digest_pending(message_key,subject,sender,classification_json,original_url,feedback_token,created_at) VALUES(?1,?2,?3,?4,?5,?6,?7)`)
      .bind(item.messageKey,item.subject,item.sender,JSON.stringify({category:item.category,summary:item.summary}),item.mailUrl||null,t,now));
    statements.push(env.DB.prepare(`INSERT OR IGNORE INTO feedback_links(token,message_key,created_at,expires_at,mail_url) SELECT feedback_token,message_key,?2,?3,original_url FROM local_digest_pending WHERE message_key=?1`).bind(item.messageKey,now,expires));
  }
  await env.DB.batch(statements);
  return {queued:true,count:items.length};
}

export async function runCloudPipeline(env,{sync=syncAllCloudMail,reader=readObservation,classifier=classifyProbe}={}) {
  await ensurePipeline(env);
  const now=new Date().toISOString(),claim=crypto.randomUUID();
  const lock=await env.DB.prepare(`UPDATE cloud_pipeline_config SET lease_token=?1,lease_until=?2 WHERE id=1 AND enabled=1 AND (lease_until IS NULL OR lease_until<?3)`)
    .bind(claim,new Date(Date.now()+10*60000).toISOString(),now).run();
  if(!lock.meta?.changes) return {skipped:true};
  let processed=0;
  try {
    const config=await env.DB.prepare('SELECT cutover FROM cloud_pipeline_config WHERE id=1').first();
    const syncResults=await sync(env);
    await env.DB.prepare(`INSERT OR IGNORE INTO cloud_processing(observation_id,status,next_at)
      SELECT id,'pending',?1 FROM cloud_mail_observations WHERE received_at>=?2`).bind(now,config.cutover).run();
    // Failures are isolated; no unbounded retries or catch-up API bill.
    const rows=await env.DB.prepare(`SELECT o.*,p.attempts FROM cloud_processing p JOIN cloud_mail_observations o ON o.id=p.observation_id
      WHERE p.status IN ('pending','retry') AND p.next_at<=?1 ORDER BY o.id LIMIT 5`).bind(now).all();
    const budget=await env.DB.prepare('SELECT count(*) AS n FROM cloud_messages WHERE created_at>=?1').bind(now.slice(0,10)).first();
    for(const o of (rows.results||[]).slice(0,Math.max(0,300-budget.n))) {
      await env.DB.prepare('UPDATE cloud_processing SET attempts=attempts+1 WHERE observation_id=?1').bind(o.id).run();
      try {
        const result=await processObservation(env,o,{reader,classifier});
        await env.DB.prepare('UPDATE cloud_processing SET status=?1,error_code=NULL WHERE observation_id=?2').bind(result,o.id).run();processed++;
      } catch {
        await env.DB.prepare('UPDATE cloud_processing SET status=?1,next_at=?2,error_code=?3 WHERE observation_id=?4')
          .bind(o.attempts>=5?'blocked':'retry',new Date(Date.now()+Math.min(3600000,300000*2**o.attempts)).toISOString(),'provider_or_classification_failed',o.id).run();
      }
    }
    await queueCloudDigest(env);
    await env.DB.prepare("UPDATE cloud_messages SET body='' WHERE created_at<?1 AND body<>''").bind(new Date(Date.now()-7*86400000).toISOString()).run();
    await env.DB.prepare('UPDATE cloud_pipeline_config SET last_run=?1,last_error=?2 WHERE id=1 AND lease_token=?3')
      .bind(new Date().toISOString(),syncResults?.some(x=>!x.ok)?'mailbox_sync_partial_failure':null,claim).run();
    return {processed};
  } finally {
    await env.DB.prepare('UPDATE cloud_pipeline_config SET lease_token=NULL,lease_until=NULL WHERE id=1 AND lease_token=?1').bind(claim).run();
  }
}

export async function handlePipeline(request,env,url,authorized) {
  if(!url.pathname.startsWith('/api/cloud/pipeline/')) return null;
  if(!authorized) return json({error:'unauthorized'},401);
  await ensurePipeline(env);
  if(url.pathname==='/api/cloud/pipeline/junk/status' && request.method==='GET') {
    const control=await env.DB.prepare('SELECT * FROM cloud_junk_control WHERE id=1').first();
    const folders=await env.DB.prepare('SELECT email,folder,last_success_at,last_error FROM cloud_folder_cursors').all();
    return json({...control,folders:folders.results||[]});
  }
  if(url.pathname==='/api/cloud/pipeline/junk/activate' && request.method==='POST') {
    let b;try{b=await request.json();}catch{return json({error:'json'},400);}
    if(b.confirm_outlook_mac_junk_stopped!==true || !Number.isFinite(Date.parse(b.cutover)) || Math.abs(Date.now()-Date.parse(b.cutover))>3600000)return json({error:'handoff_confirmation_required'},400);
    await env.DB.prepare('UPDATE cloud_junk_control SET enabled=1,cutover=?1 WHERE id=1 AND enabled=0').bind(new Date(b.cutover).toISOString()).run();
    return json({enabled:true});
  }
  if(url.pathname.endsWith('/status') && request.method==='GET') {
    const config=await env.DB.prepare('SELECT enabled,cutover,last_run,last_error FROM cloud_pipeline_config WHERE id=1').first();
    const counts=await env.DB.prepare('SELECT status,count(*) AS n FROM cloud_processing GROUP BY status').all();
    return json({...config,counts:counts.results||[],scope:'gmail_outlook_inbox',daily_message_limit:300});
  }
  if(url.pathname.endsWith('/messages') && request.method==='GET') {
    const after=Number(url.searchParams.get('after')||0);
    if(!Number.isSafeInteger(after)||after<0) return json({error:'cursor'},400);
    const rows=await env.DB.prepare('SELECT * FROM cloud_messages WHERE seq>?1 ORDER BY seq LIMIT 50').bind(after).all();
    return json({messages:rows.results||[]});
  }
  if(url.pathname.endsWith('/activate') && request.method==='POST') {
    const b=await request.json();
    if(b.confirm_mac_inboxes_stopped!==true || !Number.isFinite(Date.parse(b.cutover)) || Math.abs(Date.now()-Date.parse(b.cutover))>3600000) return json({error:'confirmation'},400);
    const accounts=await env.DB.prepare("SELECT count(*) AS n FROM cloud_accounts WHERE status='active' AND last_error IS NULL").first();
    if(!accounts.n) return json({error:'no_healthy_accounts'},409);
    await env.DB.prepare('UPDATE cloud_pipeline_config SET enabled=1,cutover=?1 WHERE id=1 AND enabled=0').bind(new Date(b.cutover).toISOString()).run();
    await env.DB.prepare("UPDATE cloud_accounts SET shadow_mode=0 WHERE status='active'").run();
    return json({enabled:true});
  }
  if(url.pathname.endsWith('/run') && request.method==='POST') {
    const result=await runCloudPipeline(env);await drainDelivery(env);return json(result);
  }
  return json({error:'not_found'},404);
}
