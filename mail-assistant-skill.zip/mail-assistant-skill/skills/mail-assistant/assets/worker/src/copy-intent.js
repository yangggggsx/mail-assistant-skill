// Local suggestions only: no extra model request, private question storage, or inferred intent.
export function questionSuggestions(mail={}){
 let c={};try{c=JSON.parse(mail.classification_json||'{}');}catch{}
 const text=[mail.subject,c.summary].filter(Boolean).join(' ');
 if(c.notification?.label==='退款售后'||/退款|refund/i.test(text))return ['这笔退款现在是什么状态，还需要我做什么？','邮件有没有说明到账时间？什么时候适合跟进？','帮我起草一封询问退款进度的邮件。'];
 if(c.mail_type==='shipping')return ['包裹现在在哪里，我需要去取吗？','有哪些取件地点、取件码或截止时间需要注意？','如果投递出现问题，我应该怎么跟进？'];
 if(c.mail_type==='academic_result')return ['这封邮件公布了什么成绩或评分信息？','有没有复核或申诉要求，需要我做什么？','如果要判断对总成绩的影响，还缺哪些信息？'];
 if(c.mail_type==='billing_notice'||c.mail_type==='transaction')return ['这笔费用是什么，是否需要我付款？','要核对金额是否正确，还需要哪些资料？','帮我整理需要向商家确认的问题。'];
 if(c.mail_type==='calendar_event')return ['活动的时间、时区和地点分别是什么？','这封邮件是否涉及取消或改期？','我参加前需要准备什么？'];
 if(c.mail_type==='application_update')return ['申请目前处于什么阶段？','我还需要提交什么材料，有明确期限吗？','帮我起草一封询问下一步安排的邮件。'];
 return ['这封邮件的重点是什么，是否需要我处理？','有哪些明确的下一步、截止时间或缺失信息？','帮我起草回复；如果我的立场不明确，请先问我。'];
}

export function composeQuestion(payload,question){
 const q=String(question||'').trim();
 if(!q)return payload;
 return '【我这次想问】\n'+q+'\n\n请优先回答这个问题，下面的通用分析要求只作补充。区分邮件明确事实、推测和一般建议；如果回答需要订单、附件、评分规则或我的个人背景等缺失资料，请指出并询问，不要编造。不要把我这次的目的当作长期偏好。\n\n'+payload;
}

export const copyIntentScript=`const composeQuestion=${composeQuestion.toString()};
const question=document.getElementById('question'),preview=document.getElementById('copy-preview');
const currentText=()=>composeQuestion(payload.value,question?.value||'');
function updatePreview(){if(preview)preview.value=currentText();}
if(question){question.addEventListener('input',updatePreview);payload.addEventListener('input',updatePreview);
 document.querySelectorAll('[data-question]').forEach(button=>button.addEventListener('click',()=>{question.value=button.dataset.question;updatePreview();question.focus();}));
 document.getElementById('clear-question').addEventListener('click',()=>{question.value='';updatePreview();});
 updatePreview();
}`;
