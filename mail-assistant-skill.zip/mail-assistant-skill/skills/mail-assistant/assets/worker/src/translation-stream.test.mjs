import test from 'node:test';
import assert from 'node:assert/strict';
import {readTranslationStream} from './translation-stream.js';
function response(events){
 const bytes=new TextEncoder().encode(events.map(e=>'data: '+JSON.stringify(e)+'\r\n\r\n').join(''));
 return new Response(new ReadableStream({start(c){for(let i=0;i<bytes.length;i+=7)c.enqueue(bytes.slice(i,i+7));c.close();}}));
}
test('SSE UTF-8 fragmentation produces partial before authoritative completion',async()=>{
 const partial=[];
 const result=await readTranslationStream(response([
  {type:'response.output_text.delta',delta:'中文<script>'},
  {type:'response.output_text.delta',delta:'第二段'},
  {type:'response.completed',response:{status:'completed',usage:{output_tokens:10}}}
 ]),async t=>partial.push(t));
 assert.equal(partial[0],'中文<script>');assert.equal(result.status,'completed');assert.equal(result.usage.output_tokens,10);
});
test('disconnect after partial is never successful',async()=>{
 await assert.rejects(readTranslationStream(response([{type:'response.output_text.delta',delta:'半截'}])),/未完整生成/);
});
test('incomplete stream preserves terminal reason',async()=>{
 const r=await readTranslationStream(response([{type:'response.incomplete',response:{status:'incomplete',incomplete_details:{reason:'max_output_tokens'}}}]));
 assert.equal(r.status,'incomplete');
});
