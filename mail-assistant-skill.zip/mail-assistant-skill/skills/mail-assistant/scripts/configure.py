#!/usr/bin/env python3
"""Copy the bundled Worker into a NEW directory and configure non-secret settings."""
import argparse
import json
from pathlib import Path
import re
import shutil
from urllib.parse import urlsplit
import uuid

SKILL = Path(__file__).resolve().parents[1]

def validate(c):
    required = set(json.loads((SKILL / 'assets/deployment.example.json').read_text()))
    if set(c) != required:
        raise ValueError('Configuration keys must exactly match deployment.example.json')
    if any(not isinstance(v, str) for v in c.values()):
        raise ValueError('All configuration values must be strings')
    for k in ('worker_name', 'database_name', 'realtime_queue', 'action_queue'):
        if not re.fullmatch(r'[a-z][a-z0-9-]{1,62}', c[k]):
            raise ValueError('Invalid resource name: ' + k)
    u = urlsplit(c['origin'])
    if u.scheme != 'https' or not u.hostname or u.username or u.password or u.port not in (None,443) or u.path not in ('','/') or u.query or u.fragment:
        raise ValueError('origin must be a bare HTTPS origin')
    if u.hostname.endswith(('.example.com', '.invalid', '.test')) or u.hostname == 'example.com':
        raise ValueError('Replace the example origin')
    if not re.fullmatch(r'[^\s@<>]+@[^\s@<>]+\.[^\s@<>]+', c['calendar_account']) or c['calendar_account'].endswith('@example.com'):
        raise ValueError('Set your intended Outlook calendar account')
    if uuid.UUID(c['database_id']).int == 0:
        raise ValueError('Set the D1 database ID returned by Cloudflare')
    if not re.fullmatch(r'[a-zA-Z0-9._:-]+', c['model']) or c['model'].startswith('SET_'):
        raise ValueError('Select an available model supporting structured output and file/image input')
    google = [c[k] for k in ('gmail_topic','gmail_subscription','gmail_service_account')]
    if any(google) and not all(google):
        raise ValueError('Provide all three Gmail push fields, or leave all empty for polling')
    if all(google):
        if not re.fullmatch(r'projects/[a-z0-9-]+/topics/[A-Za-z0-9._~-]+',google[0]) or not re.fullmatch(r'projects/[a-z0-9-]+/subscriptions/[A-Za-z0-9._~-]+',google[1]) or not re.fullmatch(r'[a-zA-Z0-9._-]+@[a-z0-9.-]+\.iam\.gserviceaccount\.com',google[2]):
            raise ValueError('Invalid Gmail Pub/Sub configuration')
    c = dict(c)
    c['origin'] = c['origin'].rstrip('/')
    c['calendar_account'] = c['calendar_account'].strip().lower()
    return c

def configure(config_path, output):
    c = validate(json.loads(Path(config_path).read_text()))
    output = Path(output).resolve()
    if output.exists():
        raise ValueError('Destination already exists; refusing to overwrite')
    shutil.copytree(SKILL / 'assets/worker', output, ignore=shutil.ignore_patterns('node_modules','.wrangler','__pycache__'))
    q = json.dumps
    (output/'src/deployment-config.js').write_text('// Generated non-secret deployment settings.\nexport const ORIGIN = '+q(c['origin'])+';\nexport const CALENDAR_ACCOUNT = '+q(c['calendar_account'])+';\n')
    lines = ['name = '+q(c['worker_name']), 'main = "src/index.js"', 'compatibility_date = "2026-08-23"', '', '[vars]', 'MAIL_AI_MODEL = '+q(c['model'])]
    for key, field in [('GMAIL_PUBSUB_TOPIC','gmail_topic'),('GMAIL_PUBSUB_SUBSCRIPTION','gmail_subscription'),('GMAIL_PUSH_SERVICE_ACCOUNT','gmail_service_account')]:
        lines.append(key+' = '+q(c[field]))
    for binding, field in [('REALTIME_QUEUE','realtime_queue'),('ACTION_QUEUE','action_queue')]:
        lines += ['', '[[queues.producers]]', 'binding = '+q(binding), 'queue = '+q(c[field])]
    for field, concurrency in [('realtime_queue',1),('action_queue',2)]:
        lines += ['', '[[queues.consumers]]', 'queue = '+q(c[field]), 'max_batch_size = 1', 'max_batch_timeout = 1', 'max_retries = 5', 'max_concurrency = '+str(concurrency), 'retry_delay = 30']
    lines += ['', '[triggers]', 'crons = ["*/5 * * * *"]', '', '[[d1_databases]]', 'binding = "DB"', 'database_name = '+q(c['database_name']), 'database_id = '+q(c['database_id']), '', '[images]', 'binding = "IMAGES"', '']
    (output/'wrangler.toml').write_text('\n'.join(lines))
    (output/'.gitignore').write_text('node_modules/\n.wrangler/\n.dev.vars*\n.env*\n*.log\n')
    return output

if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--config', required=True)
    p.add_argument('--output', required=True)
    a = p.parse_args()
    try:
        print(configure(a.config, a.output))
    except (ValueError, OSError) as e:
        p.exit(1, str(e)+'\n')
