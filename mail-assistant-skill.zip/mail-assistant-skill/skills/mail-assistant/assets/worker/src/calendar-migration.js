// Admin-only, copy-and-verify migration. Never deletes source calendar events.
import {ensureCalendar,calendarAccess,calendarGraph,CALENDAR_ACCOUNT,CALENDAR_NAME} from './outlook-calendar-auth.js';
const json=(v,s=200)=>Response.json(v,{status:s,headers:{'cache-control':'no-store'}});
export async function ensureMigration(env){
 await ensureCalendar(env);
 await env.DB.prepare(`CREATE TABLE IF NOT EXISTS calendar_course_migrations(source_key TEXT PRIMARY KEY,source_uid TEXT NOT NULL,course_key TEXT,item_key TEXT,legacy_payload_json TEXT,payload_json TEXT NOT NULL,calendar_id TEXT NOT NULL,transaction_id TEXT NOT NULL UNIQUE,event_id TEXT,status TEXT NOT NULL,created_at TEXT NOT NULL,verified_at TEXT,error TEXT)`).run();
}
export function migrationPayload(b){
 if(b.confirm!==true||b.source_calendar!=='课程安排'||b.disable_reminders!==true)throw Error('confirmation_required');
 if(!/^[a-f0-9]{64}$/.test(b.source_key||'')||typeof b.source_uid!=='string'||!b.source_uid||b.source_uid.length>300)throw Error('invalid_source');
 const e=b.event;
 if(!e||typeof e.title!=='string'||!e.title.trim()||e.title.length>300||typeof e.notes!=='string'||e.notes.length>20000||typeof e.location!=='string'||e.location.length>1000||typeof e.all_day!=='boolean')throw Error('invalid_event');
 if(!['UTC','Central Standard Time'].includes(e.timezone))throw Error('invalid_timezone');
 const valid=v=>typeof v==='string'&&/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}$/.test(v)&&new Date(v+'Z').toISOString().slice(0,19)===v;
 if(!valid(e.start)||!valid(e.end)||e.end<=e.start)throw Error('invalid_dates');
 if(e.all_day&&(e.timezone!=='Central Standard Time'||!e.start.endsWith('T00:00:00')||!e.end.endsWith('T00:00:00')))throw Error('invalid_all_day');
 for(const k of ['course_key','item_key'])if(b[k]!=null&&(typeof b[k]!=='string'||b[k].length>300))throw Error('invalid_binding');
 if(b.legacy_payload!=null&&JSON.stringify(b.legacy_payload).length>20000)throw Error('invalid_binding');
 return {subject:e.title,start:{dateTime:e.start,timeZone:e.timezone},end:{dateTime:e.end,timeZone:e.timezone},isAllDay:e.all_day,location:{displayName:e.location},body:{contentType:'text',content:e.notes},isReminderOn:false,showAs:e.all_day?'free':'busy',sensitivity:'private'};
}
function matches(actual,wanted){
 const seconds=v=>String(v).replace(/\.\d+$/,'').replace(/Z$/,'');
 return actual.subject===wanted.subject&&actual.isAllDay===wanted.isAllDay&&actual.isReminderOn===false&&
  seconds(actual.start?.dateTime)===wanted.start.dateTime&&seconds(actual.end?.dateTime)===wanted.end.dateTime&&
  actual.start?.timeZone===wanted.start.timeZone&&actual.end?.timeZone===wanted.end.timeZone&&
  (actual.location?.displayName||'')===wanted.location.displayName;
}
export async function importCourse(env,b,{access=calendarAccess,graph=calendarGraph}={}){
 const payload=migrationPayload(b);
 const prior=await env.DB.prepare('SELECT status,event_id FROM calendar_course_migrations WHERE source_key=?1').bind(b.source_key).first();
 if(prior)return {duplicate:true,...prior};
 const {access:token,connection}=await access(env);
 if(connection.email!==CALENDAR_ACCOUNT||connection.status!=='ready'||!connection.calendar_id)throw Error('calendar_not_ready');
 const path='/me/calendars/'+encodeURIComponent(connection.calendar_id);
 const target=await graph(token,path+'?$select=id,name,canEdit');
 if(target.id!==connection.calendar_id||target.name!==CALENDAR_NAME||target.canEdit!==true)throw Error('calendar_target_changed');
 const transaction=crypto.randomUUID();
 const claim=await env.DB.prepare(`INSERT OR IGNORE INTO calendar_course_migrations(source_key,source_uid,course_key,item_key,legacy_payload_json,payload_json,calendar_id,transaction_id,status,created_at) VALUES(?1,?2,?3,?4,?5,?6,?7,?8,'submitting',?9)`)
  .bind(b.source_key,b.source_uid,b.course_key||null,b.item_key||null,b.legacy_payload?JSON.stringify(b.legacy_payload):null,JSON.stringify(payload),connection.calendar_id,transaction,new Date().toISOString()).run();
 if(!claim.meta?.changes)return {duplicate:true,status:'submitting'};
 let eventId=null,posted=false;
 try{
  const event=await graph(token,path+'/events',{method:'POST',body:{...payload,transactionId:transaction},responseTimezone:payload.start.timeZone});posted=true;
  if(!event.id)throw Error('missing_id');eventId=event.id;
  await env.DB.prepare("UPDATE calendar_course_migrations SET event_id=?1,status='created' WHERE source_key=?2").bind(eventId,b.source_key).run();
  // Read back in the source zone, not just trust the write acknowledgement.
  const check=await graph(token,path+'/events/'+encodeURIComponent(eventId),{responseTimezone:payload.start.timeZone});
  if(!matches(check,payload)||check.id!==eventId)throw Error('verification_failed');
  await env.DB.prepare("UPDATE calendar_course_migrations SET status='verified',verified_at=?1 WHERE source_key=?2").bind(new Date().toISOString(),b.source_key).run();
  return {status:'verified',event_id:eventId};
 }catch(e){
  const status=eventId?'needs_review':!posted&&[400,401,403,404,422,429].includes(e.httpStatus)?'failed':'uncertain';
  await env.DB.prepare('UPDATE calendar_course_migrations SET status=?1,error=?2 WHERE source_key=?3').bind(status,'migration_needs_review',b.source_key).run();
  return {status,event_id:eventId};
 }
}
export async function auditRecentSchedules(env,{access=calendarAccess,graph=calendarGraph}={}){
 const {access:token,connection}=await access(env);
 if(connection.email!==CALENDAR_ACCOUNT||connection.status!=='ready'||!connection.calendar_id)throw Error('calendar_not_ready');
 const path='/me/calendars/'+encodeURIComponent(connection.calendar_id);
 const calendar=await graph(token,path+'?$select=id,name,canEdit');
 if(calendar.id!==connection.calendar_id||calendar.name!==CALENDAR_NAME||calendar.canEdit!==true)throw Error('calendar_target_changed');
 const rows=(await env.DB.prepare("SELECT event_id,calendar_id,updated_at FROM cloud_course_bindings WHERE status='active' AND event_id IS NOT NULL ORDER BY updated_at DESC LIMIT 5").all()).results||[];
 const events=[];
 for(const row of rows){
  if(row.calendar_id!==connection.calendar_id){events.push({status:'different_calendar'});continue;}
  try{
   const e=await graph(token,path+'/events/'+encodeURIComponent(row.event_id)+'?$select=id,subject,start,end,webLink,isCancelled',{responseTimezone:'Central Standard Time'});
   events.push({status:'found',title:e.subject,start:e.start,end:e.end,cancelled:e.isCancelled,webLink:e.webLink});
  }catch(e){events.push({status:e.httpStatus===404?'missing':'read_failed'});}
 }
 return {account:connection.email,calendar:calendar.name,timezone:'America/Chicago',events};
}
export async function handleCourseMigration(request,env,url,authorized){
 if(!['/api/calendar/course-import','/api/calendar/course-import/status','/api/calendar/schedule-audit'].includes(url.pathname))return null;
 if(!authorized)return json({error:'unauthorized'},401);
 if(url.pathname.endsWith('/schedule-audit')){
  if(request.method!=='GET')return json({error:'method'},405);
  try{return json(await auditRecentSchedules(env));}catch{return json({error:'audit_unavailable'},503);}
 }
 await ensureMigration(env);
 if(request.method==='GET'&&url.pathname.endsWith('/status'))return json({counts:(await env.DB.prepare('SELECT status,count(*) count FROM calendar_course_migrations GROUP BY status').all()).results});
 if(request.method!=='POST'||url.pathname.endsWith('/status'))return json({error:'method'},405);
 let b;try{const raw=await request.text();if(raw.length>60000)throw Error();b=JSON.parse(raw);migrationPayload(b);}catch{return json({error:'invalid_migration'},400);}
 try{return json(await importCourse(env,b));}catch{return json({error:'migration_not_started'},503);}
}
