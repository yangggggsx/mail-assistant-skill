# Mail Assistant Skill

把云端邮件助手打包为可安装的 Codex skill，包含完整 Worker 源码、自动测试、配置生成器和部署/维护指南。

**安装 skill 不等于服务已上线。** 使用者需要自己的 Cloudflare、邮箱 OAuth、OpenAI 和 Pushover 配置。本仓库不包含生产密钥、邮箱内容、数据库备份或个人访问链接，也不会自动连接原作者的服务。

## 账号配置、通知渠道与邮箱转发

本项目需要自行部署和配置；安装 Skill 并不代表服务已经开通。使用前需要准备自己的 Cloudflare 账号、OpenAI API 密钥，以及 Gmail／Outlook 授权配置；日程功能还需要授权目标 Outlook 日历。账号注册、邮箱授权和部分验证步骤需要本人手动完成，具体操作见包内部署指南。

当前版本使用 **Pushover** 接收通知，需要配置自己的应用 Token 和用户 Key。通知渠道可以扩展到 **飞书等平台**：邮件分类、摘要和日程提取逻辑可以复用，但需要适配消息发送 API、认证方式、消息格式和操作链接，并调整快捷指令完成后的返回目标。**不是仅替换一个 API 地址就能直接使用。** 目前已实现的是 Pushover，飞书属于可扩展方向。

邮箱支持通过授权直接接入 Gmail／Outlook，**直接接入的邮箱不需要配置自动转发**。对于暂未直接支持的邮箱，可以考虑手动设置自动转发到已接入的邮箱，再由助手统一处理。转发是否可用取决于邮箱服务商及学校／公司的管理政策，可能需要验证收件地址。建议保留原邮件，并避免同一邮箱同时走直接接入和转发两条路线，以免重复处理。转发后的原邮件定位、发件人识别和垃圾邮件覆盖范围需要实际验证。

iPhone 提醒事项功能需要另行安装共享快捷指令，并选择自己的「邮件待办」列表。所有密钥和授权都应使用部署者自己的配置，不要沿用他人的服务地址或凭证。


## 能力

- Gmail / Outlook 增量收件、通知触发与定时补漏。
- 邮件类别 + 重要程度双维度分类，摘要、Pushover 推送和简报。
- 中文翻译保留链接，分类反馈，复制到 AI 的上下文与问题组织。
- 简洁行动待办，通过 iPhone 快捷指令写入 Apple 提醒事项并回传结果。
- 邮件、PDF 和图片提取会议、活动、截止日期等日程；支持 HEIC/HEIF。
- 可编辑预览，确认后由云端写入 Outlook 并核验；课程关联更新能力保留。

## 安装

下载仓库，或在已授权访问此私有仓库的环境中克隆：

```sh
git clone https://github.com/yangggggsx/mail-assistant-skill.git
```

将 `skills/mail-assistant` 整个目录复制到你的 Codex skills 目录（通常为 `~/.codex/skills/mail-assistant`），重新加载技能。不要覆盖已有同名技能而不先检查/备份。

示例调用：

> 使用 $mail-assistant，帮我在自己的 Cloudflare 账号部署邮件助手，先检查配置和费用，再授权连接邮箱。

> 使用 $mail-assistant，检查邮件推送延迟，先读取状态，不重发通知。

> 使用 $mail-assistant，调整日程提取逻辑，保留旧快捷指令兼容并运行测试。

## 结构

```text
skills/mail-assistant/
  SKILL.md
  agents/openai.yaml
  references/                 部署、运行、架构、快捷指令
  scripts/configure.py        在新目录生成部署副本
  scripts/test_configure.py   配置生成器测试
  assets/deployment.example.json
  assets/worker/              完整云端源代码、测试和锁文件
```

[部署指南](skills/mail-assistant/references/deployment.md) · [云端架构](skills/mail-assistant/references/architecture.md) · [快捷指令配置](skills/mail-assistant/references/shortcuts.md)

## 验证

```sh
python3 skills/mail-assistant/scripts/test_configure.py
cd skills/mail-assistant/assets/worker
npm ci
npm test
```

需要 Node.js 24（测试使用 `node:sqlite`）。所有单元测试均使用本地内存数据库或模拟服务；不会发送真实邮件/推送或创建真实日程。新账户仍需完成真实 OAuth、资源开通和端到端验收。

提醒事项快捷指令可通过 [iCloud 共享链接](https://www.icloud.com/shortcuts/7a610bc2e6524944ad34449f66d94e11) 安装。安装后必须在“添加提醒事项”动作中重新选择自己的「邮件待办」列表，详见快捷指令配置文档。PDF/图片上传快捷指令仍需按文档配置。

本包不包含旧 Mac 常驻程序、私人历史数据和一次性迁移备份。云端已迁移的能力以源码为准。尚未选择开源许可证，仓库目前用于私有保存。详细验证记录见 [VALIDATION.md](VALIDATION.md)。
