import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {composeQuestion,questionSuggestions} from './copy-intent.js';
import {copyLaunchScript,aiLaunchers} from './copy-launch.js';
import {toolPage} from './mail-tools.js';
test('questions are optional and preserve original editable mail',()=>{
 assert.equal(composeQuestion('original','  '),'original');
 const text=composeQuestion('original','想核对退款金额');
 assert.match(text,/想核对退款金额/);assert.ok(text.endsWith('original'));assert.match(text,/缺失资料/);
});
test('contextual directions distinguish refunds, shipping and grades without claiming facts',()=>{
 assert.match(questionSuggestions({subject:'Refund started'})[0],/退款/);
 assert.match(questionSuggestions({classification_json:'{"mail_type":"shipping"}'})[0],/包裹/);
 assert.match(questionSuggestions({classification_json:'{"mail_type":"academic_result"}'})[2],/还缺哪些信息/);
 assert.equal(questionSuggestions({classification_json:'bad'}).length,3);
});
test('question and edited payload reach both launchers; clearing restores direct copy',async()=>{
 const node=value=>({value,addEventListener(event,fn){this[event]=fn},focus(){},select(){}});
 const nodes={payload:node('mail'),question:node(''), 'copy-preview':node(''),status:{},'launch-fallback':{},copy:{},'clear-question':node('')};
 const suggestions=[{...node(''),dataset:{question:'我该怎么跟进？'}}];
 const buttons=aiLaunchers.map(a=>({dataset:{aiUrl:a.url,aiLabel:a.label}}));const copied=[];
 vm.runInNewContext(copyLaunchScript,{document:{getElementById:id=>nodes[id],querySelectorAll:s=>s==='[data-question]'?suggestions:buttons},navigator:{clipboard:{writeText:async text=>copied.push(text)}},window:{location:{assign(){}}}});
 suggestions[0].click();assert.equal(nodes.question.value,'我该怎么跟进？');
 nodes.payload.value='edited';nodes.payload.input();
 for(const b of buttons)await b.onclick();
 assert.equal(copied[0],composeQuestion('edited','我该怎么跟进？'));assert.equal(copied[1],copied[0]);
 nodes['clear-question'].click();await nodes.copy.onclick();assert.equal(copied[2],'edited');
});
test('cached copy pages get optional question UI and safely escaped source text',async()=>{
 const page=await toolPage('a'.repeat(32),'copy',{status:'completed',result:'</textarea><script>bad()</script>',mail:{subject:'refund'}}).text();
 assert.match(page,/我想问/);assert.match(page,/退款/);assert.match(page,/&lt;script&gt;/);
 assert.doesNotMatch(page,/<script>bad/);
 assert.match(page,/maxlength="2000"/);
});
