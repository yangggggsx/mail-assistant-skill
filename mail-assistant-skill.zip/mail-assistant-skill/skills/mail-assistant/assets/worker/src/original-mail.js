import {safeOriginalUrl} from './cloud-content.js';
const esc=v=>String(v||'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));

export function appleMessageUrl(id) {
  let value=String(id||'').trim();
  if(value.startsWith('<') && value.endsWith('>')) value=value.slice(1,-1);
  if(!value || value.length>900 || !/^[^\s<>\x00-\x1f\x7f]+@[^\s<>\x00-\x1f\x7f]+$/.test(value)) return '';
  return 'message://'+encodeURIComponent('<'+value+'>');
}
export function originalTargets(messageId,existing) {
  let apple=appleMessageUrl(messageId);
  if(!apple && String(existing||'').startsWith('message://')) {
    try{apple=appleMessageUrl(decodeURIComponent(existing.slice(10)));}catch{}
  }
  return {apple,web:safeOriginalUrl(existing)||''};
}

// Hidden/blur means the OS may have opened Mail or an app prompt. Never infer that
// the specific message was found; the manual web fallback stays visible on return.
export const launchScript=`(()=>{
const apple=document.getElementById('apple'),web=document.getElementById('web'),status=document.getElementById('status');
const isApple=/iPhone|iPad|iPod|Macintosh|MacIntel/.test(navigator.userAgent+' '+navigator.platform);
let timer,away=false;
function cancel(){away=true;clearTimeout(timer);}
document.addEventListener('visibilitychange',()=>{if(document.hidden)cancel();});
window.addEventListener('pagehide',cancel);window.addEventListener('blur',cancel);
function fallback(){if(web)location.replace(web.href);}
if(!isApple || !apple){if(web)fallback();return;}
if(document.hidden)return;
status.textContent='请在弹窗中点击「打开」，前往 Apple Mail 查看邮件。';
timer=setTimeout(()=>{if(!away&&!document.hidden){status.textContent='正在为你打开网页版…';fallback();}},2500);
try{location.href=apple.href;}catch{clearTimeout(timer);fallback();}
apple.addEventListener('click',()=>{clearTimeout(timer);});
})();`;

export function originalMailPage(messageId,existing) {
  const {apple,web}=originalTargets(messageId,existing);
  if(!apple&&!web)return null;
  const nonce=crypto.randomUUID();
  return new Response(`<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="color-scheme" content="light dark"><title>打开原邮件</title>
<style>body{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;margin:0;background:#f4f5f7;color:#171717}main{max-width:480px;margin:0 auto;padding:32px 20px}.card{background:#fff;border-radius:22px;padding:24px;box-shadow:0 10px 35px #0001}h1{font-size:25px;margin:0 0 12px}p{color:#666;line-height:1.6}.actions{display:flex;flex-wrap:wrap;gap:12px}a{display:inline-block;padding:15px 18px;border-radius:14px;background:#eef0f4;color:#111;text-decoration:none;font-weight:650}.primary{background:#1677ff;color:white}.note{font-size:13px}@media(prefers-color-scheme:dark){body{background:#111;color:#eee}.card{background:#202124}p{color:#bbb}a{background:#34363b;color:#eee}.primary{background:#1677ff}}</style></head><body><main><section class="card"><h1>打开原邮件</h1><p id="status">${apple?'请在弹窗中点击「打开」，前往 Apple Mail 查看邮件。':'正在为你打开网页版…'}</p><div class="actions">${apple?`<a id="apple" class="primary" href="${esc(apple)}">在 Apple Mail 中查看</a>`:''}${web?`<a id="web" href="${esc(web)}">用网页版查看</a>`:''}</div><p class="note">${web?'没找到邮件？可选择网页版查看。转发邮件可能显示为 Outlook 中的副本。':'这封旧邮件暂时只有 Apple Mail 入口，请确保对应邮箱已同步。'}</p><noscript><p>请点击上方按钮打开邮件。</p></noscript></section></main><script nonce="${nonce}">${launchScript}</script></body></html>`,{headers:{'content-type':'text/html; charset=utf-8','cache-control':'no-store','referrer-policy':'no-referrer','x-content-type-options':'nosniff','x-frame-options':'DENY','content-security-policy':`default-src 'none'; style-src 'unsafe-inline'; script-src 'nonce-${nonce}'; base-uri 'none'; form-action 'none'; frame-ancestors 'none'`}});
}
