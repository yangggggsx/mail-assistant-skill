CREATE TABLE IF NOT EXISTS feedback_links (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  token TEXT NOT NULL UNIQUE,
  message_key TEXT NOT NULL,
  created_at TEXT NOT NULL,
  expires_at TEXT NOT NULL,
  label TEXT,
  note TEXT,
  mail_url TEXT,
  submitted_at TEXT,
  acknowledged_at TEXT
);

CREATE INDEX IF NOT EXISTS idx_feedback_pending
  ON feedback_links(acknowledged_at, submitted_at);

CREATE INDEX IF NOT EXISTS idx_feedback_expiry
  ON feedback_links(expires_at);

CREATE TABLE IF NOT EXISTS digest_pages (
  token TEXT PRIMARY KEY,
  created_at TEXT NOT NULL,
  expires_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS digest_items (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  digest_token TEXT NOT NULL,
  position INTEGER NOT NULL,
  message_key TEXT NOT NULL,
  subject TEXT NOT NULL,
  sender TEXT NOT NULL,
  category TEXT NOT NULL,
  summary TEXT NOT NULL,
  mail_url TEXT,
  feedback_token TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_digest_items_token
  ON digest_items(digest_token, position);

CREATE INDEX IF NOT EXISTS idx_digest_expiry
  ON digest_pages(expires_at);

CREATE TABLE IF NOT EXISTS translations (
  token TEXT PRIMARY KEY,
  status TEXT NOT NULL,
  translation_text TEXT,
  error TEXT,
  requested_at TEXT NOT NULL,
  completed_at TEXT
);

CREATE INDEX IF NOT EXISTS idx_translations_pending
  ON translations(status, requested_at);

CREATE TABLE IF NOT EXISTS oauth_states (
  state TEXT PRIMARY KEY,
  provider TEXT NOT NULL,
  created_at TEXT NOT NULL,
  expires_at TEXT NOT NULL,
  consumed_at TEXT
);

CREATE INDEX IF NOT EXISTS idx_oauth_states_expiry
  ON oauth_states(expires_at);

CREATE TABLE IF NOT EXISTS cloud_accounts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  provider TEXT NOT NULL,
  email TEXT NOT NULL,
  refresh_token_enc TEXT NOT NULL,
  history_cursor TEXT,
  status TEXT NOT NULL DEFAULT 'active',
  shadow_mode INTEGER NOT NULL DEFAULT 1,
  connected_at TEXT NOT NULL,
  last_sync_at TEXT,
  last_success_at TEXT,
  last_error TEXT,
  UNIQUE(provider,email)
);

CREATE INDEX IF NOT EXISTS idx_cloud_accounts_status
  ON cloud_accounts(status,provider);

CREATE TABLE IF NOT EXISTS cloud_mail_observations (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  provider TEXT NOT NULL,
  account_email TEXT NOT NULL,
  external_message_id TEXT NOT NULL,
  external_thread_id TEXT,
  subject TEXT,
  sender TEXT,
  received_at TEXT,
  snippet TEXT,
  first_observed_at TEXT NOT NULL,
  source TEXT NOT NULL,
  UNIQUE(provider,account_email,external_message_id)
);

CREATE INDEX IF NOT EXISTS idx_cloud_observations_time
  ON cloud_mail_observations(provider,account_email,first_observed_at);

CREATE TABLE IF NOT EXISTS schedule_access_links (
  token TEXT PRIMARY KEY,
  created_at TEXT NOT NULL,
  expires_at TEXT NOT NULL,
  last_used_at TEXT
);

CREATE TABLE IF NOT EXISTS schedule_uploads (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  token TEXT NOT NULL UNIQUE,
  access_token TEXT NOT NULL,
  object_key TEXT,
  filename TEXT NOT NULL,
  content_type TEXT NOT NULL,
  size_bytes INTEGER NOT NULL,
  course_hint TEXT,
  term_hint TEXT,
  timezone TEXT NOT NULL,
  status TEXT NOT NULL,
  preview_json TEXT,
  selected_json TEXT,
  result_json TEXT,
  error TEXT,
  created_at TEXT NOT NULL,
  expires_at TEXT NOT NULL,
  claimed_at TEXT,
  confirmed_at TEXT,
  completed_at TEXT
);

CREATE INDEX IF NOT EXISTS idx_schedule_uploads_status
  ON schedule_uploads(status, created_at);

CREATE TABLE IF NOT EXISTS schedule_file_chunks (
  job_token TEXT NOT NULL,
  chunk_index INTEGER NOT NULL,
  data BLOB NOT NULL,
  PRIMARY KEY(job_token, chunk_index)
);

CREATE TABLE IF NOT EXISTS schedule_files (
  job_token TEXT NOT NULL,
  file_index INTEGER NOT NULL,
  filename TEXT NOT NULL,
  content_type TEXT NOT NULL,
  size_bytes INTEGER NOT NULL,
  storage_key TEXT,
  PRIMARY KEY(job_token, file_index)
);

CREATE TABLE IF NOT EXISTS schedule_file_parts (
  job_token TEXT NOT NULL,
  file_index INTEGER NOT NULL,
  chunk_index INTEGER NOT NULL,
  data BLOB NOT NULL,
  PRIMARY KEY(job_token, file_index, chunk_index)
);
