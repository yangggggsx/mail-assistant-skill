import {ensureScheduleSchema,scheduleFile,deleteStoredFiles,html,escapeHtml as esc} from './schedules.js';
import {ensureMigration} from './calendar-migration.js';
import {calendarAccess,calendarGraph,CALENDAR_ACCOUNT,CALENDAR_NAME} from './outlook-calendar-auth.js';
import {zones} from './outlook-calendar.js';
import {extractCourse,normalizeCourse,coursePayload,fingerprint,hash,localValue} from './course-extraction.js';
import {prepareCourseImage} from './course-images.js';
const now=()=>new Date().toISOString();
const parse=v=>JSON.parse(v||'{}');
export async function ensureCloudSchedules(env){
 await ensureScheduleSchema(env);await ensureMigration(env);
 await env.DB.batch([
  env.DB.prepare(`CREATE TABLE IF NOT EXISTS cloud_course_bindings(item_key TEXT PRIMARY KEY,course_key TEXT NOT NULL,event_id TEXT,calendar_id TEXT,source_json TEXT NOT NULL,snapshot_json TEXT,status TEXT NOT NULL,lock_id TEXT,updated_at TEXT NOT NULL)`),
  env.DB.prepare(`CREATE TABLE IF NOT EXISTS cloud_course_operations(id TEXT PRIMARY KEY,job_token TEXT NOT NULL,item_key TEXT NOT NULL,action TEXT NOT NULL,status TEXT NOT NULL,payload_json TEXT,event_id TEXT,error TEXT,created_at TEXT NOT NULL)`),
  env.DB.prepare(`CREATE TABLE IF NOT EXISTS cloud_schedule_leases(token TEXT PRIMARY KEY,claim TEXT,lease_until TEXT,attempts INTEGER NOT NULL DEFAULT 0)`),
 ]);
 // Adopt only exact historical identities whose import was verified. Never title-match.
 await env.DB.prepare(`INSERT OR IGNORE INTO cloud_course_bindings(item_key,course_key,event_id,calendar_id,source_json,snapshot_json,status,updated_at)
 SELECT item_key,course_key,event_id,calendar_id,legacy_payload_json,payload_json,'active',verified_at FROM calendar_course_migrations
 WHERE status='verified' AND item_key IS NOT NULL AND course_key IS NOT NULL AND legacy_payload_json IS NOT NULL`).run();
}
export async function enqueueSchedule(env,token){try{await env.ACTION_QUEUE.send({type:'schedule',token});}catch{console.error('schedule retained for cron');}}
export async function recoverSchedules(env){
 await ensureCloudSchedules(env);
 const jobs=(await env.DB.prepare("SELECT token FROM schedule_uploads WHERE status IN ('cloud_pending','cloud_processing','cloud_confirmed','cloud_applying') AND expires_at>?1 ORDER BY created_at LIMIT 5").bind(now()).all()).results||[];
 for(const j of jobs)await enqueueSchedule(env,j.token);
}
export async function runSchedule(env,token,{extract=extractCourse,apply=applyCourseItem}={}){
 if(!/^[A-Za-z0-9_-]{32}$/.test(token||''))return;
 await ensureCloudSchedules(env);
 let job=await env.DB.prepare('SELECT * FROM schedule_uploads WHERE token=?1 AND expires_at>?2').bind(token,now()).first();
 if(!job||!['cloud_pending','cloud_processing','cloud_confirmed','cloud_applying'].includes(job.status))return;
 await env.DB.prepare('INSERT OR IGNORE INTO cloud_schedule_leases(token) VALUES(?1)').bind(token).run();
 const claim=crypto.randomUUID();
 const lock=await env.DB.prepare('UPDATE cloud_schedule_leases SET claim=?1,lease_until=?2 WHERE token=?3 AND (lease_until IS NULL OR lease_until<?4)').bind(claim,new Date(Date.now()+10*60000).toISOString(),token,now()).run();
 if(!lock.meta?.changes)return;
 let reschedule=false;
 try{
  // A prior worker may finish between our first read and lease acquisition.
  job=await env.DB.prepare('SELECT * FROM schedule_uploads WHERE token=?1 AND expires_at>?2').bind(token,now()).first();
  if(!job||!['cloud_pending','cloud_processing','cloud_confirmed','cloud_applying'].includes(job.status))return;
  if(['cloud_pending','cloud_processing'].includes(job.status)){
   const lease=await env.DB.prepare('SELECT attempts FROM cloud_schedule_leases WHERE token=?1').bind(token).first();
   if(lease.attempts>=3){await failExtraction(env,job,'提取连续中断，请拆分文件后重新上传');return;}
   await env.DB.batch([env.DB.prepare('UPDATE cloud_schedule_leases SET attempts=attempts+1 WHERE token=?1').bind(token),env.DB.prepare("UPDATE schedule_uploads SET status='cloud_processing' WHERE token=?1").bind(token)]);
   try{
    const manifest=(await env.DB.prepare('SELECT file_index,filename,content_type FROM schedule_files WHERE job_token=?1 ORDER BY file_index').bind(token).all()).results||[];
    if(!manifest.length)throw Error('上传文件不可用，请重新上传');
    const files=[];let modelBytes=0;
    for(const f of manifest){
     const r=await scheduleFile(env,token,f.file_index);if(!r.ok)throw Error('上传文件不可用，请重新上传');
     const prepared=await prepareCourseImage(env,{...f,bytes:await r.arrayBuffer()});
     modelBytes+=prepared.bytes.byteLength;
     if(modelBytes>30*1024*1024)throw Error('图片解码后的总大小过大，请将文件分两批上传');
     files.push(prepared);
    }
    const raw=await extract(env,job,files);
    const bindings=(await env.DB.prepare('SELECT * FROM cloud_course_bindings').all()).results||[];
    const preview=await normalizeCourse(raw,job,bindings);
    await env.DB.prepare("UPDATE schedule_uploads SET status='cloud_preview',preview_json=?1,error=NULL WHERE token=?2 AND status='cloud_processing'").bind(JSON.stringify(preview),token).run();
   }catch(error){await failExtraction(env,job,error.message||'提取失败，请重新上传');}
   // Cleanup failures must not overwrite a successfully saved preview.
   try{await deleteStoredFiles(env,token,job.object_key);await env.DB.prepare('UPDATE schedule_uploads SET object_key=NULL WHERE token=?1').bind(token).run();}catch{console.error('course files pending cleanup');}
  }else{
   await env.DB.prepare("UPDATE schedule_uploads SET status='cloud_applying' WHERE token=?1").bind(token).run();
   const items=parse(job.selected_json);if(!Array.isArray(items))throw Error('invalid_selection');
   // Bounded work per queue message. Each operation has a durable, non-reclaimable claim.
   const done=(await env.DB.prepare('SELECT * FROM cloud_course_operations WHERE job_token=?1').bind(token).all()).results||[];
   const pending=items.filter(e=>!done.some(o=>o.item_key===e.item_key));
   if(pending.length)await apply(env,token,pending[0]);
   const results=(await env.DB.prepare('SELECT * FROM cloud_course_operations WHERE job_token=?1').bind(token).all()).results||[];
   if(results.length>=items.length){
    const result={created:0,updated:0,deleted:0,existing:0,failed:0,errors:[]};
    for(const r of results){if(r.status==='completed')result[{create:'created',update:'updated',cancel:'deleted'}[r.action]]++;else{result.failed++;result.errors.push(r.error||'写入结果待核对，不会自动重试');}}
    await env.DB.prepare("UPDATE schedule_uploads SET status='cloud_completed',result_json=?1,completed_at=?2 WHERE token=?3").bind(JSON.stringify(result),now(),token).run();
   }else reschedule=true;
  }
 }finally{await env.DB.prepare('UPDATE cloud_schedule_leases SET claim=NULL,lease_until=NULL WHERE token=?1 AND claim=?2').bind(token,claim).run();if(reschedule)await enqueueSchedule(env,token);}
}
async function failExtraction(env,job,error){
 await env.DB.prepare("UPDATE schedule_uploads SET status='cloud_failed',error=?1 WHERE token=?2").bind(String(error).slice(0,800),job.token).run();
 await deleteStoredFiles(env,job.token,job.object_key);await env.DB.prepare('UPDATE schedule_uploads SET object_key=NULL WHERE token=?1').bind(job.token).run();
}
export async function applyCourseItem(env,token,e,{access=calendarAccess,graph=calendarGraph}={}){
 const id=await hash(token+':'+e.item_key);
 if(await env.DB.prepare('SELECT id FROM cloud_course_operations WHERE id=?1').bind(id).first())return;
 let eventId=null,written=false;
 const op=await env.DB.prepare("INSERT OR IGNORE INTO cloud_course_operations(id,job_token,item_key,action,status,created_at) VALUES(?1,?2,?3,?4,'checking',?5)").bind(id,token,e.item_key,e.action,now()).run();if(!op.meta?.changes)return;
 try{
  if(!['create','update','cancel'].includes(e.action)||!e.item_key||!e.course_key)throw Error('日程操作无效');
  const payload=e.action==='cancel'?null:coursePayload(e);
  const {access:bearer,connection}=await access(env);
  if(connection.email!==CALENDAR_ACCOUNT||connection.status!=='ready'||!connection.calendar_id)throw Error('目标日历不可用');
  const path='/me/calendars/'+encodeURIComponent(connection.calendar_id);
  const target=await graph(bearer,path+'?$select=id,name,canEdit');
  if(target.id!==connection.calendar_id||target.name!==CALENDAR_NAME||target.canEdit!==true)throw Error('目标日历已变化');
  if(e.action==='create')await env.DB.prepare("INSERT OR IGNORE INTO cloud_course_bindings(item_key,course_key,source_json,status,updated_at) VALUES(?1,?2,?3,'new',?4)").bind(e.item_key,e.course_key,JSON.stringify(e),now()).run();
  const bound=await env.DB.prepare('SELECT * FROM cloud_course_bindings WHERE item_key=?1').bind(e.item_key).first();
  if(!bound||bound.course_key!==e.course_key||bound.lock_id)throw Error('此事项有其他同步或待核对操作');
  if(e.action==='create'&&(bound.status!=='new'||bound.event_id))throw Error('日程已经存在，请重新分析');
  if(e.action!=='create'&&(bound.status!=='active'||bound.event_id!==e.event_id||bound.snapshot_json!==e.base||bound.calendar_id!==connection.calendar_id))throw Error('日程所有权或版本已变化，请重新分析');
  const locked=await env.DB.prepare('UPDATE cloud_course_bindings SET lock_id=?1 WHERE item_key=?2 AND lock_id IS NULL AND updated_at=?3').bind(id,e.item_key,bound.updated_at).run();
  if(!locked.meta?.changes)throw Error('此事项正在其他任务中同步');
  let etag;
  if(e.action!=='create'){
   const live=await graph(bearer,path+'/events/'+encodeURIComponent(bound.event_id),{responseTimezone:'UTC'});
   if(live.id!==bound.event_id||live.recurrence||(live.attendees||[]).length||live.isCancelled||fingerprint(live)!==fingerprint(parse(bound.snapshot_json)))throw Error('日历项目已被手动修改或不是独立个人日程，未覆盖');
   etag=live['@odata.etag'];if(!etag)throw Error('无法取得日程版本，未修改');eventId=bound.event_id;
  }
  await env.DB.prepare("UPDATE cloud_course_operations SET status='submitting',payload_json=?1,event_id=?2 WHERE id=?3").bind(payload?JSON.stringify(payload):null,eventId,id).run();
  written=true;
  if(e.action==='cancel'){
   await graph(bearer,path+'/events/'+encodeURIComponent(eventId),{method:'DELETE',ifMatch:etag});
   let absent=false;try{await graph(bearer,path+'/events/'+encodeURIComponent(eventId));}catch(error){if(error.httpStatus===404)absent=true;else throw error;}if(!absent)throw Error('删除结果无法确认');
  }else{
   const out=await graph(bearer,path+'/events'+(e.action==='update'?'/'+encodeURIComponent(eventId):''),{method:e.action==='update'?'PATCH':'POST',body:e.action==='create'?{...payload,transactionId:id}:payload,ifMatch:etag});
   eventId=out.id||eventId;if(!eventId)throw Error('写入未返回标识');
   await env.DB.prepare('UPDATE cloud_course_operations SET event_id=?1 WHERE id=?2').bind(eventId,id).run();
   const live=await graph(bearer,path+'/events/'+encodeURIComponent(eventId),{responseTimezone:'UTC'});
   if(live.id!==eventId||live.recurrence||(live.attendees||[]).length||fingerprint(live)!==fingerprint(payload))throw Error('写入后读回校验未通过');
  }
  await env.DB.batch([
   env.DB.prepare('UPDATE cloud_course_bindings SET event_id=?1,calendar_id=?2,source_json=?3,snapshot_json=?4,status=?5,lock_id=NULL,updated_at=?6 WHERE item_key=?7 AND lock_id=?8').bind(eventId,connection.calendar_id,JSON.stringify(e),JSON.stringify(payload||parse(bound.snapshot_json)),e.action==='cancel'?'deleted':'active',now(),e.item_key,id),
   env.DB.prepare("UPDATE cloud_course_operations SET status='completed',event_id=?1 WHERE id=?2").bind(eventId,id),
  ]);
 }catch(error){
  await env.DB.prepare('UPDATE cloud_course_operations SET status=?1,error=?2,event_id=?3 WHERE id=?4').bind(written?'uncertain':'conflict',written?'写入结果需核对；请检查 Outlook，不要重复提交':String(error.message).slice(0,300),eventId,id).run();
  // Unknown remote effects permanently retain the item lock until operator reconciliation.
  if(!written)await env.DB.prepare('UPDATE cloud_course_bindings SET lock_id=NULL WHERE item_key=?1 AND lock_id=?2').bind(e.item_key,id).run();
 }
}
async function proof(env,token,preview,expires){
 const key=await crypto.subtle.importKey('raw',new TextEncoder().encode(env.API_TOKEN),{name:'HMAC',hash:'SHA-256'},false,['sign']);
 return [...new Uint8Array(await crypto.subtle.sign('HMAC',key,new TextEncoder().encode(token+':'+await hash(preview)+':'+expires)))].map(x=>x.toString(16).padStart(2,'0')).join('');
}
const editable=e=>['create','update'].includes(e.action);
const selectable=e=>editable(e)||e.action==='cancel';
export async function cloudSchedulePage(env,row){
 const token=row.token;
 if(['cloud_pending','cloud_processing','cloud_confirmed','cloud_applying'].includes(row.status))return html(`<h1>${row.status.includes('pending')||row.status.includes('processing')?'正在云端提取日程':'正在同步 Outlook 日历'}</h1><p>${esc(row.filename)}</p><div class="progress"><span></span></div><script>setTimeout(()=>location.reload(),${['cloud_confirmed','cloud_applying'].includes(row.status)?2000:5000})</script>`);
 if(row.status==='cloud_failed')return html(`<h1>提取未完成</h1><p>${esc(row.error)}</p><p>没有修改日历。请返回上传入口重试。</p>`,422);
 if(row.status==='cloud_completed'){
  const r=parse(row.result_json);return html(`<h1>${r.failed?'同步完成，部分需核对':'已保存到 Outlook ✓'}</h1><p>新增 ${r.created} · 更新 ${r.updated} · 删除 ${r.deleted} · 待核对 ${r.failed}</p>${(r.errors||[]).slice(0,10).map(x=>`<p class="warning">${esc(x)}</p>`).join('')}`);
 }
 if(row.status!=='cloud_preview')return html('<h1>旧版课程任务</h1><p>旧 Mac 写入入口已停用。请重新上传课程文件，使用云端预览。</p>',409);
 const p=parse(row.preview_json),expires=String(Math.floor(Date.now()/1000)+3600);
 const input=(i,k,label,value,type='text')=>`<label>${label}</label><input style="width:100%;min-height:44px" type="${type}" name="${i}_${k}" value="${esc(value)}">`;
 const blocks=p.events.map((e,i)=>{
  const can=selectable(e),edit=editable(e),recommended=edit&&!e.issue&&e.milestone!=='assigned';
  let before='';if(e.base){const old=parse(e.base);before=`<details><summary>查看当前日历内容</summary><p>${esc(old.subject)}<br>${esc(old.start?.dateTime)} → ${esc(old.end?.dateTime)}（${esc(old.start?.timeZone)}）<br>${esc(old.location?.displayName)}</p></details>`;}
  return `<section class="event"><label><input type="checkbox" name="item" value="${i}" ${can?'':'disabled'} ${recommended?'checked':''} data-editable="${edit?'1':'0'}" data-recommended="${recommended?'1':'0'}"><strong>${esc({create:'新增',update:'更新',cancel:'明确取消',existing:'已存在',possible_cancel:'保留未出现项目',blocked:'需核对'}[e.action])} · ${esc(e.title)}</strong></label>${e.issue?`<p class="warning">${esc(e.issue)}</p>`:''}${e.duration_estimate?`<p class="warning">预计时长：${esc(e.duration_estimate.minutes)} 分钟（AI 建议，非原文结束时间）。${esc(e.duration_estimate.reason)} 可修改下方结束时间，以确认后的时间为准。</p>`:''}${before}${edit?`${input(i,'title','标题',e.title)}${input(i,'start','开始（当地时间）',e.start,'datetime-local')}${input(i,'end','结束（全天为次日 00:00）',e.end,'datetime-local')}<label>时区</label><select name="${i}_timezone">${Object.keys(zones).map(z=>`<option${z===e.timezone?' selected':''}>${z}</option>`).join('')}</select><label><input type="checkbox" name="${i}_all_day" value="yes" ${e.all_day?'checked':''}> 全天</label>${input(i,'location','地点',e.location)}${input(i,'description','备注',e.description)}`:`<p>${esc(e.start||'')} → ${esc(e.end||'')}</p>`}<details><summary>提取依据</summary><p>${esc(e.source_text||'历史课程记录')}</p></details></section>`;
 }).join('');
 return html(`<h1>预览并编辑日程</h1><p>${p.mode==='general'?'通用提取 · 仅新增':esc(p.course_id||p.course_name)+' · '+esc(p.term)}<br>保存至：Outlook · 邮件助手</p>${p.warnings.length?`<details><summary>提取提示（${p.warnings.length}）</summary>${p.warnings.map(w=>`<p>${esc(w)}</p>`).join('')}</details>`:''}<form method="post" action="/schedule/${token}/confirm"><input type="hidden" name="expires" value="${expires}"><input type="hidden" name="proof" value="${await proof(env,token,row.preview_json,expires)}"><div class="selection-tools"><button type="button" class="secondary" onclick="document.querySelectorAll('[name=item]').forEach(x=>{if(!x.disabled&&x.dataset.editable==='1')x.checked=true})">全选新增与更新</button><button type="button" class="secondary" onclick="document.querySelectorAll('[name=item]').forEach(x=>x.checked=false)">全不选</button><button type="button" class="secondary" onclick="document.querySelectorAll('[name=item]').forEach(x=>x.checked=x.dataset.recommended==='1')">恢复建议</button></div>${blocks||'<p>没有提取到日程，请检查原文件是否包含明确事件和日期。</p>'}${p.events.some(selectable)?'<button type="submit" name="confirm" value="yes" style="width:100%;min-height:52px">确认加入 Outlook</button>':''}</form><details><summary>使用说明</summary><p>未勾选不改动；不自动推断取消；不设置提醒，不发送邀请或成功推送。补全缺失时间后再勾选项目。</p></details>`);
}
export async function confirmCloudSchedule(request,env,token,row){
 const origin=new URL(request.url).origin;
 const recover=(message,status=403)=>html(`<h1>${message}</h1><p>本次提交没有写入日历。无需重新上传文件，请返回预览核对后再确认。</p><a class="button" href="/schedule/${encodeURIComponent(token)}">返回日程预览</a>`,status);
 // Referrer-Policy: no-referrer can legitimately produce Origin: null on
 // native form POSTs. A null/missing origin is not trusted on its own: the
 // expiring HMAC below binds this upload and its exact stored preview.
 const sentOrigin=request.headers.get('origin');
 if((sentOrigin&&!['null',origin].includes(sentOrigin))||request.headers.get('sec-fetch-site')==='cross-site')return recover('提交来源未通过校验');
 if(row.status!=='cloud_preview')return html('<h1>当前任务已提交或不可确认</h1>',409);
 let form;try{form=await request.formData();}catch{return recover('无法读取提交内容',400);}
 const expires=String(form.get('expires')||''),time=Math.floor(Date.now()/1000);
 if(!/^\d{10}$/.test(expires)||+expires<time||+expires>time+3600||form.get('proof')!==await proof(env,token,row.preview_json,expires)||form.get('confirm')!=='yes')return recover('预览凭证已失效或尚未勾选确认');
 const p=parse(row.preview_json),indices=[...new Set(form.getAll('item').map(String))],selected=[];
 try{
  if(!indices.length)throw Error('请至少勾选一个项目');
  for(const i of indices){if(!/^\d{1,3}$/.test(i)||!selectable(p.events[+i]||{}))throw Error('所选项目无效');const e={...p.events[+i]};
   if(editable(e)){for(const k of ['title','start','end','timezone','location','description'])e[k]=String(form.get(i+'_'+k)||'').trim();e.all_day=form.get(i+'_all_day')==='yes';coursePayload(e);}
   selected.push(e);
  }
 }catch(error){return html(`<h1>请检查所选日程</h1><p>${esc(error.message)}</p><p>用浏览器返回，保留填写内容后修改。</p>`,400);}
 const claim=await env.DB.prepare("UPDATE schedule_uploads SET status='cloud_confirmed',selected_json=?1,confirmed_at=?2 WHERE token=?3 AND status='cloud_preview' AND preview_json=?4").bind(JSON.stringify(selected),now(),token,row.preview_json).run();
 if(!claim.meta?.changes)return html('<h1>任务状态已变化，请刷新</h1>',409);
 await enqueueSchedule(env,token);
 return new Response(null,{status:303,headers:{location:'/schedule/'+token,'cache-control':'no-store'}});
}
