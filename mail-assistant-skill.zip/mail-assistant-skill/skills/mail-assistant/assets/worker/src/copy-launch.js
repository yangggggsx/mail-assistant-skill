import {copyIntentScript} from './copy-intent.js';
export const aiLaunchers=[
 {id:'chatgpt',label:'ChatGPT',shortcut:'邮件助手-ChatGPT'},
 {id:'claude',label:'Claude',shortcut:'邮件助手-Claude'},
].map(x=>({...x,url:'shortcuts://run-shortcut?name='+encodeURIComponent(x.shortcut)}));

// Never put mail content into URLs or launch after a failed clipboard write.
export const copyLaunchScript=`(()=>{
const payload=document.getElementById('payload'),status=document.getElementById('status');
if(!payload)return;
${copyIntentScript}
let busy=false;
async function copy(url,label){
 if(busy)return;busy=true;
 const fallback=document.getElementById('launch-fallback');fallback.hidden=true;
 try{
  await navigator.clipboard.writeText(currentText());
  status.textContent=url?'已复制。正在打开 '+label+'；进入后请粘贴并发送。':'已复制，可以粘贴到 AI。';
  if(url){
   fallback.href=url;fallback.textContent='已复制，点击打开 '+label;fallback.hidden=false;
   try{window.location.assign(url);}catch{status.textContent='已复制，请点击下方备用入口打开 App。';}
  }
 }catch{
  const panel=document.getElementById('preview-panel');if(panel)panel.open=true;
  const manual=preview||payload;updatePreview();manual.focus();manual.select();
  status.textContent='自动复制失败，未跳转。请长按选中文字复制，再使用下方手动打开入口。';
 }finally{busy=false;}
}
document.getElementById('copy').onclick=()=>copy();
document.querySelectorAll('[data-ai-url]').forEach(b=>{b.onclick=()=>copy(b.dataset.aiUrl,b.dataset.aiLabel);});
})();`;
