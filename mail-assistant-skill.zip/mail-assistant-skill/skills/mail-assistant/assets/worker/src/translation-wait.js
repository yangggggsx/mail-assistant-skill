// SSE and read-only polling fallback; preserve the card and existing paragraphs.
export const translationWaitScript=`(()=>{
let timer,busy=false,done=false,delay=2000,source=null,streamFailed=false;
function stopStream(){if(source){source.close();source=null;}}
function apply(data){
 const block=document.querySelector('#translation-partial'),state=document.querySelector('#translation-state');
 if(block&&Array.isArray(data.paragraphs)){
  data.paragraphs.forEach((html,index)=>{
   let paragraph=block.children[index];
   if(!paragraph){paragraph=document.createElement('div');paragraph.className='translation-paragraph';block.appendChild(paragraph);}
   if(paragraph.innerHTML!==html)paragraph.innerHTML=html;
  });
  while(block.children.length>data.paragraphs.length)block.lastElementChild.remove();
  if(state&&data.paragraphs.length){state.textContent='';}
 }
 if(data.status==='completed'||data.status==='failed'){
  done=true;stopStream();clearTimeout(timer);
  if(state){state.hidden=false;state.textContent=data.status==='completed'?'翻译完成':'翻译未完成；已有片段仅供参考。';}
  if(data.status==='failed'){
   const target=document.querySelector('#translation-error');
   if(target){const p=document.createElement('p');p.textContent=data.error||'请稍后重试。';target.appendChild(p);
    const form=document.createElement('form');form.method='post';form.action=location.pathname;
    const button=document.createElement('button');button.textContent='重新翻译';form.appendChild(button);target.appendChild(form);}
  }
 }
 if(data.error==='not_found'){done=true;stopStream();if(state)state.textContent='翻译记录暂不可用，请返回邮件通知重新打开。';}
}
function schedule(){clearTimeout(timer);if(!done&&!busy&&!document.hidden)timer=setTimeout(check,delay);}
async function check(){
 if(done||busy||document.hidden)return;
 busy=true;
 try{
  const r=await fetch(location.pathname+'/status',{cache:'no-store',credentials:'same-origin',signal:AbortSignal.timeout(15000)});
  if(r.status===404||r.status===410){apply({error:'not_found'});return;}
  if(!r.ok)throw Error('status unavailable');
  delay=2000;apply(await r.json());
 }catch{delay=Math.min(15000,delay*2);}
 finally{busy=false;schedule();}
}
function start(){
 clearTimeout(timer);if(document.hidden||done){stopStream();return;}
 if(typeof EventSource!=='undefined'&&!streamFailed){
  if(source)return;source=new EventSource(location.pathname+'/events');
  source.onmessage=event=>{try{apply(JSON.parse(event.data));}catch{fallback();}};
  source.onerror=fallback;source.addEventListener('fallback',fallback);
 }else schedule();
}
function fallback(){stopStream();streamFailed=true;check();}
document.addEventListener('visibilitychange',start);
window.addEventListener('pagehide',()=>{stopStream();clearTimeout(timer);});
window.addEventListener('pageshow',e=>{if(e.persisted)start();});
start();
})();`;
