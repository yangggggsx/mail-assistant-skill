import test from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {ensureRealtime,handleRealtime,maintainRealtime,consumeRealtime,verifyGooglePush} from './realtime.js';
async function fixture(){
 const db=new DatabaseSync(':memory:');
 const prepare=sql=>{let args=[];const q=sql.replace(/\?(\d+)/g,(_,n)=>`$p${n}`),p=()=>Object.fromEntries(args.map((v,i)=>[`$p${i+1}`,v]));return {bind(...v){args=v;return this},async run(){return {meta:{changes:Number(db.prepare(q).run(p()).changes)}}},async first(){return db.prepare(q).get(p())||null},async all(){return {results:db.prepare(q).all(p())}}};};
 const sent=[],env={DB:{prepare,batch:async qs=>Promise.all(qs.map(q=>q.run()))},REALTIME_QUEUE:{send:async x=>sent.push(x)}};
 await ensureRealtime(env);await env.DB.prepare('UPDATE realtime_control SET enabled=1').run();
 await env.DB.prepare("INSERT INTO cloud_accounts(provider,email,refresh_token_enc,status,shadow_mode,connected_at) VALUES('microsoft','test@example.com','test','active',0,'now')").run();
 await env.DB.prepare("INSERT INTO realtime_subscriptions(provider,email,subscription_id,client_state) VALUES('microsoft','test@example.com','subscription','secret')").run();
 return {env,sent};
}
import {ORIGIN as origin} from './deployment-config.js';
test('dedicated action jobs execute and drain receipts without running mailbox pipeline',async()=>{
 const {env}=await fixture();let ack=0,ran=0,drained=0;
 await consumeRealtime({messages:[{body:{type:'action',kind:'translate',key:'a'.repeat(32)},ack(){ack++},retry(){throw Error('unexpected retry')}}]},env,{
  action:async(_env,kind,key)=>{assert.equal(kind,'translate');assert.equal(key.length,32);ran++},drain:async()=>{drained++},run:()=>{throw Error('must not scan mail')}
 });assert.equal(ack,1);assert.equal(ran,1);assert.equal(drained,1);
});
function req(path,body){return new Request(origin+path,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(body)});}
test('admin rejects unauthorized and validation echo needs no database',async()=>{
 const r=req('/api/cloud/realtime/enable',{});assert.equal((await handleRealtime(r,{},new URL(r.url),false)).status,401);
 const v=req('/hooks/microsoft?validationToken=a%2Bb',{}),res=await handleRealtime(v,{},new URL(v.url),false);assert.equal(await res.text(),'a+b');assert.equal(res.headers.get('content-type'),'text/plain');
});
test('Microsoft validates clientState and subscription then durably queues',async()=>{
 const {env,sent}=await fixture();
 for(const [state,status] of [['bad',403],['secret',202]]){
  const r=req('/hooks/microsoft',{value:[{subscriptionId:'subscription',clientState:state,changeType:'created'}]});assert.equal((await handleRealtime(r,env,new URL(r.url),false)).status,status);
 }assert.equal(sent.length,1);assert.deepEqual(Object.keys(sent[0]).sort(),['received_at','type']);
});
test('queue failure is not acknowledged to mailbox provider',async()=>{
 const {env}=await fixture();env.REALTIME_QUEUE.send=async()=>{throw Error('unavailable')};
 const r=req('/hooks/microsoft',{value:[{subscriptionId:'subscription',clientState:'secret',changeType:'created'}]});await assert.rejects(handleRealtime(r,env,new URL(r.url),false));
});
test('Outlook renewal uses persisted secret and next day schedule; errors stay sanitized',async()=>{
 const {env}=await fixture();let calls=0;
 await maintainRealtime(env,{msToken:async()=>({access_token:'private'}),msRequest:async(_,path,method)=>{calls++;assert.equal(method,'PATCH');return {id:'subscription',expirationDateTime:new Date(Date.now()+6*86400000).toISOString()}}});
 await maintainRealtime(env,{msToken:()=>{throw Error('must not renew early')}});assert.equal(calls,1);
 assert.equal((await env.DB.prepare('SELECT last_error FROM realtime_subscriptions').first()).last_error,null);
});
test('lost subscription recovers using create and fixed Inbox resource',async()=>{
 const {env}=await fixture();let created;
 await maintainRealtime(env,{msToken:async()=>({access_token:'private'}),msRequest:async(_,path,method,body)=>{
  if(method==='PATCH'){const e=Error();e.status=404;throw e;}if(method==='GET')return {value:[]};created=body;return {id:'new',expirationDateTime:body.expirationDateTime};
 }});assert.equal(created.resource,"me/mailFolders('Inbox')/messages");assert.equal(created.changeType,'created');assert.equal(created.clientState,'secret');
});
test('queue consumer retries lock contention and drains immediately after processing',async()=>{
 const {env,sent}=await fixture();let ack=0,retry=0,drain=0;
 const batch={messages:[{body:{type:'mail'},ack:()=>ack++,retry:()=>retry++}]};
 await consumeRealtime(batch,env,{run:async()=>({skipped:true}),drain:async()=>drain++});assert.equal(retry,1);assert.equal(ack,0);
 await consumeRealtime(batch,env,{run:async()=>({processed:5}),drain:async()=>drain++});assert.equal(ack,1);assert.equal(drain,2);assert.equal(sent[0].type,'mail');
});
test('Gmail rejects unauthenticated push before database and unknown subscription',async()=>{
 const r=req('/hooks/google',{});assert.equal((await handleRealtime(r,{},new URL(r.url),false)).status,401);
 const {env}=await fixture();env.GMAIL_PUBSUB_SUBSCRIPTION='projects/p/subscriptions/s';
 assert.equal((await handleRealtime(r,env,new URL(r.url),false,{verifyGoogle:async()=>true})).status,403);
});
test('Gmail verifies real RSA signature, audience, expiry, service account',async()=>{
 const keys=await crypto.subtle.generateKey({name:'RSASSA-PKCS1-v1_5',modulusLength:2048,publicExponent:new Uint8Array([1,0,1]),hash:'SHA-256'},true,['sign','verify']);
 const jwk={...await crypto.subtle.exportKey('jwk',keys.publicKey),kid:'test-rsa'};
 const enc=x=>Buffer.from(typeof x==='string'?x:JSON.stringify(x)).toString('base64url');
 const make=async overrides=>{const payload={iss:'https://accounts.google.com',aud:origin+'/hooks/google',email:'push@p.iam.gserviceaccount.com',email_verified:true,iat:Date.now()/1000,exp:Date.now()/1000+3600,...overrides};const text=enc({alg:'RS256',kid:'test-rsa'})+'.'+enc(payload);const sig=await crypto.subtle.sign('RSASSA-PKCS1-v1_5',keys.privateKey,new TextEncoder().encode(text));return new Request(origin+'/hooks/google',{headers:{authorization:'Bearer '+text+'.'+Buffer.from(sig).toString('base64url')}})};
 const env={GMAIL_PUSH_SERVICE_ACCOUNT:'push@p.iam.gserviceaccount.com'},fetcher=async()=>Response.json({keys:[jwk]});
 assert.equal(await verifyGooglePush(await make({}),env,fetcher),true);
 for(const p of [{aud:'evil'},{email:'other'},{exp:0},{email_verified:false}])assert.equal(await verifyGooglePush(await make(p),env,fetcher),false);
});
