# Operations and maintenance

## Read first

All paths below require administrator bearer authentication except `/health`. Protect outputs containing emails, subjects, IDs or link tokens; do not add them to issues, repositories or skill fixtures.

| GET endpoint | Purpose |
|---|---|
| `/api/cloud/accounts` | OAuth and mailbox sync status |
| `/api/cloud/pipeline/status` | Enabled state, cutover, recent processing and daily cap |
| `/api/cloud/pipeline/junk/status` | Outlook junk review cursor/errors |
| `/api/cloud/realtime/status` | Subscriptions and renewal errors |
| `/api/delivery/status` | Cloud delivery ownership and pending/uncertain counts |
| `/api/calendar/status` | Bound Outlook account/calendar |
| `/api/calendar/events` | Recent email-calendar write results |
| `/api/calendar/schedule-audit` | Bounded readback of recent file-calendar bindings |

`/api/cloud/pipeline/messages` returns stored message data, not just metrics. Use only when message-level inspection is needed and authorized. `/api/cloud/migration/probe` can read a selected observation; `classify:true` adds a model request and cost.

## Common problems

- **Delayed push:** compare provider received time, ingestion, classification and outbox states. Distinguish client notification delay from backend processing. Two inboxes receiving the same message need not be a duplicate bug.
- **Calendar says success but appears missing:** check the actual target account/calendar, event ID and Graph readback. Then check client subscription/sync and timezone. Do not create a second event before resolving identity.
- **Task interrupted:** inspect persisted status and remote object before retrying. Never change `iphone_claimed` to pending automatically; the phone may already have written the reminder.
- **Translation slow:** use request/queue/first-text/completion timing rather than screenshots. Do not repeatedly invoke the paid model; keep incomplete output distinct from completed output. Preserve links and escaping.
- **Classification complaint:** examine the actual email and both importance/category fields. Use feedback as contextual evidence; do not turn one sender or one confirmation message into a universal rule.
- **Reported event source:** a fixture such as “Halloween Party” in a test is synthetic. It does not establish that the user's mailbox or calendar contains that event. Provide verified provenance or say it is unknown.

## Changes and rollback

Work in the generated deployment checkout, never the immutable bundled template. Save an archive and record the current Cloudflare version before edits. Run Node 24 `npm test`, then `wrangler deploy --dry-run`. If publishing, inspect the source diff and verify the health endpoint after deploy. Do not alter secrets, D1 contents, notification appearance or user-visible labels as incidental cleanup.

Keep old capability routes and format-1 shortcut payloads compatible. Old Mac schedule claim/write endpoints are intentionally fenced. Do not revive them. Some modules named migration/course are live runtime dependencies.

Rollback code using a known version or the archive after reviewing compatibility with data changes. A code backup is not a database backup. Do not overwrite current D1 state or remove existing events to roll back a cosmetic/code-only change.

## Cost model

Costs depend on email volume, token length, model, file/image usage, Cloudflare resources and Pushover. Use real API usage for a dated estimate; do not extrapolate an arbitrary partial-month screenshot as a full monthly bill. Polling a cached page is not another model call. Check current provider prices when asked, using official sources.
