# iPhone shortcuts

## Copy to AI: open ChatGPT or Claude

The iPhone **复制并打开 ChatGPT / Claude** actions also require Shortcuts. They are separate from the reminder shortcut and have no shared installation link supplied in this package.

1. Install the AI app you intend to use. In Shortcuts, create `邮件助手-ChatGPT` with a single **Open App → ChatGPT** action, and/or `邮件助手-Claude` with **Open App → Claude**. Names must match exactly, including the hyphen. Configure only the destinations you use.
2. From the assistant's **复制到 AI** page, review/edit the mail context and optional question, then select **复制并打开 ChatGPT** or **复制并打开 Claude**.
3. The webpage first writes the current text to the clipboard, then runs the named shortcut through `shortcuts://run-shortcut`. The shortcut only opens the app: it does not read the clipboard, invoke an AI model, or send the text. Mail content is not included in the launch URL.
4. Paste and send manually inside the AI app. Attachments/images are not copied automatically.
5. If copying succeeds but navigation does not, use the displayed fallback link. If the shortcut is missing, check its name and Open App target. If clipboard writing fails, the webpage does not launch the shortcut; use the selected preview text to copy manually before opening the app.

**仅复制全部** works without a shortcut, subject to browser clipboard permissions. Do not describe the iPhone app-launch integration as supported on Android/Windows. New-phone launch, paste and failure cases still require real-device acceptance.

## Install the shared reminder shortcut

[Install 邮件助手-加入待办](https://www.icloud.com/shortcuts/7a610bc2e6524944ad34449f66d94e11)

After installation, create your own `邮件待办` list in Reminders and select it in the shortcut's Add Reminder action. The shared snapshot contains the author's list reference; do not assume it resolves on another phone. Keep the shortcut name exactly `邮件助手-加入待办`, matching the generated launch URL. Install Pushover for the final return-to-app action.

Static inspection on 2026-10-26 found no fixed server URL or API key in its actions: the claim URL comes from Shortcut Input and the receipt URL comes from the response. Run it from your own deployed assistant's Add Reminder link, not with an arbitrary URL. This inspection did not execute the shortcut or verify installation on a new phone. The iCloud link is an externally hosted shared snapshot.

The manual setup instructions below remain available; the PDF/image upload shortcut is still configured manually with the operator's own upload URL.

## Add reminder

1. Create the Reminders list `邮件待办`. Create the shortcut above, accepting text input (the signed claim URL from the web flow). With no input, stop.
2. Get Contents of Shortcut Input: POST, JSON body with **Number** `format: 2`. Save the returned dictionary as `任务`. If `claim` is empty, show the returned error and stop.
3. Get `marker` from `任务`. Find Reminders where **Any** of `Notes contains marker` or `URL contains marker` is true. Do not filter out completed reminders.
4. Count results. More than one: ask the user to reconcile and stop. One: use the existing reminder. Zero: Add Reminder with `title` to `邮件待办`, `notes` in Notes and `url` in URL. No alert, guessed deadline or edit sheet.
5. After a successful add or finding exactly one existing item, POST to `receipt_url` with JSON `claim` equal to the task claim and `status` equal to `completed`.
6. Read the response's `ok` boolean. Return to Pushover on success; do not send an additional “added” push. If false or the request fails, explain that the reminder may already exist and must be checked before retrying.

The website shows server receipt state; returning to Pushover alone is not success. Existing format-1 shortcuts need both Notes/URL search and URL storage configured before switching to format 2. Never insert the admin API token into this shortcut.

## Share a file for event extraction

1. Create `上传日程`, enable Share Sheet, accept Images, PDFs and Files.
2. Accept one input file; for multiple files use the upload website.
3. Store the private upload-page URL followed by `/upload` in a URL action.
4. Get Contents of URL: POST, Request Body File, File **Shortcut Input** (not the preceding URL action's output).
5. Read `status_url` from the response; open it. If missing, show the returned error. Do not automatically retry an ambiguous upload timeout.
6. The cloud extracts events and presents an editable preview. The user confirms selected items for Outlook insertion; the shortcut does not auto-confirm them.

Supported formats: PDF, JPEG, PNG, WebP, HEIC/HEIF. HEIC conversion needs the configured Cloudflare Images binding. Website uploads support up to ten files with a total 20 MB limit. Default timezone is America/Chicago; review or change it for another locale. Optional multipart fields are `files`, `course_hint`, `term_hint`, `timezone`; use the actual source parser when changing clients.

File analysis and Outlook writing do not require a Mac. Writing Apple Reminders still requires the iPhone shortcut.

### Updated cloud preview

The upload protocol is unchanged; existing upload shortcuts do not need reinstalling for this update. Deploy the updated Worker in your own account.

For general extraction, missing source ends can receive an AI duration suggestion with a reason (for example, different basketball and football estimates). The end field is prefilled and editable, and the preview labels it as an estimate. Explicit ends take priority. Missing starts, all-day events, deadlines/homework and unsupported estimates are not filled this way; course-association mode keeps its existing behavior. Calendar notes distinguish the original AI suggestion from the user-confirmed times.

Timed general events convert from their extracted source timezone into the upload's selected timezone before preview. St Louis uses `America/Chicago`; daylight-saving changes are date-aware, and all-day dates remain unchanged. On sports schedules LOCAL varies by venue; extraction instructions prefer ET (`America/New_York`) where available. This prompt guidance is not a guarantee against table-reading errors: check times and home/away against the source.

Use **全选新增与更新** to select the batch, edit any needed fields, then **确认加入 Outlook** once. Deletions are not automatically selected, and validation remains mandatory. Old stored previews are not reprocessed; re-upload for new extraction behavior only after checking whether an earlier attempt already wrote calendar events.
