# Application map

The bundled Worker implements cloud email ingestion, classification, notifications, translation, feedback, copy-to-AI preparation, reminder task coordination and event extraction. The user interface is primarily Chinese. It is a single-owner service, not a hosted multi-tenant product.

```mermaid
flowchart TD
    M[Gmail / Outlook] --> I[Authenticated notifications and incremental sync]
    C[Five-minute cron] --> I
    I --> A[AI classification and policy]
    A --> Q[Persistent outbox]
    Q --> P[Pushover]
    P --> W[Worker pages]
    W --> T[Translation / feedback / copy / original mail]
    W --> E[Email event extraction]
    F[PDF / images] --> X[Action queue / HEIC conversion / AI extraction]
    E --> V[Editable preview and user confirmation]
    X --> V
    V --> G[Graph write and readback]
    G --> O[Outlook calendar]
    W --> R[Reminder claim and receipt API]
    D[(D1 state and temporary file parts)]
    I -.-> D
    A -.-> D
    T -.-> D
    X -.-> D
    R -.-> D
    G -.-> D
```

Apple Reminders writing happens on the iPhone through Shortcuts; it is outside this cloud-only diagram. Outlook-to-Apple calendar sync is a client/account setup issue, not a second calendar writer.

## Runtime modules

| Files in `assets/worker/src/` | Responsibility |
|---|---|
| `index.js` | HTTP router, cron, queue dispatch, feedback and translation pages |
| `cloud-mail.js`, `realtime.js` | OAuth, provider cursors, authenticated hooks, subscription renewal |
| `cloud-pipeline.js`, `cloud-migration.js` | Processing, model classification, persisted results, migration/probe endpoints |
| `classification-policy.js`, `classification-config.json`, `feedback-fields.js` | Schema, prompt, category/importance and delivery decisions |
| `notification-format.js`, `delivery-queue.js` | Concise notification content, durable delivery and uncertain-state handling |
| `cloud-content.js`, `original-mail.js` | Readable content and validated source links |
| `cloud-actions.js`, `translation-*.js` | Async translation, streaming, link preservation and status UI |
| `mail-tools.js`, `copy-intent.js`, `copy-launch.js` | Tool routes, copy context and feedback UI |
| `reminder-draft.js`, `iphone-todo*.js` | Action-oriented reminders, signed claims, format compatibility and receipts |
| `outlook-calendar-auth.js`, `outlook-calendar.js` | One designated calendar account, preview, write and readback |
| `schedules.js`, `cloud-schedules.js` | Uploads, lifecycle, editable preview, confirmed task execution |
| `course-extraction.js`, `course-images.js` | General events plus optional course identity, date normalization, Images conversion |
| `calendar-migration.js` | Legacy course migration and bounded read-only audits |
| `deployment-config.js` | Generated non-secret origin and calendar account settings |

The source still defaults to America/Chicago and morning/afternoon digest windows, uses a Chinese reminder list/shortcut name, and limits daily classification. These are documented application defaults, not universal preferences. If changing locale or policy, inspect call sites and tests rather than blind string replacement. Gmail push can be omitted; Outlook JunkEmail review has its own cursor/control state. General extraction adds events; course mode can propose bound updates and explicit cancellations.

Data lives in D1: encrypted mailbox refresh tokens, observations, classification/feedback, outbox, signed-link records, task states, event bindings and temporary file parts. Upload bytes are removed after processing/retention cleanup. There is no R2 binding in the generated deployment; the optional legacy storage reader remains for compatibility. Secrets stay in Worker secrets. OpenAI and provider requests can contain user mail/file data as part of the authorized workflow.
