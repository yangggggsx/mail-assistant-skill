import {notificationSchema,notificationContent} from './notification-format.js';
export const feedbackCategories=notificationSchema.properties.label.enum;
export const feedbackImportance={urgent:'紧急',important:'重要',normal:'普通',low:'低'};
export async function ensureFeedbackFields(env){
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS feedback_dimensions(token TEXT PRIMARY KEY,mail_category TEXT NOT NULL,importance TEXT NOT NULL,submitted_at TEXT NOT NULL)`).run();
}
export function feedbackDefaults(row,c={}){
  return {category:row.mail_category||({newsletter:'订阅资讯',spam:'垃圾邮件'})[row.label]||notificationContent({},c).label,
    importance:row.importance||(['urgent','important','normal'].includes(row.label)?row.label:c.importance)||'normal'};
}
export function compatibilityLabel(category,importance){
  if(category==='垃圾邮件')return 'spam';
  if(['订阅资讯','推广营销'].includes(category))return 'newsletter';
  return ['urgent','important'].includes(importance)?importance:'normal';
}
