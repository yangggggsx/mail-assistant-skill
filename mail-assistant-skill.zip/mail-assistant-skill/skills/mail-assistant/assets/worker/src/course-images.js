// Decode privately inside the existing Cloudflare account. Never publish an image URL.
// Conversion is sequential to keep multi-photo jobs within Worker memory limits.
export async function prepareCourseImage(env,file){
 if(!['image/heic','image/heif'].includes(file.content_type))return file;
 if(!env.IMAGES)throw Error('HEIC 云端解码服务暂不可用，请稍后重试');
 try{
  const result=await env.IMAGES.input(new Blob([file.bytes]).stream())
   .transform({width:4096,height:4096,fit:'scale-down'})
   .output({format:'image/jpeg',quality:95});
  const response=result.response();
  if(!response.ok)throw Error('decode_response');
  const bytes=await response.arrayBuffer(),magic=new Uint8Array(bytes);
  if(bytes.byteLength>20*1024*1024||magic.length<3||magic[0]!==0xff||magic[1]!==0xd8||magic[2]!==0xff)throw Error('decode_output');
  return {...file,filename:String(file.filename||'photo').replace(/\.(heic|heif)$/i,'')+'.jpg',content_type:'image/jpeg',bytes};
 }catch{
  throw Error('HEIC 图片云端解码失败，未写入日历。请稍后重试；若仍失败，请提供该原文件以便检查兼容性');
 }
}
