import test from 'node:test';
import assert from 'node:assert/strict';
import {reminderDraft,reminderInstructions} from './reminder-draft.js';
import {reminderPayload} from './iphone-todo.js';
import config from './classification-config.json' with {type:'json'};
import {validateSchema} from './cloud-migration.js';

test('new classifications carry a separate action draft without changing routing',()=>{
 assert.ok(config.schema.required.includes('todo'));
 const schema=config.schema.properties.todo;
 assert.deepEqual(validateSchema({title:'确认 Walmart $24.36 退款到账',notes:'瑜伽垫退款处理中，到账后勾选完成。'},schema),{title:'确认 Walmart $24.36 退款到账',notes:'瑜伽垫退款处理中，到账后勾选完成。'});
 assert.throws(()=>validateSchema({title:'取件',notes:'',due:'tomorrow'},schema));
 assert.match(reminderInstructions,/不得因此改变 action_required/);
});
test('cached AI title replaces long subject and clean format keeps URL and marker out of notes',()=>{
 const mail={subject:'Very long product name '.repeat(40),classification_json:JSON.stringify({todo:{title:'确认 Walmart $24.36 退款到账',notes:'瑜伽垫退款处理中，到账后勾选完成。'}})};
 const payload=reminderPayload(mail,'a'.repeat(64),'https://example.test','B'.repeat(32),2);
 assert.equal(payload.title,'确认 Walmart $24.36 退款到账');
 assert.equal(payload.notes,'瑜伽垫退款处理中，到账后勾选完成。');
 assert.equal(new URL(payload.url).hash,'#'+payload.marker);
 assert.doesNotMatch(payload.notes,/http|MailAssistant/);
 assert.equal(payload.due,undefined);
 const legacy=reminderPayload(mail,'a'.repeat(64),'https://example.test','B'.repeat(32));
 assert.ok(legacy.notes.includes(legacy.marker));assert.match(legacy.notes,/原邮件：https/);
});
test('old mail uses conservative fallback without new API requests',()=>{
 assert.equal(reminderDraft({}, {summary:'Walmart 已为瑜伽垫发起 24.36 美元退款，退款正在处理中。'}).title,'确认退款到账');
 assert.equal(reminderDraft({}, {summary:'包裹已到快递柜，请及时取件。'}).title,'去取快递');
 assert.equal(reminderDraft({}, {summary:'包裹已送到门口。'}).title,'收取门口包裹');
 assert.equal(reminderDraft({}, {mail_type:'shipping',summary:'预计明天送达，请留意后续取件通知。'}).title,'查看包裹物流');
 assert.notEqual(reminderDraft({}, {mail_type:'shipping',summary:'包裹尚未送达，未准备取件。'}).title,'去取快递');
 assert.equal(reminderDraft({subject:'Invitation'}, {summary:'活动邀请'}).title,'查看并处理邮件');
});
test('draft display is bounded and never imports a URL from model output',()=>{
 const draft=reminderDraft({}, {todo:{title:'测'.repeat(100),notes:'https://evil.test/path '+ '文'.repeat(300)}});
 assert.equal(Array.from(draft.title).length,40);assert.equal(Array.from(draft.notes).length,120);
 assert.doesNotMatch(draft.notes,/evil/);
 assert.doesNotThrow(()=>reminderPayload({classification_json:'null'},'a'.repeat(64),'https://example.test','B'.repeat(32)));
});
