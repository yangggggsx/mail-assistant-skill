import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {translationWaitScript} from './translation-wait.js';
test('SSE updates preserve old paragraphs; disconnect falls back and hidden page closes stream',async()=>{
 const instances=[],events={},timers=[],block={children:[],appendChild(p){this.children.push(p)}},state={};let polls=0;
 class EventSource{constructor(url){this.url=url;instances.push(this)}addEventListener(){}close(){this.closed=true}}
 const document={hidden:false,createElement:()=>({innerHTML:''}),querySelector:s=>s==='#translation-partial'?block:s==='#translation-state'?state:null,addEventListener:(n,f)=>events[n]=f};
 vm.runInNewContext(translationWaitScript,{EventSource,document,window:{addEventListener(){}},location:{pathname:'/f/test/translate'},AbortSignal,setTimeout:f=>{timers.push(f)},clearTimeout(){},fetch:async()=>{polls++;return {ok:true,json:async()=>({status:'pending',paragraphs:['第一段','第二段']})}}});
 assert.equal(instances.length,1);assert.equal(polls,0);
 instances[0].onmessage({data:JSON.stringify({status:'pending',paragraphs:['第一段']})});
 const first=block.children[0];
 instances[0].onmessage({data:JSON.stringify({status:'pending',paragraphs:['第一段','第二段']})});
 assert.equal(block.children[0],first);assert.equal(block.children.length,2);
 instances[0].onerror();await new Promise(r=>setTimeout(r,0));assert.equal(polls,1);assert.equal(instances[0].closed,true);
 document.hidden=true;events.visibilitychange();assert.equal(instances.length,1);
});
test('partial text renders safely without replacing card or navigating',async()=>{
 const timers=[],card={innerHTML:'waiting'},block={children:[],appendChild(p){this.children.push(p);}};
 const context={location:{pathname:'/f/test/translate'},AbortSignal,document:{hidden:false,createElement:()=>({innerHTML:''}),querySelector:s=>s==='.card'?card:s==='#translation-partial'?block:null,addEventListener:()=>{}},window:{addEventListener:()=>{}},setTimeout:f=>{timers.push(f);return 1},clearTimeout:()=>{},fetch:async()=>({ok:true,json:async()=>({status:'pending',paragraphs:['中文&lt;script&gt;alert(1)&lt;/script&gt;']})})};
 vm.runInNewContext(translationWaitScript,context);await timers.shift()();
 assert.equal(card.innerHTML,'waiting');assert.equal(block.children[0].innerHTML,'中文&lt;script&gt;alert(1)&lt;/script&gt;');assert.equal(timers.length,1);
});
test('completion does not replace card or navigate',async()=>{
 const timers=[],events={},card={innerHTML:'waiting'};let calls=0;
 const context={location:{pathname:'/f/test/translate'},AbortSignal,document:{hidden:false,querySelector:()=>card,addEventListener:(n,f)=>events[n]=f},window:{addEventListener:(n,f)=>events[n]=f},setTimeout:f=>{timers.push(f);return timers.length;},clearTimeout:()=>{},fetch:async()=>({ok:true,status:200,json:async()=>++calls===1?{status:'pending'}:{status:'completed',html:'translated'}})};
 vm.runInNewContext(translationWaitScript,context);
 await timers.shift()();assert.equal(card.innerHTML,'waiting');
 await timers.shift()();assert.equal(card.innerHTML,'waiting');assert.equal(timers.length,0);assert.equal(calls,2);
});
test('hidden page does not request; network failure backs off without changing page',async()=>{
 const timers=[],events={},delays=[];let calls=0;
 const context={location:{pathname:'/f/test/translate'},AbortSignal,document:{hidden:true,addEventListener:(n,f)=>events[n]=f},window:{addEventListener:()=>{}},setTimeout:(f,d)=>{timers.push(f);delays.push(d);return 1;},clearTimeout:()=>{},fetch:async()=>{calls++;throw Error('offline')}};
 vm.runInNewContext(translationWaitScript,context);assert.equal(timers.length,0);
 context.document.hidden=false;events.visibilitychange();await timers.shift()();assert.equal(calls,1);assert.equal(delays.at(-1),4000);
});
