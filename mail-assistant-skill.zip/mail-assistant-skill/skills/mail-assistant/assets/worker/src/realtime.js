// Notifications are hints, never email content. Authenticated callbacks enqueue a
// durable job; the existing provider cursors, global lease and hashes own truth.
import {ensureCloudMailSchema,refreshMicrosoftAccessToken,refreshGoogleAccessToken} from './cloud-mail.js';
import {runCloudPipeline} from './cloud-pipeline.js';
import {drainDelivery} from './delivery-queue.js';
import {runCloudAction} from './cloud-actions.js';
import {ORIGIN} from './deployment-config.js';
const MS_RESOURCE="me/mailFolders('Inbox')/messages";
const json=(x,s=200)=>Response.json(x,{status:s,headers:{'cache-control':'no-store'}});
export async function ensureRealtime(env){
  await ensureCloudMailSchema(env);
  await env.DB.batch([
    env.DB.prepare(`CREATE TABLE IF NOT EXISTS realtime_subscriptions(provider TEXT NOT NULL,email TEXT NOT NULL,subscription_id TEXT,client_state TEXT,expires_at TEXT,renew_after TEXT,last_error TEXT,last_notification_at TEXT,PRIMARY KEY(provider,email))`),
    env.DB.prepare(`CREATE TABLE IF NOT EXISTS realtime_control(id INTEGER PRIMARY KEY CHECK(id=1),enabled INTEGER NOT NULL DEFAULT 0,lease TEXT,lease_until TEXT,last_job_at TEXT,last_job_error TEXT)`),
    env.DB.prepare('INSERT OR IGNORE INTO realtime_control(id) VALUES(1)'),
  ]);
}
async function graph(token,path,method='GET',body){
  const r=await fetch('https://graph.microsoft.com/v1.0'+path,{method,signal:AbortSignal.timeout(20000),headers:{authorization:'Bearer '+token,'content-type':'application/json'},body:body?JSON.stringify(body):undefined});
  if(!r.ok){const error=Error('graph_subscription_'+r.status);error.status=r.status;throw error;}
  return r.status===204?{}:r.json();
}
export async function maintainRealtime(env,{msToken=refreshMicrosoftAccessToken,msRequest=graph,googleToken=refreshGoogleAccessToken,fetcher=fetch}={}){
  await ensureRealtime(env);
  const claim=crypto.randomUUID(),now=new Date().toISOString();
  const lock=await env.DB.prepare('UPDATE realtime_control SET lease=?1,lease_until=?2 WHERE id=1 AND enabled=1 AND (lease_until IS NULL OR lease_until<?3)').bind(claim,new Date(Date.now()+180000).toISOString(),now).run();
  if(!lock.meta?.changes)return;
  try{
    const accounts=(await env.DB.prepare("SELECT * FROM cloud_accounts WHERE status='active' AND shadow_mode=0").all()).results||[];
    for(const account of accounts){
      await env.DB.prepare('INSERT OR IGNORE INTO realtime_subscriptions(provider,email,client_state) VALUES(?1,?2,?3)').bind(account.provider,account.email,crypto.randomUUID()+crypto.randomUUID()).run();
      const s=await env.DB.prepare('SELECT * FROM realtime_subscriptions WHERE provider=?1 AND email=?2').bind(account.provider,account.email).first();
      if(s.renew_after && s.renew_after>now)continue;
      try{
        if(account.provider==='microsoft'){
          const {access_token}=await msToken(account,env),expiry=new Date(Date.now()+6*86400000).toISOString();
          let remote;
          if(s.subscription_id){
            try{remote=await msRequest(access_token,'/subscriptions/'+encodeURIComponent(s.subscription_id),'PATCH',{expirationDateTime:expiry});}
            catch(e){if(![404,410].includes(e.status))throw e;}
          }
          if(!remote){
            // Recover a create whose HTTP response / D1 write was lost.
            const list=await msRequest(access_token,'/subscriptions','GET');
            for(const candidate of list.value||[]){
              if(candidate.notificationUrl!==ORIGIN+'/hooks/microsoft'||candidate.resource!==MS_RESOURCE||Date.parse(candidate.expirationDateTime)<=Date.now())continue;
              // Graph may omit clientState in list responses; fetch only our
              // known callback/resource candidate before adopting its secret.
              const detail=candidate.clientState?candidate:await msRequest(access_token,'/subscriptions/'+encodeURIComponent(candidate.id),'GET');
              if(detail.clientState===s.client_state){remote=detail;break;}
            }
            if(!remote)remote=await msRequest(access_token,'/subscriptions','POST',{changeType:'created',resource:MS_RESOURCE,notificationUrl:ORIGIN+'/hooks/microsoft',lifecycleNotificationUrl:ORIGIN+'/hooks/microsoft',expirationDateTime:expiry,clientState:s.client_state});
          }
          if(!remote.id)throw Error('invalid_subscription');
          await env.DB.prepare('UPDATE realtime_subscriptions SET subscription_id=?1,expires_at=?2,renew_after=?3,last_error=NULL WHERE provider=?4 AND email=?5').bind(remote.id,remote.expirationDateTime||expiry,new Date(Math.min(Date.now()+86400000,Date.parse(remote.expirationDateTime||expiry)-86400000)).toISOString(),account.provider,account.email).run();
        }else if(account.provider==='google'){
          if(!env.GMAIL_PUBSUB_TOPIC || !env.GMAIL_PUSH_SERVICE_ACCOUNT || !env.GMAIL_PUBSUB_SUBSCRIPTION){
            await env.DB.prepare("UPDATE realtime_subscriptions SET last_error='google_pubsub_setup_required' WHERE provider='google' AND email=?1").bind(account.email).run();continue;
          }
          const {access_token}=await googleToken(account,env);
          const r=await fetcher('https://gmail.googleapis.com/gmail/v1/users/me/watch',{method:'POST',signal:AbortSignal.timeout(20000),headers:{authorization:'Bearer '+access_token,'content-type':'application/json'},body:JSON.stringify({topicName:env.GMAIL_PUBSUB_TOPIC,labelIds:['INBOX'],labelFilterBehavior:'include'})});
          if(!r.ok)throw Error('gmail_watch_'+r.status);
          const result=await r.json();if(!Number.isFinite(Number(result.expiration)))throw Error('invalid_watch');
          // Never overwrite history_cursor with watch's historyId: would skip mail.
          await env.DB.prepare("UPDATE realtime_subscriptions SET subscription_id=?1,expires_at=?2,renew_after=?3,last_error=NULL WHERE provider='google' AND email=?4").bind(env.GMAIL_PUBSUB_SUBSCRIPTION,new Date(Number(result.expiration)).toISOString(),new Date(Date.now()+86400000).toISOString(),account.email).run();
        }
      }catch(e){
        const safe=/^(graph_subscription|gmail_watch)_\d{3}$/.test(e.message)?e.message:'subscription_renewal_failed';
        await env.DB.prepare('UPDATE realtime_subscriptions SET last_error=?1,renew_after=?2 WHERE provider=?3 AND email=?4').bind(safe,new Date(Date.now()+30*60000).toISOString(),account.provider,account.email).run();
      }
    }
  }finally{await env.DB.prepare('UPDATE realtime_control SET lease=NULL,lease_until=NULL WHERE id=1 AND lease=?1').bind(claim).run();}
}
function decode(s){return Uint8Array.from(atob(s.replaceAll('-','+').replaceAll('_','/')),c=>c.charCodeAt(0));}
let jwksCache;
export async function verifyGooglePush(request,env,fetcher=fetch){
  const token=(request.headers.get('authorization')||'').match(/^Bearer ([\w.-]+)$/)?.[1];
  if(!token||token.length>10000||!env.GMAIL_PUSH_SERVICE_ACCOUNT)return false;
  try{
    const [a,b,c,...rest]=token.split('.');if(rest.length||!c)return false;
    const h=JSON.parse(new TextDecoder().decode(decode(a))),p=JSON.parse(new TextDecoder().decode(decode(b))),now=Date.now()/1000;
    if(h.alg!=='RS256'||!h.kid||!['accounts.google.com','https://accounts.google.com'].includes(p.iss)||p.aud!==ORIGIN+'/hooks/google'||p.email!==env.GMAIL_PUSH_SERVICE_ACCOUNT||p.email_verified!==true||!Number.isFinite(p.exp)||p.exp<=now||!Number.isFinite(p.iat)||p.iat>now+60||now-p.iat>7200)return false;
    if(!jwksCache||jwksCache.until<Date.now()){
      const r=await fetcher('https://www.googleapis.com/oauth2/v3/certs',{signal:AbortSignal.timeout(5000)});if(!r.ok)return false;
      jwksCache={keys:(await r.json()).keys,until:Date.now()+300000};
    }
    const jwk=jwksCache.keys.find(k=>k.kid===h.kid);if(!jwk)return false;
    const key=await crypto.subtle.importKey('jwk',jwk,{name:'RSASSA-PKCS1-v1_5',hash:'SHA-256'},false,['verify']);
    return crypto.subtle.verify('RSASSA-PKCS1-v1_5',key,decode(c),new TextEncoder().encode(a+'.'+b));
  }catch{return false;}
}
export async function handleRealtime(request,env,url,authorized,{verifyGoogle=verifyGooglePush}={}){
  const hook=['/hooks/microsoft','/hooks/google'].includes(url.pathname),admin=url.pathname.startsWith('/api/cloud/realtime/');
  if(!hook&&!admin)return null;
  if(admin&&!authorized)return json({error:'unauthorized'},401);
  // Microsoft endpoint validation is deliberately non-mutating and plain text.
  if(url.pathname==='/hooks/microsoft'&&request.method==='POST'&&url.searchParams.has('validationToken')){
    const value=url.searchParams.get('validationToken');if(value.length>4096)return json({error:'size'},400);
    return new Response(value,{headers:{'content-type':'text/plain','cache-control':'no-store','x-content-type-options':'nosniff'}});
  }
  if(hook&&request.method!=='POST')return json({error:'method'},405);
  if(hook&&url.pathname==='/hooks/google'&&!(await verifyGoogle(request,env)))return json({error:'unauthorized'},401);
  await ensureRealtime(env);
  if(admin){
    if(url.pathname.endsWith('/status')&&request.method==='GET'){
      const control=await env.DB.prepare('SELECT enabled,last_job_at,last_job_error FROM realtime_control WHERE id=1').first();
      const subs=await env.DB.prepare('SELECT provider,email,subscription_id,expires_at,renew_after,last_error,last_notification_at FROM realtime_subscriptions').all();
      return json({...control,subscriptions:subs.results||[],google_setup_ready:!!(env.GMAIL_PUBSUB_TOPIC&&env.GMAIL_PUSH_SERVICE_ACCOUNT&&env.GMAIL_PUBSUB_SUBSCRIPTION)});
    }
    if(url.pathname.endsWith('/enable')&&request.method==='POST'){
      if(!env.REALTIME_QUEUE)return json({error:'queue_unavailable'},503);
      await env.DB.prepare('UPDATE realtime_control SET enabled=1 WHERE id=1').run();
      await env.REALTIME_QUEUE.send({type:'maintain'});return json({queued:true},202);
    }
    if(url.pathname.endsWith('/test')&&request.method==='POST'){
      // Fixed operational test: no synthetic email, no model or phone message.
      await env.REALTIME_QUEUE.send({type:'health'});return json({queued:true},202);
    }
    return json({error:'not_found'},404);
  }
  const control=await env.DB.prepare('SELECT enabled FROM realtime_control WHERE id=1').first();
  if(!control.enabled)return json({error:'disabled'},503);
  const raw=await request.text();if(raw.length>65536)return json({error:'size'},413);
  let body;try{body=JSON.parse(raw);}catch{return json({error:'json'},400);}
  const matched=[];
  if(url.pathname==='/hooks/microsoft'){
    if(!Array.isArray(body.value)||body.value.length>100)return json({error:'format'},400);
    for(const n of body.value){
      if(typeof n.subscriptionId!=='string'||typeof n.clientState!=='string')continue;
      const s=await env.DB.prepare("SELECT s.* FROM realtime_subscriptions s JOIN cloud_accounts a ON a.provider=s.provider AND a.email=s.email WHERE s.provider='microsoft' AND s.subscription_id=?1 AND a.status='active' AND a.shadow_mode=0").bind(n.subscriptionId).first();
      if(s&&n.clientState===s.client_state && (n.changeType==='created'||['reauthorizationRequired','subscriptionRemoved','missed'].includes(n.lifecycleEvent)))matched.push({...s,lifecycle:n.lifecycleEvent});
    }
  }else{
    if(body.subscription!==env.GMAIL_PUBSUB_SUBSCRIPTION)return json({error:'subscription'},403);
    let data;try{data=JSON.parse(new TextDecoder().decode(decode(body.message?.data||'')));}catch{return json({error:'format'},400);}
    if(typeof data.emailAddress!=='string'||!/^\d+$/.test(String(data.historyId)))return json({error:'format'},400);
    const s=await env.DB.prepare("SELECT s.* FROM realtime_subscriptions s JOIN cloud_accounts a ON a.provider=s.provider AND a.email=s.email WHERE s.provider='google' AND s.email=?1 AND a.status='active' AND a.shadow_mode=0").bind(data.emailAddress.toLowerCase()).first();
    if(s)matched.push(s);
  }
  if(!matched.length)return json({error:'unrecognized_notification'},403);
  // A queue failure must not ACK to the provider. Retried notifications are safe.
  await env.REALTIME_QUEUE.send({type:'mail',received_at:new Date().toISOString()});
  for(const s of matched){
    await env.DB.prepare('UPDATE realtime_subscriptions SET last_notification_at=?1 WHERE provider=?2 AND email=?3').bind(new Date().toISOString(),s.provider,s.email).run();
    if(s.lifecycle)await env.DB.prepare("UPDATE realtime_subscriptions SET renew_after=NULL WHERE provider='microsoft' AND email=?1").bind(s.email).run();
  }
  return json({accepted:true},202);
}
export async function consumeRealtime(batch,env,{run=runCloudPipeline,drain=drainDelivery,maintain=maintainRealtime,action=runCloudAction}={}){
  await ensureRealtime(env);
  for(const job of batch.messages){
    try{
      if(job.body.type==='action'){
        const {kind,key}=job.body;
        if((kind==='copy' && /^[a-f0-9]{64}$/.test(key||'')) || (kind==='translate' && /^[A-Za-z0-9_-]{32}$/.test(key||''))){
          await action(env,kind,key);await drain(env);
        }
        job.ack();continue;
      }
      const enabled=(await env.DB.prepare('SELECT enabled FROM realtime_control WHERE id=1').first()).enabled;
      if(!enabled){job.ack();continue;}
      if(job.body.type==='maintain')await maintain(env);
      else if(job.body.type==='mail'){
        const result=await run(env);await drain(env);
        if(result.skipped){job.retry({delaySeconds:30});continue;}
        // Continue bounded backlog without reclassifying saved records.
        if(result.processed===5)await env.REALTIME_QUEUE.send({type:'mail',received_at:new Date().toISOString()});
      }else if(job.body.type!=='health'){job.ack();continue;}
      await env.DB.prepare('UPDATE realtime_control SET last_job_at=?1,last_job_error=NULL WHERE id=1').bind(new Date().toISOString()).run();job.ack();
    }catch{
      await env.DB.prepare("UPDATE realtime_control SET last_job_error='realtime_job_failed' WHERE id=1").run();job.retry({delaySeconds:60});
    }
  }
}
