const esc=v=>String(v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const urls=/https?:\/\/[^\s<>"\u3000]+/gi;
function splitEnd(raw){
 let value=raw.replace(/[。，；！？、.,;!]+$/u,'');
 while(value.endsWith(')')&&(value.match(/\)/g)||[]).length>(value.match(/\(/g)||[]).length)value=value.slice(0,-1);
 while(value.endsWith(']')&&!value.includes('['))value=value.slice(0,-1);
 return [value,raw.slice(value.length)];
}
function safe(value){try{const u=new URL(value);return ['http:','https:'].includes(u.protocol)&&!u.username&&!u.password;}catch{return false;}}
export function protectTranslationLinks(text){
 const prefix='MAILURL'+crypto.randomUUID().replaceAll('-','')+'X',links=[];
 const input=String(text).replace(urls,raw=>{
  const [url,end]=splitEnd(raw);if(!safe(url))return raw;
  const marker=prefix+links.length+'END';links.push({marker,url});return marker+end;
 });
 return {input,restore(text){
  let result=String(text);
  for(const {marker,url} of links)result=result.replaceAll(marker,url);
  // Hide an unfinished marker at the current stream tail, never show a fake link.
  for(let n=1;n<=prefix.length;n++)if(result.endsWith(prefix.slice(0,n)))return result.slice(0,-n);
  return result.replace(new RegExp(prefix+'[0-9]*(?:E|EN)?$'),'');
 }};
}
export function translationText(text){return String(text||'').replace(/^说明：仅翻译可读正文，附件与图片未包含；长邮件最多处理 12000 字符。\s*/,'');}
export function translationParagraphs(text){
 return translationText(text).split(/\n\s*\n/).filter(Boolean).map(part=>{
  let html='',position=0;
  for(const match of part.matchAll(urls)){
   html+=esc(part.slice(position,match.index));const [url,end]=splitEnd(match[0]);
   html+=safe(url)?`<a href="${esc(url)}" target="_blank" rel="noopener noreferrer" referrerpolicy="no-referrer">${esc(url)}</a>${esc(end)}`:esc(match[0]);
   position=match.index+match[0].length;
  }
  return html+esc(part.slice(position));
 });
}
export function translationMarkup(text){return translationParagraphs(text).map(p=>`<div class="translation-paragraph">${p}</div>`).join('');}
