import test from 'node:test';
import assert from 'node:assert/strict';
import {protectTranslationLinks,translationMarkup} from './translation-links.js';
import {translateText} from './cloud-actions.js';
test('URLs including secret query parameters never reach model and restore exactly',async()=>{
 const original='https://example.com/grade?token=private&x=1';
 const result=await translateText({OPENAI_API_KEY:'test',MAIL_AI_MODEL:'test'},{subject:'成绩',sender:'a'},'查看 '+original,async(_,opts)=>{
  const body=JSON.parse(opts.body);assert.ok(!body.input.includes('private'));assert.ok(!body.input.includes(original));
  const marker=body.input.match(/MAILURL[a-f0-9]+X\d+END/)[0];
  return Response.json({status:'completed',output:[{content:[{type:'output_text',text:'查看成绩 '+marker}]}]});
 });
 assert.equal(result.text,'查看成绩 '+original);
 const html=translationMarkup(result.text);assert.match(html,/href="https:\/\/example.com\/grade\?token=private&amp;x=1"/);
});
test('renderer escapes HTML and never makes script or credential links clickable',()=>{
 const html=translationMarkup('<script>bad()</script> javascript:alert(1) https://user:pass@example.com/a\n\nhttps://example.com/a?q=1&b=2。');
 assert.doesNotMatch(html,/<script>|href="javascript:|href="https:\/\/user/);
 assert.match(html,/&lt;script&gt;/);assert.match(html,/rel="noopener noreferrer"/);assert.match(html,/b=2"/);
});
test('partial markers hidden and URL punctuation preserved',()=>{
 const protectedText=protectTranslationLinks('看 https://example.com/a(b)。');
 assert.equal(protectedText.restore(protectedText.input),'看 https://example.com/a(b)。');
 const marker=protectedText.input.match(/MAILURL[a-f0-9]+X\d+END/)[0];
 assert.equal(protectedText.restore('看 '+marker.slice(0,-2)),'看 ');
 assert.equal(protectedText.restore('看 '+marker.slice(0,5)),'看 ');
});
