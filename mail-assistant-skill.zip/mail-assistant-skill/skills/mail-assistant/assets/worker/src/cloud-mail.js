const GOOGLE_SCOPE = "openid email https://www.googleapis.com/auth/gmail.readonly";
const MICROSOFT_SCOPE = "openid profile email offline_access User.Read Mail.Read";

function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      "content-type": "application/json; charset=utf-8",
      "cache-control": "no-store",
      "x-content-type-options": "nosniff",
    },
  });
}

function page(title, message, status = 200) {
  return new Response(`<!doctype html><html lang="zh-CN"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>${escapeHtml(title)}</title>
<style>body{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;background:#f4f5f7;margin:0;padding:28px;color:#171717}.card{max-width:520px;margin:12vh auto;background:#fff;border-radius:22px;padding:26px;box-shadow:0 10px 35px #0001}h1{font-size:24px;margin:0 0 12px}p{color:#555;line-height:1.55;margin:0}</style>
</head><body><main class="card"><h1>${escapeHtml(title)}</h1><p>${escapeHtml(message)}</p></main></body></html>`, {
    status,
    headers: {
      "content-type": "text/html; charset=utf-8",
      "cache-control": "no-store",
      "content-security-policy": "default-src 'none'; style-src 'unsafe-inline'; frame-ancestors 'none'; base-uri 'none'",
      "referrer-policy": "no-referrer",
      "x-content-type-options": "nosniff",
    },
  });
}

function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>"']/g, (character) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;",
  })[character]);
}

function randomToken(byteLength = 32) {
  const bytes = new Uint8Array(byteLength);
  crypto.getRandomValues(bytes);
  return base64UrlEncode(bytes);
}

function base64UrlEncode(bytes) {
  let binary = "";
  for (const byte of bytes) binary += String.fromCharCode(byte);
  return btoa(binary).replaceAll("+", "-").replaceAll("/", "_").replaceAll("=", "");
}

function base64UrlDecode(value) {
  const base64 = value.replaceAll("-", "+").replaceAll("_", "/") + "===".slice((value.length + 3) % 4);
  const binary = atob(base64);
  return Uint8Array.from(binary, (character) => character.charCodeAt(0));
}

async function encryptionKey(env) {
  if (!env.TOKEN_ENCRYPTION_KEY) throw new Error("TOKEN_ENCRYPTION_KEY is not configured");
  const raw = base64UrlDecode(env.TOKEN_ENCRYPTION_KEY.trim());
  if (raw.byteLength !== 32) throw new Error("TOKEN_ENCRYPTION_KEY must decode to 32 bytes");
  return crypto.subtle.importKey("raw", raw, "AES-GCM", false, ["encrypt", "decrypt"]);
}

export async function encryptSecret(value, env) {
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const ciphertext = new Uint8Array(await crypto.subtle.encrypt(
    { name: "AES-GCM", iv }, await encryptionKey(env), new TextEncoder().encode(value),
  ));
  const packed = new Uint8Array(iv.length + ciphertext.length);
  packed.set(iv);
  packed.set(ciphertext, iv.length);
  return `v1.${base64UrlEncode(packed)}`;
}

export async function decryptSecret(value, env) {
  const [version, encoded] = String(value || "").split(".", 2);
  if (version !== "v1" || !encoded) throw new Error("Unsupported encrypted token format");
  const packed = base64UrlDecode(encoded);
  const plaintext = await crypto.subtle.decrypt(
    { name: "AES-GCM", iv: packed.slice(0, 12) }, await encryptionKey(env), packed.slice(12),
  );
  return new TextDecoder().decode(plaintext);
}

export async function ensureCloudMailSchema(env) {
  await env.DB.batch([
    env.DB.prepare(`CREATE TABLE IF NOT EXISTS oauth_states (
      state TEXT PRIMARY KEY,
      provider TEXT NOT NULL,
      created_at TEXT NOT NULL,
      expires_at TEXT NOT NULL,
      consumed_at TEXT
    )`),
    env.DB.prepare(`CREATE TABLE IF NOT EXISTS cloud_accounts (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      provider TEXT NOT NULL,
      email TEXT NOT NULL,
      refresh_token_enc TEXT NOT NULL,
      history_cursor TEXT,
      status TEXT NOT NULL DEFAULT 'active',
      shadow_mode INTEGER NOT NULL DEFAULT 1,
      connected_at TEXT NOT NULL,
      last_sync_at TEXT,
      last_success_at TEXT,
      last_error TEXT,
      UNIQUE(provider,email)
    )`),
    env.DB.prepare(`CREATE TABLE IF NOT EXISTS cloud_mail_observations (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      provider TEXT NOT NULL,
      account_email TEXT NOT NULL,
      external_message_id TEXT NOT NULL,
      external_thread_id TEXT,
      subject TEXT,
      sender TEXT,
      received_at TEXT,
      snippet TEXT,
      first_observed_at TEXT NOT NULL,
      source TEXT NOT NULL,
      UNIQUE(provider,account_email,external_message_id)
    )`),
    env.DB.prepare("CREATE INDEX IF NOT EXISTS idx_oauth_states_expiry ON oauth_states(expires_at)"),
    env.DB.prepare("CREATE INDEX IF NOT EXISTS idx_cloud_accounts_status ON cloud_accounts(status,provider)"),
    env.DB.prepare("CREATE INDEX IF NOT EXISTS idx_cloud_observations_time ON cloud_mail_observations(provider,account_email,first_observed_at)"),
    env.DB.prepare(`CREATE TABLE IF NOT EXISTS cloud_junk_control(id INTEGER PRIMARY KEY,enabled INTEGER NOT NULL DEFAULT 0,cutover TEXT)`),
    env.DB.prepare('INSERT OR IGNORE INTO cloud_junk_control(id) VALUES(1)'),
    env.DB.prepare(`CREATE TABLE IF NOT EXISTS cloud_folder_cursors(email TEXT NOT NULL,folder TEXT NOT NULL,cursor TEXT,last_success_at TEXT,last_error TEXT,PRIMARY KEY(email,folder))`),
  ]);
}

function googleConfigured(env) {
  return Boolean(env.GOOGLE_CLIENT_ID && env.GOOGLE_CLIENT_SECRET && env.TOKEN_ENCRYPTION_KEY);
}

function microsoftConfigured(env) {
  return Boolean(env.MICROSOFT_CLIENT_ID && env.MICROSOFT_CLIENT_SECRET && env.TOKEN_ENCRYPTION_KEY);
}

export async function startGoogleOAuth(env, origin) {
  await ensureCloudMailSchema(env);
  if (!googleConfigured(env)) return json({ error: "google_oauth_not_configured" }, 503);
  const state = randomToken();
  const now = new Date();
  const expires = new Date(now.getTime() + 10 * 60 * 1000);
  await env.DB.prepare(`INSERT INTO oauth_states(state,provider,created_at,expires_at)
    VALUES(?1,'google',?2,?3)`).bind(state, now.toISOString(), expires.toISOString()).run();
  await env.DB.prepare("DELETE FROM oauth_states WHERE expires_at < ?1")
    .bind(new Date(now.getTime() - 24 * 60 * 60 * 1000).toISOString()).run();
  const redirectUri = `${origin}/oauth/google/callback`;
  const url = new URL("https://accounts.google.com/o/oauth2/v2/auth");
  url.searchParams.set("client_id", env.GOOGLE_CLIENT_ID);
  url.searchParams.set("redirect_uri", redirectUri);
  url.searchParams.set("response_type", "code");
  url.searchParams.set("scope", GOOGLE_SCOPE);
  url.searchParams.set("access_type", "offline");
  url.searchParams.set("include_granted_scopes", "true");
  url.searchParams.set("prompt", "consent");
  url.searchParams.set("state", state);
  return json({ authorization_url: url.toString(), expires_at: expires.toISOString() });
}

async function googleTokenRequest(parameters, env) {
  const response = await fetch("https://oauth2.googleapis.com/token", {
    signal: AbortSignal.timeout(20000),
    method: "POST",
    headers: { "content-type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams(parameters),
  });
  const body = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(`Google token exchange failed (${response.status}): ${body.error || "unknown_error"}`);
  return body;
}

async function gmailJson(path, accessToken) {
  const response = await fetch(`https://gmail.googleapis.com/gmail/v1/users/me${path}`, {
    signal: AbortSignal.timeout(20000),
    headers: { authorization: `Bearer ${accessToken}` },
  });
  const body = await response.json().catch(() => ({}));
  if (!response.ok) {
    const error = new Error(`Gmail API failed (${response.status}): ${body.error?.message || "unknown_error"}`);
    error.status = response.status;
    throw error;
  }
  return body;
}

export async function handleGoogleCallback(request, env) {
  await ensureCloudMailSchema(env);
  const url = new URL(request.url);
  if (url.searchParams.get("error")) return page("授权未完成", `Google 返回：${url.searchParams.get("error")}`, 400);
  const state = url.searchParams.get("state") || "";
  const code = url.searchParams.get("code") || "";
  const now = new Date().toISOString();
  const savedState = await env.DB.prepare(`SELECT state FROM oauth_states
    WHERE state=?1 AND provider='google' AND consumed_at IS NULL AND expires_at>?2`).bind(state, now).first();
  if (!savedState || !code) return page("授权链接无效", "链接可能已过期或已使用，请重新发起迁移。", 400);
  await env.DB.prepare("UPDATE oauth_states SET consumed_at=?1 WHERE state=?2 AND consumed_at IS NULL")
    .bind(now, state).run();

  try {
    const redirectUri = `${url.origin}/oauth/google/callback`;
    const tokens = await googleTokenRequest({
      code,
      client_id: env.GOOGLE_CLIENT_ID,
      client_secret: env.GOOGLE_CLIENT_SECRET,
      redirect_uri: redirectUri,
      grant_type: "authorization_code",
    }, env);
    const profile = await gmailJson("/profile", tokens.access_token);
    const email = String(profile.emailAddress || "").trim().toLowerCase();
    if (!email) throw new Error("Google did not return a mailbox address");
    const existing = await env.DB.prepare(
      "SELECT refresh_token_enc FROM cloud_accounts WHERE provider='google' AND email=?1",
    ).bind(email).first();
    let encryptedRefreshToken = existing?.refresh_token_enc || "";
    if (tokens.refresh_token) encryptedRefreshToken = await encryptSecret(tokens.refresh_token, env);
    if (!encryptedRefreshToken) throw new Error("Google did not issue an offline refresh token; please revoke the app grant and try again");

    await env.DB.prepare(`INSERT INTO cloud_accounts
      (provider,email,refresh_token_enc,history_cursor,status,shadow_mode,connected_at,last_error)
      VALUES('google',?1,?2,NULL,'active',1,?3,NULL)
      ON CONFLICT(provider,email) DO UPDATE SET
        refresh_token_enc=excluded.refresh_token_enc,
        history_cursor=NULL,
        status='active',
        shadow_mode=1,
        connected_at=excluded.connected_at,
        last_error=NULL`)
      .bind(email, encryptedRefreshToken, now).run();

    await syncGoogleAccount(env, { provider: "google", email, refresh_token_enc: encryptedRefreshToken, history_cursor: null });
    return page("Gmail 已连接 ✓", `${email} 已进入只读影子扫描。当前只记录比对，不会重复推送，也不会修改邮件。你可以关闭此页。`);
  } catch (error) {
    return page("Gmail 连接失败", String(error?.message || error), 500);
  }
}

export async function startMicrosoftOAuth(env, origin) {
  await ensureCloudMailSchema(env);
  if (!microsoftConfigured(env)) return json({ error: "microsoft_oauth_not_configured" }, 503);
  const state = randomToken();
  const now = new Date();
  const expires = new Date(now.getTime() + 10 * 60 * 1000);
  await env.DB.prepare(`INSERT INTO oauth_states(state,provider,created_at,expires_at)
    VALUES(?1,'microsoft',?2,?3)`).bind(state, now.toISOString(), expires.toISOString()).run();
  await env.DB.prepare("DELETE FROM oauth_states WHERE expires_at < ?1")
    .bind(new Date(now.getTime() - 24 * 60 * 60 * 1000).toISOString()).run();
  const redirectUri = `${origin}/oauth/microsoft/callback`;
  const url = new URL("https://login.microsoftonline.com/common/oauth2/v2.0/authorize");
  url.searchParams.set("client_id", env.MICROSOFT_CLIENT_ID);
  url.searchParams.set("redirect_uri", redirectUri);
  url.searchParams.set("response_type", "code");
  url.searchParams.set("response_mode", "query");
  url.searchParams.set("scope", MICROSOFT_SCOPE);
  url.searchParams.set("prompt", "select_account");
  url.searchParams.set("state", state);
  return json({ authorization_url: url.toString(), expires_at: expires.toISOString() });
}

async function microsoftTokenRequest(parameters, env) {
  const response = await fetch("https://login.microsoftonline.com/common/oauth2/v2.0/token", {
    signal: AbortSignal.timeout(20000),
    method: "POST",
    headers: { "content-type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams(parameters),
  });
  const body = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(`Microsoft token exchange failed (${response.status}): ${body.error_description || body.error || "unknown_error"}`);
  return body;
}

async function graphJson(pathOrUrl, accessToken) {
  const target = pathOrUrl.startsWith("https://") ? pathOrUrl : `https://graph.microsoft.com/v1.0${pathOrUrl}`;
  const response = await fetch(target, { signal: AbortSignal.timeout(20000), headers: { authorization: `Bearer ${accessToken}` } });
  const body = await response.json().catch(() => ({}));
  if (!response.ok) {
    const error = new Error(`Microsoft Graph failed (${response.status}): ${body.error?.message || "unknown_error"}`);
    error.status = response.status;
    throw error;
  }
  return body;
}

const MICROSOFT_DELTA_SELECT = "id,conversationId,subject,from,receivedDateTime,bodyPreview,webLink";

export function isMicrosoftDeltaCursor(value) {
  try {
    const url = new URL(String(value || ""));
    const path = url.pathname.toLowerCase();
    const tokenNames = new Set([...url.searchParams.keys()].map((key) => key.toLowerCase()));
    return url.protocol === "https:"
      && url.hostname === "graph.microsoft.com"
      && path.includes("/mailfolders")
      && path.endsWith("/messages/delta")
      && (tokenNames.has("$deltatoken") || tokenNames.has("$skiptoken"));
  } catch {
    return false;
  }
}

export function microsoftDeltaInitialPath(now = new Date(),folder='inbox',cutover=null) {
  if(!['inbox','junkemail'].includes(folder))throw Error('unsupported_folder');
  const since = cutover || new Date(now.getTime() - 2 * 24 * 60 * 60 * 1000).toISOString();
  const query = new URLSearchParams({
    changeType: "created",
    "$select": MICROSOFT_DELTA_SELECT,
    "$filter": `receivedDateTime ge ${since}`,
    "$top": "50",
  });
  return `/me/mailFolders/${folder}/messages/delta?${query}`;
}

export async function collectMicrosoftDelta(
  accessToken, historyCursor, graphRequest = graphJson, now = new Date(),folder='inbox',cutover=null,
) {
  let target = isMicrosoftDeltaCursor(historyCursor)
    ? historyCursor
    : microsoftDeltaInitialPath(now,folder,cutover);
  const messages = [];
  let pages = 0;
  let deltaLink = "";
  while (target) {
    pages += 1;
    if (pages > 10) throw new Error("Microsoft delta sync exceeded 10 pages; cursor was not advanced");
    const pageBody = await graphRequest(target, accessToken);
    for (const message of pageBody.value || []) {
      if (message?.id && !message["@removed"]) messages.push(message);
    }
    const nextLink = String(pageBody["@odata.nextLink"] || "");
    if (nextLink) {
      if (!nextLink.startsWith("https://graph.microsoft.com/")) {
        throw new Error("Microsoft delta returned an invalid nextLink host");
      }
      target = nextLink;
      continue;
    }
    deltaLink = String(pageBody["@odata.deltaLink"] || "");
    if (!isMicrosoftDeltaCursor(deltaLink)) {
      throw new Error("Microsoft delta response did not include a valid deltaLink");
    }
    target = "";
  }
  return { messages, deltaLink, pages };
}

export async function handleMicrosoftCallback(request, env) {
  await ensureCloudMailSchema(env);
  const url = new URL(request.url);
  if (url.searchParams.get("error")) {
    return page("授权未完成", url.searchParams.get("error_description") || url.searchParams.get("error"), 400);
  }
  const state = url.searchParams.get("state") || "";
  const code = url.searchParams.get("code") || "";
  const now = new Date().toISOString();
  const savedState = await env.DB.prepare(`SELECT state FROM oauth_states
    WHERE state=?1 AND provider='microsoft' AND consumed_at IS NULL AND expires_at>?2`).bind(state, now).first();
  if (!savedState || !code) return page("授权链接无效", "链接可能已过期或已使用，请重新发起迁移。", 400);
  await env.DB.prepare("UPDATE oauth_states SET consumed_at=?1 WHERE state=?2 AND consumed_at IS NULL")
    .bind(now, state).run();

  try {
    const redirectUri = `${url.origin}/oauth/microsoft/callback`;
    const tokens = await microsoftTokenRequest({
      code,
      client_id: env.MICROSOFT_CLIENT_ID,
      client_secret: env.MICROSOFT_CLIENT_SECRET,
      redirect_uri: redirectUri,
      grant_type: "authorization_code",
      scope: MICROSOFT_SCOPE,
    }, env);
    const me = await graphJson("/me?$select=mail,userPrincipalName", tokens.access_token);
    const email = String(me.mail || me.userPrincipalName || "").trim().toLowerCase();
    if (!email || !tokens.refresh_token) throw new Error("Microsoft did not return an offline mailbox credential");
    const encryptedRefreshToken = await encryptSecret(tokens.refresh_token, env);
    await env.DB.prepare(`INSERT INTO cloud_accounts
      (provider,email,refresh_token_enc,history_cursor,status,shadow_mode,connected_at,last_error)
      VALUES('microsoft',?1,?2,NULL,'active',1,?3,NULL)
      ON CONFLICT(provider,email) DO UPDATE SET
        refresh_token_enc=excluded.refresh_token_enc,
        history_cursor=NULL,
        status='active',
        shadow_mode=1,
        connected_at=excluded.connected_at,
        last_error=NULL`)
      .bind(email, encryptedRefreshToken, now).run();
    await syncMicrosoftAccount(env, {
      provider: "microsoft", email, refresh_token_enc: encryptedRefreshToken, history_cursor: null,
    });
    return page("Microsoft 邮箱已连接 ✓", `${email} 已进入只读影子扫描。当前只记录比对，不会重复推送，也不会修改邮件。你可以关闭此页。`);
  } catch (error) {
    return page("Microsoft 邮箱连接失败", String(error?.message || error), 500);
  }
}

export async function refreshGoogleAccessToken(account, env) {
  const refreshToken = await decryptSecret(account.refresh_token_enc, env);
  return googleTokenRequest({
    client_id: env.GOOGLE_CLIENT_ID,
    client_secret: env.GOOGLE_CLIENT_SECRET,
    refresh_token: refreshToken,
    grant_type: "refresh_token",
  }, env);
}

function headerValue(message, name) {
  const headers = message.payload?.headers || [];
  return String(headers.find((item) => String(item.name).toLowerCase() === name.toLowerCase())?.value || "").slice(0, 1000);
}

async function fetchGmailMetadata(messageId, accessToken) {
  const query = new URLSearchParams({ format: "metadata" });
  for (const header of ["Subject", "From", "Date", "Message-ID"]) query.append("metadataHeaders", header);
  return gmailJson(`/messages/${encodeURIComponent(messageId)}?${query}`, accessToken);
}

async function recordGmailMessages(env, email, messages, source) {
  if (!messages.length) return 0;
  const now = new Date().toISOString();
  const statements = messages.map((message) => env.DB.prepare(`INSERT OR IGNORE INTO cloud_mail_observations
    (provider,account_email,external_message_id,external_thread_id,subject,sender,received_at,snippet,first_observed_at,source)
    VALUES('google',?1,?2,?3,?4,?5,?6,?7,?8,?9)`)
    .bind(
      email,
      message.id,
      message.threadId || null,
      headerValue(message, "Subject").slice(0, 500),
      headerValue(message, "From").slice(0, 500),
      message.internalDate ? new Date(Number(message.internalDate)).toISOString() : null,
      String(message.snippet || "").slice(0, 1000),
      now,
      source,
    ));
  const results = await env.DB.batch(statements);
  return results.reduce((total, result) => total + Number(result.meta?.changes || 0), 0);
}

export async function collectGmailBaseline(accessToken, get = gmailJson) {
  let pageToken='';
  const messages=[];
  const seen=new Set();
  do {
    const query=new URLSearchParams({labelIds:'INBOX',maxResults:'50',q:'newer_than:2d'});
    if(pageToken) query.set('pageToken',pageToken);
    const page=await get(`/messages?${query}`,accessToken);
    messages.push(...(page.messages || []));
    pageToken=page.nextPageToken || '';
    if(pageToken && seen.has(pageToken)) throw new Error('Gmail pagination loop; cursor not advanced');
    if(messages.length>500) throw new Error('Gmail baseline exceeds 500 messages; controlled resync required');
    seen.add(pageToken);
  } while(pageToken);
  return [...new Map(messages.map(m=>[m.id,m])).values()];
}

async function gmailBaseline(env, account, accessToken, profile) {
  const listed=await collectGmailBaseline(accessToken);
  let inserted=0;
  // Bound concurrent API requests and D1 batches. Commit cursor only after all pages.
  for(let i=0;i<listed.length;i+=10) {
    const metadata=await Promise.all(listed.slice(i,i+10).map(item=>fetchGmailMetadata(item.id,accessToken)));
    inserted+=await recordGmailMessages(env,account.email,metadata,'baseline');
  }
  await env.DB.prepare(`UPDATE cloud_accounts SET history_cursor=?1,last_sync_at=?2,last_success_at=?2,last_error=NULL
    WHERE provider='google' AND email=?3`).bind(profile.historyId, new Date().toISOString(), account.email).run();
  return { mode: "baseline", observed: inserted, cursor: profile.historyId };
}

async function gmailIncremental(env, account, accessToken) {
  let pageToken = "";
  let latestHistoryId = account.history_cursor;
  const ids = new Set();
  do {
    const query = new URLSearchParams({
      startHistoryId: account.history_cursor,
      historyTypes: "messageAdded",
      labelId: "INBOX",
      maxResults: "100",
    });
    if (pageToken) query.set("pageToken", pageToken);
    const history = await gmailJson(`/history?${query}`, accessToken);
    for (const item of history.history || []) {
      for (const added of item.messagesAdded || []) {
        if ((added.message?.labelIds || []).includes("INBOX") && added.message?.id) ids.add(added.message.id);
      }
    }
    latestHistoryId = history.historyId || latestHistoryId;
    pageToken = history.nextPageToken || "";
    if (ids.size > 200) throw new Error("More than 200 new inbox messages require a controlled resync");
  } while (pageToken);

  const metadata = await Promise.all([...ids].map((id) => fetchGmailMetadata(id, accessToken)));
  const inserted = await recordGmailMessages(env, account.email, metadata, "incremental");
  const now = new Date().toISOString();
  await env.DB.prepare(`UPDATE cloud_accounts SET history_cursor=?1,last_sync_at=?2,last_success_at=?2,last_error=NULL
    WHERE provider='google' AND email=?3`).bind(latestHistoryId, now, account.email).run();
  return { mode: "incremental", observed: inserted, cursor: latestHistoryId };
}

export async function syncGoogleAccount(env, account) {
  const now = new Date().toISOString();
  await env.DB.prepare("UPDATE cloud_accounts SET last_sync_at=?1 WHERE provider='google' AND email=?2")
    .bind(now, account.email).run();
  try {
    const tokens = await refreshGoogleAccessToken(account, env);
    const profile = await gmailJson("/profile", tokens.access_token);
    if (!account.history_cursor) return gmailBaseline(env, account, tokens.access_token, profile);
    try {
      return await gmailIncremental(env, account, tokens.access_token);
    } catch (error) {
      if (error?.status === 404) return gmailBaseline(env, { ...account, history_cursor: null }, tokens.access_token, profile);
      throw error;
    }
  } catch (error) {
    await env.DB.prepare(`UPDATE cloud_accounts SET last_error=?1,last_sync_at=?2
      WHERE provider='google' AND email=?3`).bind(String(error?.message || error).slice(0, 1500), now, account.email).run();
    throw error;
  }
}

export async function refreshMicrosoftAccessToken(account, env) {
  const refreshToken = await decryptSecret(account.refresh_token_enc, env);
  const tokens = await microsoftTokenRequest({
    client_id: env.MICROSOFT_CLIENT_ID,
    client_secret: env.MICROSOFT_CLIENT_SECRET,
    refresh_token: refreshToken,
    grant_type: "refresh_token",
    scope: MICROSOFT_SCOPE,
  }, env);
  if (tokens.refresh_token) {
    const encrypted = await encryptSecret(tokens.refresh_token, env);
    await env.DB.prepare(`UPDATE cloud_accounts SET refresh_token_enc=?1
      WHERE provider='microsoft' AND email=?2`).bind(encrypted, account.email).run();
    account.refresh_token_enc = encrypted;
  }
  return tokens;
}

async function recordMicrosoftMessages(env, email, messages, source) {
  if (!messages.length) return 0;
  const now = new Date().toISOString();
  const statements = messages.map((message) => env.DB.prepare(`INSERT OR IGNORE INTO cloud_mail_observations
    (provider,account_email,external_message_id,external_thread_id,subject,sender,received_at,snippet,first_observed_at,source)
    VALUES('microsoft',?1,?2,?3,?4,?5,?6,?7,?8,?9)`)
    .bind(
      email,
      String(message.id || ""),
      message.conversationId || null,
      String(message.subject || "").slice(0, 500),
      String(message.from?.emailAddress?.address || message.from?.emailAddress?.name || "").slice(0, 500),
      message.receivedDateTime || null,
      String(message.bodyPreview || "").slice(0, 1000),
      now,
      source,
    ));
  const results = await env.DB.batch(statements);
  return results.reduce((total, result) => total + Number(result.meta?.changes || 0), 0);
}

export async function syncMicrosoftAccount(env, account) {
  const now = new Date().toISOString();
  await env.DB.prepare("UPDATE cloud_accounts SET last_sync_at=?1 WHERE provider='microsoft' AND email=?2")
    .bind(now, account.email).run();
  try {
    const tokens = await refreshMicrosoftAccessToken(account, env);
    let delta;
    try {
      delta = await collectMicrosoftDelta(tokens.access_token, account.history_cursor);
    } catch (error) {
      if (error?.status !== 410 || !isMicrosoftDeltaCursor(account.history_cursor)) throw error;
      delta = await collectMicrosoftDelta(tokens.access_token, null);
    }
    const source = isMicrosoftDeltaCursor(account.history_cursor) ? "delta" : "delta-baseline";
    const inserted = await recordMicrosoftMessages(
      env, account.email, delta.messages, source,
    );
    await env.DB.prepare(`UPDATE cloud_accounts SET history_cursor=?1,last_sync_at=?2,last_success_at=?2,last_error=NULL
      WHERE provider='microsoft' AND email=?3`).bind(delta.deltaLink, now, account.email).run();
    const junk=await env.DB.prepare('SELECT enabled,cutover FROM cloud_junk_control WHERE id=1').first();
    if(junk?.enabled && account.shadow_mode===0){
      await env.DB.prepare("INSERT OR IGNORE INTO cloud_folder_cursors(email,folder) VALUES(?1,'junkemail')").bind(account.email).run();
      const state=await env.DB.prepare("SELECT * FROM cloud_folder_cursors WHERE email=?1 AND folder='junkemail'").bind(account.email).first();
      try{
        let change;
        try{change=await collectMicrosoftDelta(tokens.access_token,state.cursor,undefined,new Date(),'junkemail',junk.cutover);}
        catch(e){if(e?.status!==410)throw e;change=await collectMicrosoftDelta(tokens.access_token,null,undefined,new Date(),'junkemail',junk.cutover);}
        // Old items moved into junk must not generate a historical notification storm.
        await recordMicrosoftMessages(env,account.email,change.messages.filter(m=>Date.parse(m.receivedDateTime)>=Date.parse(junk.cutover)),'junk-delta');
        await env.DB.prepare("UPDATE cloud_folder_cursors SET cursor=?1,last_success_at=?2,last_error=NULL WHERE email=?3 AND folder='junkemail'").bind(change.deltaLink,now,account.email).run();
      }catch(e){
        await env.DB.prepare("UPDATE cloud_folder_cursors SET last_error='junk_sync_failed' WHERE email=?1 AND folder='junkemail'").bind(account.email).run();
        throw Error('junk_sync_failed');
      }
    }
    return { mode: source, observed: inserted, pages: delta.pages, cursor_updated: true };
  } catch (error) {
    await env.DB.prepare(`UPDATE cloud_accounts SET last_error=?1,last_sync_at=?2
      WHERE provider='microsoft' AND email=?3`).bind(String(error?.message || error).slice(0, 1500), now, account.email).run();
    throw error;
  }
}

export async function syncAllCloudMail(env) {
  await ensureCloudMailSchema(env);
  const accounts = await env.DB.prepare(`SELECT provider,email,refresh_token_enc,history_cursor,shadow_mode
    FROM cloud_accounts WHERE status='active' ORDER BY id`).all();
  const results = [];
  for (const account of accounts.results || []) {
    try {
      if (account.provider === "google") {
        results.push({ provider: account.provider, email: account.email, ok: true, ...(await syncGoogleAccount(env, account)) });
      } else if (account.provider === "microsoft") {
        results.push({ provider: account.provider, email: account.email, ok: true, ...(await syncMicrosoftAccount(env, account)) });
      }
    } catch (error) {
      results.push({ provider: account.provider, email: account.email, ok: false, error: String(error?.message || error) });
    }
  }
  return results;
}

export async function cloudAccountStatus(env) {
  await ensureCloudMailSchema(env);
  const accounts = await env.DB.prepare(`SELECT provider,email,status,shadow_mode,connected_at,last_sync_at,last_success_at,last_error,
      CASE WHEN history_cursor IS NULL THEN 0 ELSE 1 END AS has_history_cursor
    FROM cloud_accounts ORDER BY id`).all();
  const observations = await env.DB.prepare(`SELECT provider,account_email,COUNT(*) AS observed,MAX(first_observed_at) AS latest_observation
    FROM cloud_mail_observations GROUP BY provider,account_email`).all();
  return json({ accounts: accounts.results || [], observations: observations.results || [] });
}

export function cloudJson(data, status = 200) {
  return json(data, status);
}

// Read-only provider access for migration validation and, later, cloud processing.
// Never accepts a caller-supplied URL, refresh token or arbitrary account.
export async function fetchCloudMessage(env, observation) {
  const account=await env.DB.prepare("SELECT * FROM cloud_accounts WHERE provider=?1 AND email=?2 AND status='active'")
    .bind(observation.provider,observation.account_email).first();
  if(!account) throw new Error('Cloud account is not active');
  if(account.provider==='google') {
    const tokens=await refreshGoogleAccessToken(account,env);
    return gmailJson(`/messages/${encodeURIComponent(observation.external_message_id)}?format=full`,tokens.access_token);
  }
  if(account.provider==='microsoft') {
    const tokens=await refreshMicrosoftAccessToken(account,env);
    const select='id,internetMessageId,subject,from,toRecipients,receivedDateTime,body,webLink,hasAttachments';
    return graphJson(`/me/messages/${encodeURIComponent(observation.external_message_id)}?$select=${select}`,tokens.access_token);
  }
  throw new Error('Unsupported cloud provider');
}
