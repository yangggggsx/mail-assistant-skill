// Never steal an existing Mac task. No automatic lease expiry:
// an interrupted device might already have created the reminder.
import {reminderDraft} from './reminder-draft.js';
import {iphoneTodoPage} from './iphone-todo-page.js';
const json=(v,status=200)=>Response.json(v,{status,headers:{'cache-control':'no-store','referrer-policy':'no-referrer'}});
async function signature(env,token,expires){
  if(!env.API_TOKEN)throw new Error('Signing key unavailable');
  const key=await crypto.subtle.importKey('raw',new TextEncoder().encode(env.API_TOKEN),{name:'HMAC',hash:'SHA-256'},false,['sign']);
  const bytes=await crypto.subtle.sign('HMAC',key,new TextEncoder().encode(`iphone-todo:${token}:${expires}`));
  return Array.from(new Uint8Array(bytes),b=>b.toString(16).padStart(2,'0')).join('');
}
export async function iphoneTodoLaunch(env,origin,token,direct=false){
  if(direct){
    const claimUrl=`${origin}/f/${token}/iphone-todo/direct-claim?proof=${await signature(env,token,'direct-v1')}`;
    return 'shortcuts://run-shortcut?name='+encodeURIComponent('邮件助手-加入待办')+'&input=text&text='+encodeURIComponent(claimUrl);
  }
  const expires=String(Math.floor(Date.now()/1000)+1800);
  const claimUrl=`${origin}/f/${token}/iphone-todo/claim?expires=${expires}&proof=${await signature(env,token,expires)}`;
  return 'shortcuts://run-shortcut?name='+encodeURIComponent('邮件助手-加入待办')+'&input=text&text='+encodeURIComponent(claimUrl);
}
export function reminderPayload(mail,key,origin,token,format=1){
  let c={};try{c=JSON.parse(mail.classification_json||'{}');}catch{}
  if(!c||typeof c!=='object'||Array.isArray(c))c={};
  const draft=reminderDraft(mail,c),marker=`MailAssistant:${key}`;
  const original=`${origin}/f/${token}/original`;
  // v1 is safe for the already installed shortcut (Notes-based deduplication).
  // v2 requires URL-based lookup and writing the URL field before activation.
  return {title:draft.title,list:'邮件待办',marker,format,
    notes:format===2?draft.notes:`${draft.notes}\n\n原邮件：${original}\n${marker}`,
    url:`${original}#${marker}`,draft_source:draft.source};
}
export async function handleIphoneTodo(request,env,url){
  const m=url.pathname.match(/^\/f\/([A-Za-z0-9_-]{32})\/iphone-todo(?:\/(claim|receipt|direct-claim|status))?$/);
  if(!m)return null;
  const [,token,action]=m;
  const link=await env.DB.prepare('SELECT message_key,expires_at FROM feedback_links WHERE token=?1').bind(token).first();
  if(!link||link.expires_at<new Date().toISOString())return json({error:'链接无效或已过期'},410);
  if(action==='status'){
    if(request.method!=='GET')return json({error:'method'},405);
    const task=await env.DB.prepare("SELECT status FROM mail_tools WHERE message_key=?1 AND kind='todo'").bind(link.message_key).first();
    return json({status:task?.status||'not_started'});
  }
  if(!action){
    if(request.method!=='GET')return json({error:'method'},405);
    const launch=await iphoneTodoLaunch(env,url.origin,token);
    const task=await env.DB.prepare("SELECT status FROM mail_tools WHERE message_key=?1 AND kind='todo'").bind(link.message_key).first();
    return iphoneTodoPage(launch,task);
  }
  if(request.method!=='POST')return json({error:'method'},405);
  const expiry=url.searchParams.get('expires')||'',proof=url.searchParams.get('proof')||'',now=Math.floor(Date.now()/1000);
  const valid=action==='direct-claim'
    ? proof===await signature(env,token,'direct-v1')
    : /^\d{10}$/.test(expiry)&&Number(expiry)>=now&&Number(expiry)<=now+1800&&proof===await signature(env,token,expiry);
  if(!valid)return json({error:'任务凭证无效或已过期，请重新打开入口'},403);
  if(action==='claim'||action==='direct-claim'){
    let body;
    try { const text=await request.text();body=text?JSON.parse(text):{}; } catch { return json({error:'json'},400); }
    if(!body||typeof body!=='object'||Array.isArray(body)||![undefined,1,2].includes(body.format))return json({error:'format'},400);
    const format=body.format===2?2:1;
    const mail=await env.DB.prepare('SELECT * FROM cloud_messages WHERE message_key=?1').bind(link.message_key).first();
    if(!mail)return json({error:'该历史邮件没有云端记录，请使用原入口'},409);
    const claim=crypto.randomUUID();
    const inserted=await env.DB.prepare("INSERT OR IGNORE INTO mail_tools(message_key,kind,token,status,result,requested_at) VALUES(?1,'todo',?2,'iphone_claimed',?3,?4)")
      .bind(link.message_key,token,claim,new Date().toISOString()).run();
    if(!inserted.meta?.changes)return json({error:'已存在待办任务；可能已创建、由 Mac 处理或等待核对。请勿重复创建。'},409);
    const receipt=new URL(`/f/${token}/iphone-todo/receipt`,url.origin);
    const receiptExpiry=String(now+1800);
    receipt.searchParams.set('expires',receiptExpiry);
    receipt.searchParams.set('proof',await signature(env,token,receiptExpiry));
    return json({...reminderPayload(mail,link.message_key,url.origin,token,format),claim,receipt_url:receipt.href});
  }
  let b;try{b=await request.json();}catch{return json({error:'json'},400);}
  const task=await env.DB.prepare("SELECT status,result FROM mail_tools WHERE message_key=?1 AND kind='todo'").bind(link.message_key).first();
  if(!task||!['iphone_claimed','completed'].includes(task.status)||task.result!==b.claim||b.status!=='completed')return json({error:'无效回执'},409);
  await env.DB.prepare("UPDATE mail_tools SET status='completed',completed_at=?1 WHERE message_key=?2 AND kind='todo' AND status='iphone_claimed' AND result=?3")
    .bind(new Date().toISOString(),link.message_key,b.claim).run();
  // The shortcut receives the acknowledgement; no duplicate success push.
  return json({ok:true});
}
