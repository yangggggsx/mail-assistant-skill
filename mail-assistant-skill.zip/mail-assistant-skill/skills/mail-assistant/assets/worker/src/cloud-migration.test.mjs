import test from 'node:test';
import assert from 'node:assert/strict';
import {readableHtml,gmailReadableBody,boundedBody,safeOriginalUrl,messageKeyCandidates} from './cloud-content.js';
import {collectGmailBaseline} from './cloud-mail.js';
import {redactCloudInput,validateSchema,handleCloudMigration} from './cloud-migration.js';
const encoded=s=>Buffer.from(s).toString('base64url');

test('rich mail retains paragraphs, table contents and link destinations without scripts',()=>{
  const text=readableHtml('<style>bad-css</style><script>steal()</script><p>Your bill &amp; plan</p><table><tr><td>Due</td><td>Oct 30</td></tr></table><a href="https://example.com/bill">View bill</a><img src="https://example.com/track">');
  assert.match(text,/bill & plan/);assert.match(text,/Due/);assert.match(text,/Oct 30/);assert.match(text,/https:\/\/example.com\/bill/);
  assert.doesNotMatch(text,/steal|bad-css|track/);
});
test('Gmail alternatives prefer rich content and exclude attached text',()=>{
  const body=gmailReadableBody({mimeType:'multipart/mixed',parts:[
    {mimeType:'multipart/alternative',parts:[{mimeType:'text/plain',body:{data:encoded('View HTML')}},{mimeType:'text/html',body:{data:encoded('<p>实际账单内容</p>')}}]},
    {mimeType:'text/plain',filename:'secret.txt',body:{data:encoded('attachment secret')}}]});
  assert.equal(body,'实际账单内容');
});
test('empty content fails and truncation is explicit',()=>{
  assert.throws(()=>boundedBody('  '));assert.equal(boundedBody('a'.repeat(13000)).truncated,true);
  assert.equal(boundedBody('a'.repeat(13000)).body.length,12000);
});
test('provider links reject lookalike domains, credentials and unexpected ports',()=>{
  assert.equal(safeOriginalUrl('https://outlook.live.com/mail/0/id/a'),'https://outlook.live.com/mail/0/id/a');
  for(const v of ['javascript:alert(1)','https://outlook.live.com.evil.test/a','https://user@outlook.live.com/a','https://outlook.live.com:123/a']) assert.equal(safeOriginalUrl(v),'');
});
test('message-id matching covers Apple Mail brackets for migration dedupe',async()=>{
  const a=await messageKeyCandidates('<mail@host>','unused');const b=await messageKeyCandidates('mail@host','unused');
  assert.equal(a.length,2);assert.deepEqual(new Set(a),new Set(b));
});
test('Gmail baseline follows all pages and rejects repeating cursors',async()=>{
  let calls=0;
  const rows=await collectGmailBaseline('token',async()=>++calls===1?{messages:[{id:'a'}],nextPageToken:'next'}:{messages:[{id:'b'}]});
  assert.deepEqual(rows.map(x=>x.id),['a','b']);
  await assert.rejects(collectGmailBaseline('token',async()=>({messages:[],nextPageToken:'loop'})),/loop/);
});
test('schema validator rejects malformed enum, required properties and extra fields',()=>{
  const s={type:'object',required:['category'],properties:{category:{type:'string',enum:['normal']}}};
  assert.deepEqual(validateSchema({category:'normal'},s),{category:'normal'});
  for(const v of [{},{category:'urgent'},{category:'normal',execute:'delete'}]) assert.throws(()=>validateSchema(v,s));
});
test('migration endpoints require authentication before touching data',async()=>{
  const request=new Request('https://local/api/cloud/migration/probe',{method:'POST'});
  const response=await handleCloudMigration(request,{},new URL(request.url),false);
  assert.equal(response.status,401);
});
test('redaction removes mailbox local parts and URL secrets',()=>{
  const text=redactCloudInput('a@example.com https://example.com/?token=secret&x=1 verification code: 123456');
  assert.doesNotMatch(text,/a@example|token=secret|123456/);
});
