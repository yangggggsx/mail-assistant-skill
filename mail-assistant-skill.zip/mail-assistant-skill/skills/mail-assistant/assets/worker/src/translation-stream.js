// Parse SSE across arbitrary UTF-8/network boundaries. Only explicit completion
// is authoritative; a disconnected stream must never become a cached success.
export async function readTranslationStream(response,onPartial=async()=>{}) {
 const reader=response.body.getReader(),decoder=new TextDecoder();
 let buffer='',data=[],text='',result=null,lastWrite=0;
 async function event(){
  if(!data.length)return;
  const raw=data.join('\n');data=[];
  if(raw==='[DONE]')return;
  const e=JSON.parse(raw);
  if(e.type==='response.output_text.delta'){
   text+=e.delta||'';
   if(text.length>60000)throw Error('translation too large');
   if(Date.now()-lastWrite>=1000){await onPartial(text);lastWrite=Date.now();}
  }
  if(['response.completed','response.incomplete','response.failed'].includes(e.type))result=e.response;
  if(e.type==='error')throw Error('translation stream error');
 }
 try {
  while(true){
   const {value,done}=await reader.read();buffer+=decoder.decode(value,{stream:!done});
   let end;
   while((end=buffer.indexOf('\n'))>=0){
    const line=buffer.slice(0,end).replace(/\r$/,'');buffer=buffer.slice(end+1);
    if(!line)await event();else if(line.startsWith('data:'))data.push(line.slice(5).replace(/^ /,''));
   }
   if(done)break;
  }
  if(buffer.startsWith('data:'))data.push(buffer.slice(5).trimStart());
  await event();
  if(!result)throw Error('翻译未完整生成，请重试；未将不完整结果标记为成功');
  return result;
 }finally{await reader.cancel().catch(()=>{});reader.releaseLock();}
}
