import { convert } from 'html-to-text';

export const MAX_BODY_CHARS = 12000;

export function readableHtml(html) {
  if (String(html).length > 2000000) throw new Error('邮件 HTML 超过安全解析上限');
  return convert(String(html || ''), {
    wordwrap: false,
    selectors: [
      {selector:'img', format:'skip'},
      {selector:'script', format:'skip'},
      {selector:'style', format:'skip'},
      {selector:'a', options:{hideLinkHrefIfSameAsText:true}},
      {selector:'table', options:{uppercaseHeaderCells:false}},
    ],
  }).trim();
}

export function decodeGmailPart(data, charset='utf-8') {
  const bytes = Uint8Array.from(atob(String(data || '').replace(/-/g,'+').replace(/_/g,'/')), c=>c.charCodeAt(0));
  try { return new TextDecoder(charset).decode(bytes); }
  catch { return new TextDecoder().decode(bytes); }
}

export function gmailReadableBody(payload) {
  const visit = part => {
    if (!part || part.filename) return '';
    const headers = part.headers || [];
    if (headers.some(h=>h.name.toLowerCase()==='content-disposition' && /^attachment/i.test(h.value))) return '';
    const type = String(part.mimeType || '').toLowerCase();
    const charset = headers.find(h=>h.name.toLowerCase()==='content-type')?.value?.match(/charset=["']?([^;\s"']+)/i)?.[1] || 'utf-8';
    if (type==='text/plain' && part.body?.data) return decodeGmailPart(part.body.data,charset).trim();
    if (type==='text/html' && part.body?.data) return readableHtml(decodeGmailPart(part.body.data,charset));
    const parts = part.parts || [];
    if (type==='multipart/alternative') {
      // Prefer the rich representation: some vendors send an empty/useless plain part.
      const ranked = [...parts].sort((a,b)=>Number(b.mimeType==='text/html')-Number(a.mimeType==='text/html'));
      for (const child of ranked) { const text=visit(child); if(text) return text; }
      return '';
    }
    return parts.map(visit).filter(Boolean).join('\n\n');
  };
  return visit(payload);
}

export function boundedBody(value) {
  const text=String(value || '').trim();
  if (!text) throw new Error('未获得可读正文；不会把空正文当作完整邮件');
  return {body:text.slice(0,MAX_BODY_CHARS),truncated:text.length>MAX_BODY_CHARS,original_chars:text.length};
}

export function safeOriginalUrl(value) {
  try {
    const u=new URL(value);
    if(u.protocol!=='https:' || u.username || u.password || u.port) return '';
    if(!['mail.google.com','outlook.live.com','outlook.office.com','outlook.office365.com'].includes(u.hostname)) return '';
    return u.href;
  } catch { return ''; }
}

export async function messageKeyCandidates(messageId, fallback) {
  const raw=String(messageId || '').trim();
  const bare=raw.replace(/^</,'').replace(/>$/,'');
  const inputs=raw ? [...new Set([raw,bare,`<${bare}>`])] : [fallback];
  return Promise.all(inputs.map(async value=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(value))),b=>b.toString(16).padStart(2,'0')).join('')));
}
