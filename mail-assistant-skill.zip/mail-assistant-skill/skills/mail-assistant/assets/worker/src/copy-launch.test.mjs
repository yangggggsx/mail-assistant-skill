import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {aiLaunchers,copyLaunchScript} from './copy-launch.js';
import {toolPage} from './mail-tools.js';
function setup(write,launch=()=>{}){
 const calls=[],nodes={payload:{value:'edited email',focus(){},select(){}},status:{},'launch-fallback':{},copy:{}};
 const buttons=aiLaunchers.map(a=>({dataset:{aiUrl:a.url,aiLabel:a.label}}));
 vm.runInNewContext(copyLaunchScript,{document:{getElementById:id=>nodes[id],querySelectorAll:()=>buttons},navigator:{clipboard:{writeText:async s=>{calls.push(['copy',s]);await write?.();}}},window:{location:{assign:url=>{calls.push(['launch',url]);launch();}}}});
 return {nodes,buttons,calls};
}
test('both launch buttons copy edited text before invoking fixed shortcut URL',async()=>{
 for(let i=0;i<2;i++){
  const x=setup();await x.buttons[i].onclick();
  assert.deepEqual(x.calls,[['copy','edited email'],['launch',aiLaunchers[i].url]]);
  assert.equal(x.nodes['launch-fallback'].hidden,false);
  const u=new URL(x.calls[1][1]);assert.equal(u.searchParams.get('name'),aiLaunchers[i].shortcut);assert.equal(u.searchParams.has('text'),false);
 }
});
test('failed clipboard never launches; fallback does not expose stale link',async()=>{
 const x=setup(()=>{throw Error('denied')});await x.buttons[0].onclick();
 assert.equal(x.calls.length,1);assert.equal(x.nodes['launch-fallback'].hidden,true);assert.match(x.nodes.status.textContent,/未跳转/);
});
test('blocked launch leaves manual fallback; copy-only does not navigate',async()=>{
 const x=setup(undefined,()=>{throw Error('blocked')});await x.buttons[0].onclick();assert.equal(x.nodes['launch-fallback'].hidden,false);
 const y=setup();await y.nodes.copy.onclick();assert.equal(y.calls.length,1);
});
test('completed copy page offers installation guidance, todo page has no launch buttons',async()=>{
 const copy=await toolPage('a'.repeat(32),'copy',{status:'completed',result:'hello'}).text();
 for(const a of aiLaunchers){assert.ok(copy.includes('复制并打开 '+a.label));assert.ok(copy.includes(a.shortcut));}
 const todo=await toolPage('a'.repeat(32),'todo',{status:'completed'}).text();assert.ok(!todo.includes('data-ai-url="'));
});
