import {encryptSecret,decryptSecret,ensureCloudMailSchema} from './cloud-mail.js';
import {CALENDAR_ACCOUNT} from './deployment-config.js';
export {CALENDAR_ACCOUNT};
export const CALENDAR_NAME='邮件助手';
const SCOPE='openid profile email offline_access User.Read Calendars.ReadWrite';
const json=(v,status=200)=>Response.json(v,{status,headers:{'cache-control':'no-store'}});
const page=(message,status=200)=>new Response(`<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>日历授权</title><body style="font-family:system-ui;max-width:520px;margin:80px auto;padding:24px"><h1>邮件助手 · Outlook 日历</h1><p>${message}</p></body></html>`,{status,headers:{'content-type':'text/html; charset=utf-8','cache-control':'no-store','content-security-policy':"default-src 'none'; style-src 'unsafe-inline'; frame-ancestors 'none'",'referrer-policy':'no-referrer'}});
export async function ensureCalendar(env){
 await env.DB.prepare(`CREATE TABLE IF NOT EXISTS outlook_calendar_connection(id INTEGER PRIMARY KEY CHECK(id=1),email TEXT NOT NULL,refresh_token_enc TEXT NOT NULL,calendar_id TEXT,status TEXT NOT NULL,connected_at TEXT NOT NULL,last_error TEXT)`).run();
 await env.DB.prepare(`CREATE TABLE IF NOT EXISTS outlook_calendar_events(message_key TEXT NOT NULL,item_index INTEGER NOT NULL,transaction_id TEXT NOT NULL UNIQUE,status TEXT NOT NULL,payload_json TEXT NOT NULL,event_id TEXT,created_at TEXT NOT NULL,completed_at TEXT,error TEXT,PRIMARY KEY(message_key,item_index))`).run();
}
async function tokenRequest(env,parameters){
 const r=await fetch('https://login.microsoftonline.com/common/oauth2/v2.0/token',{method:'POST',signal:AbortSignal.timeout(20000),headers:{'content-type':'application/x-www-form-urlencoded'},body:new URLSearchParams({client_id:env.MICROSOFT_CLIENT_ID,client_secret:env.MICROSOFT_CLIENT_SECRET,scope:SCOPE,...parameters})});
 const data=await r.json();if(!r.ok||!data.access_token)throw Error('calendar_authorization_required');
 if(!String(data.scope||'').toLowerCase().split(' ').includes('calendars.readwrite'))throw Error('calendar_permission_missing');
 return data;
}
export async function calendarAccess(env){
 const row=await env.DB.prepare('SELECT * FROM outlook_calendar_connection WHERE id=1').first();
 if(!row||row.email!==CALENDAR_ACCOUNT)throw Error('calendar_not_connected');
 const tokens=await tokenRequest(env,{grant_type:'refresh_token',refresh_token:await decryptSecret(row.refresh_token_enc,env)});
 if(tokens.refresh_token)await env.DB.prepare('UPDATE outlook_calendar_connection SET refresh_token_enc=?1 WHERE id=1').bind(await encryptSecret(tokens.refresh_token,env)).run();
 return {access:tokens.access_token,connection:row};
}
export async function calendarGraph(access,path,{method='GET',body,responseTimezone,ifMatch}={}){
 if((!path.startsWith('/me/')&&!path.startsWith('/me?'))||path.includes('://'))throw Error('invalid_graph_path');
 if(responseTimezone&&!['UTC','Central Standard Time'].includes(responseTimezone))throw Error('invalid_response_timezone');
 const prefer='IdType="ImmutableId"'+(responseTimezone?`, outlook.timezone="${responseTimezone}", outlook.body-content-type="text"`:'');
 const response=await fetch('https://graph.microsoft.com/v1.0'+path,{method,signal:AbortSignal.timeout(20000),headers:{authorization:'Bearer '+access,'content-type':'application/json',Prefer:prefer,...(ifMatch?{'If-Match':ifMatch}:{})},...(body?{body:JSON.stringify(body)}:{})});
 const data=await response.json().catch(()=>({}));
 if(!response.ok){const error=Error('graph_'+response.status);error.httpStatus=response.status;throw error;}
 return data;
}
export async function handleCalendarAuth(request,env,url,authorized){
 const callback=url.pathname==='/oauth/microsoft/callback'&&request.method==='GET';
 if(!callback&&!url.pathname.startsWith('/api/calendar/'))return null;
 if(!callback&&!authorized)return json({error:'unauthorized'},401);
 await ensureCloudMailSchema(env);await ensureCalendar(env);
 if(callback){
  const state=url.searchParams.get('state')||'';
  const saved=await env.DB.prepare("SELECT state,expires_at,consumed_at FROM oauth_states WHERE state=?1 AND provider='microsoft-calendar'").bind(state).first();
  if(!saved)return null; // Mail callback remains entirely unchanged.
  const now=new Date().toISOString();
  if(saved.consumed_at||saved.expires_at<=now)return page('授权链接已使用或过期，请重新发起日历授权。',400);
  const claim=await env.DB.prepare('UPDATE oauth_states SET consumed_at=?1 WHERE state=?2 AND consumed_at IS NULL').bind(now,state).run();
  if(!claim.meta?.changes)return page('授权链接已使用。',400);
  if(url.searchParams.has('error')||!url.searchParams.get('code'))return page('授权未完成，现有邮件推送不受影响。',400);
  try{
   const tokens=await tokenRequest(env,{grant_type:'authorization_code',code:url.searchParams.get('code'),redirect_uri:url.origin+'/oauth/microsoft/callback'});
   const me=await calendarGraph(tokens.access_token,'/me?$select=mail,userPrincipalName');
   const email=String(me.mail||me.userPrincipalName||'').trim().toLowerCase();
   if(email!==CALENDAR_ACCOUNT)return page('账号不匹配。请使用指定的私人 Outlook 账号重新授权；未保存本次凭据。',400);
   if(!tokens.refresh_token)throw Error('no_refresh');
   await env.DB.prepare(`INSERT INTO outlook_calendar_connection(id,email,refresh_token_enc,status,connected_at) VALUES(1,?1,?2,'authorized',?3)
    ON CONFLICT(id) DO UPDATE SET refresh_token_enc=excluded.refresh_token_enc,connected_at=excluded.connected_at,last_error=NULL`).bind(email,await encryptSecret(tokens.refresh_token,env),now).run();
   return page('日历授权已完成 ✓。现有邮件推送未改动。请回到对话，我会继续绑定专用「邮件助手」日历并完成上线验证。');
  }catch{return page('日历授权未完成，请重新发起。现有邮件推送不受影响。',502);}
 }
 if(url.pathname==='/api/calendar/connect'&&request.method==='POST'){
  if(!env.MICROSOFT_CLIENT_ID||!env.MICROSOFT_CLIENT_SECRET)return json({error:'oauth_not_configured'},503);
  const state=crypto.randomUUID().replaceAll('-','')+crypto.randomUUID().replaceAll('-',''),now=new Date(),expires=new Date(now.getTime()+600000).toISOString();
  await env.DB.prepare("INSERT INTO oauth_states(state,provider,created_at,expires_at) VALUES(?1,'microsoft-calendar',?2,?3)").bind(state,now.toISOString(),expires).run();
  const target=new URL('https://login.microsoftonline.com/common/oauth2/v2.0/authorize');
  for(const [k,v] of Object.entries({client_id:env.MICROSOFT_CLIENT_ID,redirect_uri:url.origin+'/oauth/microsoft/callback',response_type:'code',response_mode:'query',scope:SCOPE,prompt:'consent',login_hint:CALENDAR_ACCOUNT,state}))target.searchParams.set(k,v);
  return json({authorization_url:target.toString(),expires_at:expires});
 }
 if(url.pathname==='/api/calendar/status'&&request.method==='GET')return json({connection:await env.DB.prepare('SELECT email,calendar_id,status,connected_at,last_error FROM outlook_calendar_connection WHERE id=1').first()});
 return null;
}
