# Mail Assistant Skill

把云端邮件助手打包为可安装的 Codex skill，包含完整 Worker 源码、自动测试、配置生成器和部署/维护指南。

**公开预览版；供个人独立部署，尚未完成独立新账户端到端验收。** 个人自用和修改免费，包括处理自己的工作邮件；售卖、收费代部署或提供付费服务需要作者单独书面商业授权。完整条款见 [LICENSE](LICENSE)。这是源码可见项目，不采用允许自由商用的开源许可证。

**安装 skill 不等于服务已上线。** 使用者需要自己的 Cloudflare、邮箱 OAuth、OpenAI 和 Pushover 配置。本仓库不包含生产密钥、邮箱内容、数据库备份或个人访问链接，也不会自动连接原作者的服务。

## 账号配置、通知渠道与邮箱转发

本项目需要自行部署和配置；安装 Skill 并不代表服务已经开通。使用前需要准备自己的 Cloudflare 账号、OpenAI API 密钥，以及 Gmail／Outlook 授权配置；日程功能还需要授权目标 Outlook 日历。账号注册、邮箱授权和部分验证步骤需要本人手动完成，具体操作见包内部署指南。

当前版本使用 **Pushover** 接收通知，需要配置自己的应用 Token 和用户 Key。通知渠道可以扩展到 **飞书等平台**：邮件分类、摘要和日程提取逻辑可以复用，但需要适配消息发送 API、认证方式、消息格式和操作链接，并调整快捷指令完成后的返回目标。**不是仅替换一个 API 地址就能直接使用。** 目前已实现的是 Pushover，飞书属于可扩展方向。

邮箱支持通过授权直接接入 Gmail／Outlook，**直接接入的邮箱不需要配置自动转发**。对于暂未直接支持的邮箱，可以考虑手动设置自动转发到已接入的邮箱，再由助手统一处理。转发是否可用取决于邮箱服务商及学校／公司的管理政策，可能需要验证收件地址。建议保留原邮件，并避免同一邮箱同时走直接接入和转发两条路线，以免重复处理。转发后的原邮件定位、发件人识别和垃圾邮件覆盖范围需要实际验证。

iPhone 提醒事项功能需要另行安装共享快捷指令，并选择自己的「邮件待办」列表。所有密钥和授权都应使用部署者自己的配置，不要沿用他人的服务地址或凭证。


## 模型选择与自定义计划

邮件助手采用个人独立部署方式，使用者自行配置云资源、邮箱授权和模型服务。当前公开预览版的自动分类、摘要、翻译与日程提取仍固定调用 OpenAI 接口，可配置模型名称，但尚未实现并验收 DeepSeek、Kimi 等供应商的切换，不能直接替换 API 密钥使用。

后续拟支持自定义供应商、API 地址、密钥及按功能选择模型，例如使用一个模型处理邮件分类和翻译，另一个模型处理图片与 PDF。实际可用功能将取决于所选接口和模型的结构化输出、流式响应及文件处理能力；不支持的功能拟明确提示或允许关闭，不会默认把邮件转发给另一家服务商。相关 API 费用由部署者自行承担。这些属于计划能力，完成适配与真实接口验收后才会标为支持。

后台模型配置与“复制到 AI”的 App 入口相互独立：后者由网页复制、快捷指令打开 ChatGPT / Claude，再由用户手动粘贴发送。接入其他后台模型不会自动增加对应 App 入口，也不代表获得其 API 额度或 App 会员。

## 能力

- Gmail / Outlook 增量收件、通知触发与定时补漏。
- 邮件类别 + 重要程度双维度分类，摘要、Pushover 推送和简报。
- 中文翻译保留链接，分类反馈，复制到 AI 的上下文与问题组织；iPhone 上“复制并打开 ChatGPT / Claude”依赖对应快捷指令，随后需手动粘贴并发送。“仅复制全部”不依赖快捷指令。
- 简洁行动待办，通过 iPhone 快捷指令写入 Apple 提醒事项并回传结果。
- 邮件、PDF 和图片提取会议、活动、截止日期等日程；支持 HEIC/HEIF。
- 可编辑预览，确认后由云端写入 Outlook 并核验；课程关联更新能力保留。

### PDF／图片日程预览更新（2026-10-28）

通用文件提取在原文没有结束时间时，可按活动类型给出 AI 预计时长、理由和预计结束时间。篮球与足球可有不同建议，明确可能加时的赛事可建议更长占位；这些是可修改的建议，不是原文事实或实际完赛保证。已有结束时间优先使用原文；缺少开始日期／时间、全天、截止事项或无法合理判断时，不套用预计时长。课程关联模式暂保留原有时间处理。

有具体钟点的通用日程会按上传时选择的时区转换后预览；圣路易斯选择 `America/Chicago`，转换按日期处理夏令时。赛程的 LOCAL 是比赛所在地时间，ET 是东部时间，不能混用；提取提示要求有 ET 列时统一读取 ET，但复杂表格仍可能错读，需要核对原图。全天日期不跨时区平移。

预览新增「全选新增与更新」，仍需点击一次「确认加入 Outlook」。全选不自动选择删除，不跳过日期与时间校验。预计结束时间可以直接编辑，日历备注保留 AI 原建议的说明。旧预览不会自动重新提取；要应用新提取逻辑需重新上传，已写入或写入结果不确定时先核对日历，避免重复。

此更新包含云端工具源码；上传接口和快捷指令协议未变，现有上传快捷指令无需重装。独立部署者需要更新自己的 Worker，下载 ZIP 本身不会升级云端服务。

## 安装

首次使用先读 [配置引导与支持矩阵](skills/mail-assistant/references/getting-started.md)。另见 [数据与权限](skills/mail-assistant/references/privacy.md)、[升级与卸载](skills/mail-assistant/references/lifecycle.md) 和 [公开发布准备清单](RELEASE_READINESS.md)。当前是公开预览，尚未完成独立新账户验收。

当前 GitHub 分发以 ZIP 为主：下载并解压 `mail-assistant-skill.zip` 后进入同名目录。若仓库根目录没有 `skills/`，请先解压，不要直接执行后续路径。也可克隆公开仓库后解压：

维护者进行正常源码导入与生成新发布包时，按 [源码迁移说明](SOURCE_IMPORT.md) 保留远端历史。已经包含 `skills/` 的源码目录可以直接使用，无需再解压旧 ZIP。

```sh
git clone https://github.com/yangggggsx/mail-assistant-skill.git
```

将 `skills/mail-assistant` 整个目录复制到你的 Codex skills 目录（通常为 `~/.codex/skills/mail-assistant`），重新加载技能。不要覆盖已有同名技能而不先检查/备份。

示例调用：

> 使用 $mail-assistant，帮我在自己的 Cloudflare 账号部署邮件助手，先检查配置和费用，再授权连接邮箱。

> 使用 $mail-assistant，检查邮件推送延迟，先读取状态，不重发通知。

> 使用 $mail-assistant，调整日程提取逻辑，保留旧快捷指令兼容并运行测试。

## 结构

```text
skills/mail-assistant/
  SKILL.md
  agents/openai.yaml
  references/                 部署、运行、架构、快捷指令
  scripts/configure.py        在新目录生成部署副本
  scripts/test_configure.py   配置生成器测试
  assets/deployment.example.json
  assets/worker/              完整云端源代码、测试和锁文件
```

[部署指南](skills/mail-assistant/references/deployment.md) · [云端架构](skills/mail-assistant/references/architecture.md) · [快捷指令配置](skills/mail-assistant/references/shortcuts.md)

## 验证

```sh
python3 skills/mail-assistant/scripts/test_configure.py
cd skills/mail-assistant/assets/worker
npm ci
npm test
```

需要 Node.js 24（测试使用 `node:sqlite`）。所有单元测试均使用本地内存数据库或模拟服务；不会发送真实邮件/推送或创建真实日程。新账户仍需完成真实 OAuth、资源开通和端到端验收。

提醒事项快捷指令可通过 [iCloud 共享链接](https://www.icloud.com/shortcuts/7a610bc2e6524944ad34449f66d94e11) 安装。安装后必须在“添加提醒事项”动作中重新选择自己的「邮件待办」列表，详见快捷指令配置文档。PDF/图片上传快捷指令仍需按文档配置。

“复制到 AI”的打开 App 功能也需要 iPhone 快捷指令：分别创建 `邮件助手-ChatGPT` 和 `邮件助手-Claude`，各添加一个“打开 App”动作，选择 ChatGPT 或 Claude，名称必须完全一致。网页负责复制；快捷指令只打开 App，不读取剪贴板、不调用模型、不自动发送，也不在跳转 URL 中传递邮件正文。可只配置自己使用的 App；完整流程与失败处理见[快捷指令配置](skills/mail-assistant/references/shortcuts.md)。

本包不包含旧 Mac 常驻程序、私人历史数据和一次性迁移备份。云端已迁移的能力以源码为准。使用范围以 [LICENSE](LICENSE) 为准。详细验证记录见 [VALIDATION.md](VALIDATION.md)。
