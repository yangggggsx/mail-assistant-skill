import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {appleMessageUrl,originalTargets,originalMailPage,launchScript} from './original-mail.js';
test('Apple links use RFC message id, preserve web fallback and validate legacy ids',async()=>{
  assert.equal(appleMessageUrl('<abc@example.com>'),'message://%3Cabc%40example.com%3E');
  assert.equal(appleMessageUrl('providerInternalId'),'');
  assert.equal(appleMessageUrl('a\nb@example.com'),'');
  assert.equal(originalTargets('', 'message://%3Cabc%40example.com%3E').apple,appleMessageUrl('abc@example.com'));
  assert.equal(originalTargets('', 'message://%zz').apple,'');
  assert.equal(originalMailPage('', 'https://attacker.example'),null);
  const r=originalMailPage('<abc@example.com>','https://outlook.live.com/mail/0/inbox');
  const s=await r.text();assert.ok(s.includes('id="apple"'));assert.ok(s.includes('id="web"'));
  assert.ok(r.headers.get('content-security-policy').includes("script-src 'nonce-"));
  assert.ok(s.includes('noscript'));
});
function browser({apple=true,device=true,hidden=false}={}){
  const events={},timers=[],links={apple:apple?{href:'message://id',addEventListener:(n,f)=>events[n]=f}:null,web:{href:'https://outlook.live.com/mail/'},status:{}};
  const context={navigator:{userAgent:device?'iPhone':'Android',platform:''},document:{hidden,getElementById:id=>links[id],addEventListener:(n,f)=>events[n]=f},window:{addEventListener:(n,f)=>events[n]=f},location:{replace(url){this.replaced=url;}},setTimeout:f=>{timers.push(f);return 1;},clearTimeout:()=>{context.cancelled=true;}};
  vm.runInNewContext(launchScript,context);return {context,events,timers};
}
test('Apple launch then timed web fallback only if page stays active',()=>{
  const a=browser();assert.equal(a.context.location.href,'message://id');a.timers[0]();assert.equal(a.context.location.replaced,'https://outlook.live.com/mail/');
  const b=browser();b.context.document.hidden=true;b.events.visibilitychange();b.timers[0]();assert.equal(b.context.location.replaced,undefined);
  const c=browser();c.events.blur();c.timers[0]();assert.equal(c.context.location.replaced,undefined);
});
test('non Apple or missing message id uses web; background preview does not launch',()=>{
  for(const opts of [{device:false},{apple:false}]){const x=browser(opts);assert.equal(x.context.location.replaced,'https://outlook.live.com/mail/');assert.equal(x.context.location.href,undefined);}
  assert.equal(browser({hidden:true}).context.location.href,undefined);
});
