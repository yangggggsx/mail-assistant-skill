import {ensureCalendar,calendarAccess,calendarGraph,CALENDAR_ACCOUNT,CALENDAR_NAME} from './outlook-calendar-auth.js';
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const json=(v,status=200)=>Response.json(v,{status,headers:{'cache-control':'no-store'}});
export const zones={'America/Chicago':'Central Standard Time','America/New_York':'Eastern Standard Time','America/Los_Angeles':'Pacific Standard Time','America/Denver':'Mountain Standard Time','America/Phoenix':'US Mountain Standard Time','Asia/Shanghai':'China Standard Time','Asia/Tokyo':'Tokyo Standard Time','Europe/London':'GMT Standard Time','Europe/Paris':'Romance Standard Time',UTC:'UTC'};
function page(body,status=200){return new Response(`<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="color-scheme" content="light dark"><title>加入日程</title><style>body{font-family:system-ui;margin:0;background:#f4f5f7;color:#171717}main{max-width:520px;margin:auto;padding:24px 16px}.card{padding:24px;background:white;border-radius:20px;margin-bottom:18px}h1{font-size:25px}h2{font-size:20px}p{line-height:1.6;color:#666;overflow-wrap:anywhere}label{display:block;margin:16px 0 6px}input:not([type=checkbox]),select,textarea{box-sizing:border-box;width:100%;padding:12px;border:1px solid #bbb;border-radius:10px;font:inherit;background:transparent;color:inherit}textarea{min-height:90px}button{width:100%;border:0;border-radius:12px;background:#1877f2;color:white;padding:15px;font:inherit;margin-top:20px}a{color:#1877f2}.warning{padding:12px;background:#fff3d6;border-radius:10px}.small{font-size:13px}@media(prefers-color-scheme:dark){body{background:#111;color:#eee}.card{background:#202124}p{color:#bbb}.warning{background:#403921}}</style><main>${body}</main></html>`,{status,headers:{'content-type':'text/html; charset=utf-8','cache-control':'no-store','referrer-policy':'no-referrer','x-frame-options':'DENY','x-content-type-options':'nosniff','content-security-policy':"default-src 'none'; style-src 'unsafe-inline'; form-action 'self'; base-uri 'none'; frame-ancestors 'none'"}});}
function note(text,status=200){return page(`<section class="card"><h1>加入日程</h1><p>${esc(text)}</p></section>`,status);}
function parseLocal(value){
 if(!/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/.test(value))throw Error('请填写完整的日期和时间。');
 const date=new Date(value+':00Z');if(!Number.isFinite(date.getTime())||date.toISOString().slice(0,16)!==value||Number(value.slice(0,4))<2000)throw Error('日期或时间无效。');
 return date.getTime();
}
// Enumerate possible offsets near the date, then round-trip. Reject DST gaps and
// overlaps rather than silently moving a meeting by an hour.
export function localInstant(value,zone){
 const naive=parseLocal(value);if(!Object.hasOwn(zones,zone))throw Error('请选择支持的时区。');
 const format=new Intl.DateTimeFormat('en-CA',{timeZone:zone,year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',hourCycle:'h23'});
 const wall=t=>{const p=Object.fromEntries(format.formatToParts(new Date(t)).map(x=>[x.type,x.value]));return `${p.year}-${p.month}-${p.day}T${p.hour}:${p.minute}`;};
 const offsets=new Set([-86400000,0,86400000].map(d=>parseLocal(wall(naive+d))-(naive+d)));
 const matches=[...offsets].map(offset=>naive-offset).filter(t=>wall(t)===value);
 if(matches.length!==1)throw Error('该时间处于夏令时跳变或重复时段，请改用 UTC 明确时间后提交。');
 return matches[0];
}
export function validateEvent(form,origin,token){
 const get=k=>String(form.get(k)||'').trim();
 const title=get('title'),start=get('start'),end=get('end'),timezone=get('timezone'),location=get('location'),notes=get('notes'),allDay=form.get('all_day')==='yes',reminder=get('reminder');
 if(!title||title.length>180||location.length>300||notes.length>2000)throw Error('标题必填且不超过 180 字；地点不超过 300 字，备注不超过 2000 字。');
 const a=localInstant(start,timezone),b=localInstant(end,timezone);
 if(b<=a||b-a>366*86400000)throw Error('结束时间必须晚于开始时间，跨度不超过一年。');
 if(allDay&&(!start.endsWith('T00:00')||!end.endsWith('T00:00')))throw Error('全天日程开始和结束都应为 00:00；结束日期为最后一天的次日。');
 if(!['none','0','5','15','30','60','1440'].includes(reminder))throw Error('提醒设置无效。');
 return {subject:title,start:{dateTime:start+':00',timeZone:zones[timezone]},end:{dateTime:end+':00',timeZone:zones[timezone]},isAllDay:allDay,
  location:{displayName:location},body:{contentType:'text',content:[notes,'原邮件：'+origin+'/f/'+token+'/original'].filter(Boolean).join('\n\n')},
  isReminderOn:reminder!=='none',...(reminder!=='none'?{reminderMinutesBeforeStart:Number(reminder)}:{}),showAs:allDay?'free':'busy'};
}
async function proof(env,token,index,expires){
 const key=await crypto.subtle.importKey('raw',new TextEncoder().encode(env.API_TOKEN),{name:'HMAC',hash:'SHA-256'},false,['sign']);
 return [...new Uint8Array(await crypto.subtle.sign('HMAC',key,new TextEncoder().encode(`outlook-calendar-v1:${token}:${index}:${expires}`)))].map(b=>b.toString(16).padStart(2,'0')).join('');
}
async function rowFor(env,token){return env.DB.prepare(`SELECT f.*,m.subject,m.classification_json FROM feedback_links f JOIN cloud_messages m ON m.message_key=f.message_key WHERE f.token=?1`).bind(token).first();}
export function candidates(row){
 let c={};try{c=JSON.parse(row.classification_json||'{}');}catch{}
 const events=Array.isArray(c.calendar?.events)?c.calendar.events:[];
 if(events.some(e=>e.action!=='create'))return {blocked:true,events:[]};
 return {blocked:false,events:events.length?events.slice(0,20):[{title:c.notification?.title||row.subject||'',start:'',end:'',timezone:'America/Chicago',location:''}],summary:c.summary||''};
}
async function legacyOwned(env,row){
 if(row.label==='calendar')return true;
 return Boolean(await env.DB.prepare('SELECT 1 FROM outlook_calendar_legacy WHERE message_key=?1').bind(row.message_key).first());
}
export async function ensureCalendarOwnership(env){await env.DB.prepare('CREATE TABLE IF NOT EXISTS outlook_calendar_legacy(message_key TEXT PRIMARY KEY)').run();}
async function preview(env,url,token,row){
 const connection=await env.DB.prepare('SELECT status,calendar_id FROM outlook_calendar_connection WHERE id=1').first();
 if(connection?.status!=='ready'||!connection.calendar_id)return note('Outlook 日历尚未完成启用。现在不会创建日程，请稍后重新打开。',503);
 if(await legacyOwned(env,row))return note('这封邮件已经交给 Mac 处理日历，或此前已有日历请求。本页不再创建，以免重复。',409);
 const draft=candidates(row);if(draft.blocked)return note('这封邮件包含取消或改期。首版仅支持新增，为避免只新增而遗漏取消，本页不执行。请在原日历中核对处理。',409);
 const saved=(await env.DB.prepare('SELECT item_index,status FROM outlook_calendar_events WHERE message_key=?1').bind(row.message_key).all()).results||[];
 const expires=String(Math.floor(Date.now()/1000)+1800);
 const field=(name,label,value,type='text',max='')=>`<label>${label}<input name="${name}" type="${type}" value="${esc(value)}" ${['title','start','end'].includes(name)?'required':''} ${max?`maxlength="${max}"`:''}></label>`;
 const forms=await Promise.all(draft.events.map(async(event,index)=>{
  const prior=saved.find(x=>x.item_index===index);
  if(prior)return `<section class="card"><h2>${esc(event.title||'日程 '+(index+1))}</h2><p>${prior.status==='completed'?'已加入 Outlook「邮件助手」日历 ✓。后续编辑请在日历 App 中进行。':prior.status==='failed'?'创建未成功。请联系助手核对原因；此入口不会自动重复提交。':'提交结果正在核对。请先检查日历，勿重复创建。'}</p></section>`;
  const local=value=>typeof value==='string'&&/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}(?::00(?:\.000)?)?$/.test(value)?value.slice(0,16):'';
  const tz=Object.hasOwn(zones,event.timezone)?event.timezone:'';
  return `<section class="card"><h2>日程 ${index+1}</h2><form method="post" action="/f/${token}/calendar">
   <input type="hidden" name="index" value="${index}"><input type="hidden" name="expires" value="${expires}"><input type="hidden" name="proof" value="${await proof(env,token,index,expires)}">
   ${field('title','标题',event.title||row.subject,'text',180)}
   ${field('start','开始（所选时区的当地时间）',local(event.start),'datetime-local')}
   ${field('end','结束（所选时区的当地时间）',local(event.end),'datetime-local')}
   <label>时区<select name="timezone" required><option value="">请选择时区</option>${Object.keys(zones).map(z=>`<option value="${z}"${z===tz?' selected':''}>${z}</option>`).join('')}</select></label>
   <label><input type="checkbox" name="all_day" value="yes"> 全天日程</label><p class="small">全天请将开始、结束设为 00:00，结束日期选择最后一天的次日。</p>
   ${field('location','地点／会议链接',event.location||'','text',300)}
   <label>提醒<select name="reminder"><option value="none">不提醒</option>${[0,5,15,30,60,1440].map(n=>`<option value="${n}">${n===0?'开始时':n===1440?'提前一天':'提前 '+n+' 分钟'}</option>`).join('')}</select></label>
   <label>备注<textarea name="notes" maxlength="2000">${esc(draft.summary.slice(0,500))}</textarea></label>
   <button type="submit" name="confirm" value="yes" style="width:100%;min-height:52px">确认加入 Outlook</button></form></section>`;
 }));
 return page(`<section class="card"><h1>添加日程</h1><p class="small">保存至：Outlook · 邮件助手　<a href="/f/${token}/original">原邮件</a></p><details><summary>使用说明</summary><p class="small">请核对提取结果；缺少的时间不会自动猜测。仅创建个人日程，不发送邀请、不修改原有活动。每项单独确认，未确认的项目不会写入。</p></details></section>${forms.join('')}`);
}
export async function createEvent(env,row,index,payload,{access=calendarAccess,graph=calendarGraph}={}){
 const {access:token,connection}=await access(env);
 if(connection.email!==CALENDAR_ACCOUNT||connection.status!=='ready'||!connection.calendar_id)throw Error('calendar_not_ready');
 const path='/me/calendars/'+encodeURIComponent(connection.calendar_id);
 const target=await graph(token,path+'?$select=id,name,canEdit');
 if(target.id!==connection.calendar_id||target.canEdit!==true||target.name!==CALENDAR_NAME)throw Error('calendar_target_changed');
 // Claim before the network write. Never reclaim uncertain/pending attempts.
 const transaction=crypto.randomUUID();
 const result=await env.DB.prepare(`INSERT OR IGNORE INTO outlook_calendar_events(message_key,item_index,transaction_id,status,payload_json,created_at)
   SELECT ?1,?2,?3,'submitting',?4,?5 WHERE EXISTS(SELECT 1 FROM feedback_links WHERE token=?6 AND (label IS NULL OR label!='calendar'))
   AND NOT EXISTS(SELECT 1 FROM outlook_calendar_legacy WHERE message_key=?1)`)
  .bind(row.message_key,index,transaction,JSON.stringify(payload),new Date().toISOString(),row.token).run();
 if(!result.meta?.changes)return {duplicate:true};
 let accepted=false;
 try{
  const event=await graph(token,path+'/events',{method:'POST',body:{...payload,transactionId:transaction}});
  accepted=true;if(!event.id)throw Error('missing_event_id');
  await env.DB.prepare("UPDATE outlook_calendar_events SET status='completed',event_id=?1,completed_at=?2 WHERE transaction_id=?3").bind(event.id,new Date().toISOString(),transaction).run();
  return {completed:true};
 }catch(error){
  const definite=!accepted&&[400,401,403,404,422,429].includes(error.httpStatus);
  await env.DB.prepare('UPDATE outlook_calendar_events SET status=?1,error=?2 WHERE transaction_id=?3').bind(definite?'failed':'uncertain',definite?'provider_rejected':'result_unknown',transaction).run();
  return {completed:false,uncertain:!definite};
 }
}
async function setup(env){
 const {access,connection}=await calendarAccess(env);
 if(connection.status==='ready')return {ready:true};
 const claim=await env.DB.prepare("UPDATE outlook_calendar_connection SET status='initializing' WHERE id=1 AND status IN ('authorized','needs_review')").run();
 if(!claim.meta?.changes)throw Error('setup_in_progress');
 try{
  let path='/me/calendars?$select=id,name,canEdit&$top=100',matches=[];
  for(let i=0;i<10&&path;i++){
   const result=await calendarGraph(access,path);matches.push(...(result.value||[]).filter(c=>c.name===CALENDAR_NAME));
   path='';if(result['@odata.nextLink']){const next=new URL(result['@odata.nextLink']);if(next.origin!=='https://graph.microsoft.com'||!next.pathname.startsWith('/v1.0/me/calendars'))throw Error('pagination');path=next.pathname.slice(5)+next.search;}
   if(i===9&&path)throw Error('too_many_calendars');
  }
  if(matches.length>1)throw Error('ambiguous_calendar');
  let calendar=matches[0];
  if(!calendar){if(connection.status==='needs_review')throw Error('creation_needs_review');calendar=await calendarGraph(access,'/me/calendars',{method:'POST',body:{name:CALENDAR_NAME}});}
  if(!calendar.id||calendar.canEdit===false)throw Error('calendar_not_editable');
  const verified=await calendarGraph(access,'/me/calendars/'+encodeURIComponent(calendar.id)+'?$select=id,name,canEdit');
  if(verified.name!==CALENDAR_NAME||verified.canEdit!==true)throw Error('calendar_not_editable');
  await env.DB.prepare("UPDATE outlook_calendar_connection SET calendar_id=?1,status='ready',last_error=NULL WHERE id=1").bind(calendar.id).run();
  return {ready:true,calendar_name:CALENDAR_NAME};
 }catch{await env.DB.prepare("UPDATE outlook_calendar_connection SET status='needs_review',last_error='setup_needs_review' WHERE id=1").run();throw Error('setup_needs_review');}
}
export async function handleOutlookCalendar(request,env,url,authorized){
 const match=url.pathname.match(/^\/f\/([A-Za-z0-9_-]{32})\/calendar$/);
 const admin=['/api/calendar/setup','/api/calendar/legacy','/api/calendar/events'].includes(url.pathname);
 if(!match&&!admin)return null;if(admin&&!authorized)return json({error:'unauthorized'},401);
 await ensureCalendar(env);await ensureCalendarOwnership(env);
 if(admin){
  if(url.pathname.endsWith('/events')&&request.method==='GET')return json({events:(await env.DB.prepare('SELECT message_key,item_index,status,event_id,created_at,error FROM outlook_calendar_events ORDER BY created_at DESC LIMIT 20').all()).results});
  if(request.method!=='POST')return json({error:'method'},405);
  let body;try{body=await request.json();}catch{return json({error:'json'},400);}
  if(body.confirm!==true)return json({error:'confirmation_required'},400);
  if(url.pathname.endsWith('/legacy')){
   if(!Array.isArray(body.keys)||body.keys.length>1000||body.keys.some(k=>!/^[a-f0-9]{64}$/.test(k)))return json({error:'keys'},400);
   if(body.keys.length)await env.DB.batch(body.keys.map(k=>env.DB.prepare('INSERT OR IGNORE INTO outlook_calendar_legacy(message_key) VALUES(?1)').bind(k)));
   return json({recorded:body.keys.length});
  }
  try{return json(await setup(env));}catch{return json({error:'calendar_setup_needs_attention'},409);}
 }
 if(!['GET','POST'].includes(request.method))return note('请求方式无效。',405);
 const token=match[1],row=await rowFor(env,token);
 if(!row||row.expires_at<=new Date().toISOString())return note('链接已过期，或这封邮件不是云端邮件。',410);
 if(request.method==='GET')return preview(env,url,token,row);
 if((request.headers.get('origin')&&!['null',url.origin].includes(request.headers.get('origin')))||request.headers.get('sec-fetch-site')==='cross-site')return note('请从邮件中的日程链接重新打开。',403);
 let form;try{form=await request.formData();}catch{return note('表单无效。',400);}
 const rawIndex=String(form.get('index')||''),index=Number(rawIndex),expires=String(form.get('expires')||''),now=Math.floor(Date.now()/1000);
 if(!/^\d{1,2}$/.test(rawIndex)||!/^\d{10}$/.test(expires)||Number(expires)<now||Number(expires)>now+1800||form.get('proof')!==await proof(env,token,index,expires))return note('预览已失效，请重新打开日程链接。',403);
 const draft=candidates(row);
 if(draft.blocked||!draft.events[index]||await legacyOwned(env,row))return note('该日程不可在此新增，请检查是否已有 Mac 日历请求或涉及取消、改期。',409);
 if(form.get('confirm')!=='yes')return note('请先核对预览并勾选确认。',400);
 let payload;try{payload=validateEvent(form,url.origin,token);}catch(error){return page(`<section class="card"><h1>请检查日程</h1><p>${esc(error.message)}</p><p>请用浏览器返回按钮保留并修改刚才填写的内容。</p></section>`,400);}
 try{await createEvent(env,row,index,payload);}catch{return note('日历暂不可用，未发起创建。请检查授权或目标日历。',503);}
 return new Response(null,{status:303,headers:{location:url.pathname,'cache-control':'no-store'}});
}
