# 从 ZIP 分发迁移到源码仓库

本文件是迁移操作说明，不表示远端已经迁移。2026-10-26 网页核对：仓库为 Private，远端 main 为 `a4591f4fb98860244cbf215e16ad17ff7ec72092`，根目录仅 README 与 ZIP。本地原始源码历史末端为 `8b85806`，两条历史不能直接互相覆盖。

## 保留历史的导入方式

1. 保存本地源码 Git bundle、原 ZIP 及其 SHA-256。确认源码工作区干净。远端可认证后，在新目录 clone 私有仓库，再用 `git bundle create ../remote-before-import.bundle --all` 备份远端历史。
2. 在该远端 clone 的最新 `origin/main` 上建立 `prepare/source-import` 分支。核对最新提交，若 main 已变化，先审阅新增内容。不要 reset、强推或用本地无关历史替换 main。
3. 用本包工具为已审阅的本地源码提交生成 ZIP 和 manifest；只把解压后的源码文件导入新分支，禁止复制 `.git`、个人配置、依赖目录、日志、凭证或数据库。README 以完整源码版为基础，同时保留远端独有且仍有效的信息。
4. 根目录原 ZIP 先保留，明确它是旧分发版本；当前源码以 `skills/` 为准。历史记录中原 ZIP 仍需安全扫描，新增安全源码不能消除旧提交中的信息。后续处理旧 ZIP 应作为独立、可审阅的变更。
5. 检查完整 diff、运行配置测试及 Worker 测试，检查相对文档链接。提交导入时记录本地来源完整 SHA、旧 ZIP SHA-256 和远端基线。
6. 常规 push 此分支并创建 PR。核对 PR 的目标仓库仍为 Private、base 是 main、差异只包含预期导入。合并后记录远端新提交；不改变可见性，不部署服务。此流程保留远端祖先；本地原历史单独保存在 bundle 中，不宣称两条历史已经合并。

若只有网页认证，可以在最新 main 上通过网页新增提交/分支导入，但必须保留文件层级并逐项核对。不能仅重新上传 ZIP 后宣称源码迁移完成。当前命令行缺少 GitHub 凭证时，先由作者完成认证；不要从浏览器提取 Cookie 或 Token。

## 可重复打包

在源码仓库中运行（输出目录必须不存在）：

```sh
python3 tools/package_release.py --ref <reviewed-commit> --output /absolute/path/new-release
```

工具只读取指定提交的 Git 对象，生成 ZIP、`SHA256SUMS`、逐文件 SHA-256 清单及来源提交。未提交修改不会进入包；固定 ZIP 时间和排序，在相同 Python/zlib 环境下相同源码可重复构建。路径白名单会拒绝常见运行数据、符号链接和子模块，但不能证明源码没有秘密，仍需内容及历史安全审查。

旧分发 ZIP 的 SHA-256：`500e398513fc09246a2d9af93978a64073e87adf7eab8b51f6a24f755301c086`。不要将旧值用于新包。
