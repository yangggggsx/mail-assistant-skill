import test from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {ensureDelivery,enqueueDelivery,drainDelivery,outcome,retrySeconds,handleDelivery,validatePayload} from './delivery-queue.js';
function envDB() {
  const db=new DatabaseSync(':memory:');
  const prepare=sql=>{
    let args=[];const q={bind(...v){args=v;return q;},async run(){const r=db.prepare(sql).run(...args);return {meta:{changes:Number(r.changes)}};},async first(){return db.prepare(sql).get(...args) || null;},async all(){return {results:db.prepare(sql).all(...args)}}};
    // D1 positional ?1 is a named SQLite parameter in node:sqlite.
    const normalized=sql.replace(/\?(\d+)/g,(_,n)=>`$p${n}`);
    const params=()=>Object.fromEntries(args.map((v,i)=>[`$p${i+1}`,v]));
    q.run=async()=>({meta:{changes:Number(db.prepare(normalized).run(params()).changes)}});
    q.first=async()=>db.prepare(normalized).get(params()) || null;
    q.all=async()=>({results:db.prepare(normalized).all(params())});
    return q;
  };
  return {DB:{prepare,batch:qs=>Promise.all(qs.map(q=>q.run()))},PUSHOVER_API_TOKEN:'test',PUSHOVER_USER_KEY:'test'};
}
const payload={title:'test',message:'message',priority:0,html:false};
test('response policy never calls an ambiguous outcome delivered',()=>{
  assert.equal(outcome(200,{status:1}),'accepted');assert.equal(outcome(429,{}),'retry');
  assert.equal(outcome(503,{status:0}),'retry');assert.equal(outcome(502,null),'uncertain');
  assert.equal(outcome(400,{status:0}),'blocked');assert.equal(outcome(200,null),'uncertain');
  assert.equal(retrySeconds(1),120);assert.equal(retrySeconds(10),3600);
});
test('duplicate enqueue does not overwrite or resend accepted delivery',async()=>{
  const env=envDB();await ensureDelivery(env);let sent=0;
  await enqueueDelivery(env,'test:once',payload);
  const fetcher=async()=>{sent++;return Response.json({status:1});};
  await drainDelivery(env,{fetcher});
  const duplicate=await enqueueDelivery(env,'test:once',{...payload,message:'changed'});
  await drainDelivery(env,{fetcher});
  assert.equal(sent,1);assert.equal(duplicate.status,'accepted');assert.equal(duplicate.duplicate,true);
});
test('rate limit persists retry with backoff, not a hot loop',async()=>{
  const env=envDB();await ensureDelivery(env);await enqueueDelivery(env,'test:retry',payload);let sent=0;
  const fetcher=async()=>{sent++;return Response.json({status:0},{status:429});};
  await drainDelivery(env,{fetcher});await drainDelivery(env,{fetcher});
  const row=await env.DB.prepare('SELECT * FROM delivery_queue').first();
  assert.equal(row.status,'retry');assert.equal(row.attempts,1);assert.equal(sent,1);assert.ok(Date.parse(row.next_at)>Date.now());
});
test('timeout and expired lease are quarantined, never automatically resent',async()=>{
  const env=envDB();await ensureDelivery(env);await enqueueDelivery(env,'test:timeout',payload);let sent=0;
  const fetcher=async()=>{sent++;throw new Error('timeout');};
  await drainDelivery(env,{fetcher});await drainDelivery(env,{fetcher});
  assert.equal(sent,1);assert.equal((await env.DB.prepare('SELECT status FROM delivery_queue').first()).status,'uncertain');
  await env.DB.prepare("UPDATE delivery_queue SET status='sending',lease_until='2000-01-01'").run();
  await drainDelivery(env,{fetcher});assert.equal(sent,1);
});
test('Mac owns production until explicit handoff; tests do not flip ownership',async()=>{
  const env=envDB();await ensureDelivery(env);await enqueueDelivery(env,'mail:'+'a'.repeat(64),payload);
  let sent=0;await drainDelivery(env,{fetcher:async()=>{sent++;return Response.json({status:1});}});
  assert.equal(sent,0);assert.equal((await env.DB.prepare('SELECT owner FROM delivery_handoff').first()).owner,'mac');
});
test('unauthenticated caller cannot initialize or change queue',async()=>{
  const url=new URL('https://example.com/api/delivery/handoff');
  const response=await handleDelivery(new Request(url,{method:'POST'}),{},url,false);assert.equal(response.status,401);
});
test('concurrent drains acquire one claim only',async()=>{
  const env=envDB();await ensureDelivery(env);await enqueueDelivery(env,'test:parallel',payload);let sent=0;
  const fetcher=async()=>{sent++;return Response.json({status:1});};
  await Promise.all([drainDelivery(env,{fetcher}),drainDelivery(env,{fetcher})]);assert.equal(sent,1);
});
test('handoff enables production and seeded receipts cannot resend',async()=>{
  const env=envDB();await ensureDelivery(env);
  const call=async(path,b)=>{const url=new URL('https://local/api/delivery/'+path);return handleDelivery(new Request(url,{method:'POST',body:JSON.stringify(b)}),env,url,true);};
  const key='mail:'+'a'.repeat(64);
  assert.equal((await call('handoff',{owner:'cloud'})).status,400);
  assert.equal((await call('seed-receipts',{keys:[key]})).status,200);
  assert.equal((await call('handoff',{owner:'cloud',confirm_mac_sender_stopped:true})).status,200);
  const receipt=await (await call('enqueue',{key,payload})).json();
  assert.equal(receipt.status,'accepted');assert.equal(receipt.duplicate,true);
  let sent=0;await drainDelivery(env,{fetcher:async()=>{sent++;return Response.json({status:1});}});assert.equal(sent,0);
});
test('reject payload sizes, foreign destinations and emergency repeat priority',()=>{
  assert.throws(()=>validatePayload({...payload,url:'https://evil.example/'},'https://example.com'));
  assert.throws(()=>validatePayload({...payload,priority:2},'https://example.com'));
  assert.throws(()=>validatePayload({...payload,message:'x'.repeat(1025)},'https://example.com'));
});
