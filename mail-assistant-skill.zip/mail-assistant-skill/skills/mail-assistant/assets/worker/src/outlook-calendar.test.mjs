import test from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync} from 'node:fs';
import {handleCalendarAuth,ensureCalendar,CALENDAR_ACCOUNT,calendarGraph} from './outlook-calendar-auth.js';
import {localInstant,validateEvent,candidates,createEvent,handleOutlookCalendar,ensureCalendarOwnership} from './outlook-calendar.js';
import {ensurePipeline,notification} from './cloud-pipeline.js';
import worker from './index.js';
import {ensureMigration,importCourse,migrationPayload,handleCourseMigration} from './calendar-migration.js';
function environment(){
 const db=new DatabaseSync(':memory:');db.exec(readFileSync(new URL('../schema.sql',import.meta.url),'utf8'));
 const prepare=sql=>{let args=[];const q=sql.replace(/\?(\d+)/g,(_,n)=>`$p${n}`),p=()=>Object.fromEntries(args.map((v,i)=>[`$p${i+1}`,v]));return {bind(...v){args=v;return this},async run(){return {meta:{changes:Number(db.prepare(q).run(p()).changes)}}},async first(){return db.prepare(q).get(p())||null},async all(){return {results:db.prepare(q).all(p())}}};};
 return {MICROSOFT_CLIENT_ID:'test-client',MICROSOFT_CLIENT_SECRET:'test-secret',TOKEN_ENCRYPTION_KEY:btoa('a'.repeat(32)),API_TOKEN:'test',DB:{prepare,batch:async qs=>{db.exec('BEGIN');try{const result=await Promise.all(qs.map(q=>q.run()));db.exec('COMMIT');return result;}catch(e){db.exec('ROLLBACK');throw e;}}}};
}
const migration=()=>({confirm:true,source_calendar:'课程安排',disable_reminders:true,source_key:'c'.repeat(64),source_uid:'local-uid',course_key:'course',item_key:'exam',event:{title:'Exam',start:'2026-11-01T18:00:00',end:'2026-11-01T19:00:00',timezone:'UTC',all_day:false,location:'Room',notes:'Source'}});
test('course migration is authenticated, never invites or enables reminders, and validates dates',async()=>{
 const env=environment(),url=new URL('https://example.test/api/calendar/course-import');
 assert.equal((await handleCourseMigration(new Request(url),env,url,false)).status,401);
 const b=migration(),p=migrationPayload(b);assert.equal(p.isReminderOn,false);assert.equal(p.attendees,undefined);
 assert.throws(()=>migrationPayload({...b,disable_reminders:false}));
 assert.throws(()=>migrationPayload({...b,event:{...b.event,start:'2026-02-30T18:00:00'}}));
});
test('course migration stores verified mapping once and does not repeat uncertain writes',async()=>{
 for(const fail of [false,true]){
  const env=environment();await ensureMigration(env);let writes=0,payload;
  const deps={access:async()=>({access:'token',connection:{email:CALENDAR_ACCOUNT,status:'ready',calendar_id:'target'}}),graph:async(t,p,o)=>{
   if(p.endsWith('?$select=id,name,canEdit'))return {id:'target',name:'邮件助手',canEdit:true};
   if(o?.method==='POST'){writes++;if(fail)throw Error('timeout');payload=o.body;return {id:'event',...payload};}
   return {id:'event',...payload};
  }};
  const result=await importCourse(env,migration(),deps);assert.equal(result.status,fail?'uncertain':'verified');
  assert.equal((await importCourse(env,migration(),deps)).duplicate,true);assert.equal(writes,1);
  const row=await env.DB.prepare('SELECT * FROM calendar_course_migrations').first();assert.equal(row.course_key,'course');assert.equal(JSON.parse(row.payload_json).isReminderOn,false);
 }
});
test('calendar OAuth uses separate state, expected account and calendar scope without changing mail connections',async()=>{
 const env=environment(),url=new URL('https://example.test/api/calendar/connect');
 assert.equal((await handleCalendarAuth(new Request(url,{method:'POST'}),env,url,false)).status,401);
 const result=await (await handleCalendarAuth(new Request(url,{method:'POST'}),env,url,true)).json();
 const auth=new URL(result.authorization_url);assert.equal(auth.searchParams.get('login_hint'),CALENDAR_ACCOUNT);
 assert.match(auth.searchParams.get('scope'),/Calendars.ReadWrite/);assert.doesNotMatch(auth.searchParams.get('scope'),/Mail.Read/);
 const state=await env.DB.prepare('SELECT * FROM oauth_states WHERE state=?1').bind(auth.searchParams.get('state')).first();assert.equal(state.provider,'microsoft-calendar');
 assert.equal((await env.DB.prepare('SELECT count(*) n FROM cloud_accounts').first()).n,0);
});
test('mail callback not consumed by calendar handler and expired calendar states rejected',async()=>{
 const env=environment();await ensureCalendar(env);
 const url=new URL('https://example.test/oauth/microsoft/callback?state=mail&code=code');
 assert.equal(await handleCalendarAuth(new Request(url),env,url,false),null);
 await env.DB.prepare("INSERT INTO oauth_states(state,provider,created_at,expires_at) VALUES('old','microsoft-calendar','2000','2000')").run();
 url.searchParams.set('state','old');assert.equal((await handleCalendarAuth(new Request(url),env,url,false)).status,400);
});
test('calendar callback saves separate encrypted credential only for expected account',async()=>{
 const originalFetch=globalThis.fetch;
 try{
  for(const email of ['wrong@example.com',CALENDAR_ACCOUNT]){
   const env=environment(),start=new URL('https://example.test/api/calendar/connect');
   await env.DB.prepare("INSERT INTO cloud_accounts(provider,email,refresh_token_enc,history_cursor,status,shadow_mode,connected_at) VALUES('microsoft',?1,'mail-credential','keep-cursor','active',0,'now')").bind(CALENDAR_ACCOUNT).run();
   const auth=await (await handleCalendarAuth(new Request(start,{method:'POST'}),env,start,true)).json();
   const state=new URL(auth.authorization_url).searchParams.get('state');
   globalThis.fetch=async url=>String(url).includes('/token')?Response.json({access_token:'access',refresh_token:'calendar-refresh',scope:'User.Read Calendars.ReadWrite'}):Response.json({mail:email});
   const callback=new URL('https://example.test/oauth/microsoft/callback?code=code&state='+state);
   const response=await handleCalendarAuth(new Request(callback),env,callback,false);
   assert.equal(response.status,email===CALENDAR_ACCOUNT?200:400);
   const calendar=await env.DB.prepare('SELECT * FROM outlook_calendar_connection').first();
   if(email===CALENDAR_ACCOUNT){assert.match(calendar.refresh_token_enc,/^v1\./);assert.notEqual(calendar.refresh_token_enc,'calendar-refresh');assert.equal(calendar.status,'authorized');}
   else assert.equal(calendar,null);
   const mail=await env.DB.prepare('SELECT * FROM cloud_accounts').first();assert.equal(mail.history_cursor,'keep-cursor');assert.equal(mail.shadow_mode,0);assert.equal(mail.refresh_token_enc,'mail-credential');
  }
 }finally{globalThis.fetch=originalFetch;}
});
test('Graph wrapper refuses arbitrary hosts',async()=>{
 await assert.rejects(calendarGraph('secret','https://evil.test'),/invalid_graph_path/);
});
const eventForm=(extra={})=>new URLSearchParams({title:'Review meeting',start:'2026-10-25T14:00',end:'2026-10-25T15:00',timezone:'America/Chicago',location:'Room 1',notes:'Bring notes',reminder:'none',...extra});
test('local date conversion handles seasonal offsets and rejects nonexistent or ambiguous DST times',()=>{
 assert.equal(new Date(localInstant('2026-07-01T14:00','America/Chicago')).toISOString(),'2026-07-01T19:00:00.000Z');
 assert.equal(new Date(localInstant('2026-12-01T14:00','America/Chicago')).toISOString(),'2026-12-01T20:00:00.000Z');
 for(const value of ['2026-03-08T02:30','2026-11-01T01:30'])assert.throws(()=>localInstant(value,'America/Chicago'),/夏令时/);
 assert.throws(()=>localInstant('2026-02-30T12:00','UTC'),/无效/);
});
test('event payload is bounded, personal, explicitly zoned and has no invitation or recurrence fields',()=>{
 const p=validateEvent(eventForm(),'https://example.test','t');
 assert.equal(p.start.timeZone,'Central Standard Time');assert.equal(p.isReminderOn,false);
 assert.equal(p.attendees,undefined);assert.equal(p.recurrence,undefined);assert.equal(p.isOnlineMeeting,undefined);
 assert.match(p.body.content,/\/f\/t\/original/);
 for(const fields of [{end:'2026-10-25T13:00'},{timezone:'bad'},{title:''},{all_day:'yes'},{reminder:'3'}])assert.throws(()=>validateEvent(eventForm(fields),'https://example.test','t'));
 const day=validateEvent(eventForm({all_day:'yes',start:'2026-10-25T00:00',end:'2026-10-26T00:00'}),'https://example.test','t');assert.equal(day.isAllDay,true);
});
test('mixed reschedule operations are blocked; missing time is not invented',()=>{
 assert.equal(candidates({classification_json:JSON.stringify({calendar:{events:[{action:'cancel'},{action:'create'}]}})}).blocked,true);
 const c=candidates({subject:'No time',classification_json:'{}'});assert.equal(c.events[0].start,'');assert.equal(c.events[0].end,'');
});
async function calendarFixture(){
 const env=environment();await ensurePipeline(env);await ensureCalendarOwnership(env);
 const token='c'.repeat(32),key='c'.repeat(64),now=new Date().toISOString();
 await env.DB.prepare('INSERT INTO feedback_links(token,message_key,created_at,expires_at) VALUES(?1,?2,?3,?4)').bind(token,key,now,'2099-01-01').run();
 await env.DB.prepare("INSERT INTO cloud_messages(message_key,observation_id,subject,classification_json,usage_json,feedback_token,created_at) VALUES(?1,1,'Mail event','{}','{}',?2,?3)").bind(key,token,now).run();
 await env.DB.prepare("INSERT INTO outlook_calendar_connection(id,email,refresh_token_enc,calendar_id,status,connected_at) VALUES(1,?1,'encrypted','target','ready',?2)").bind(CALENDAR_ACCOUNT,now).run();
 const row=await env.DB.prepare('SELECT * FROM feedback_links WHERE token=?1').bind(token).first();
 const access=async()=>({access:'private',connection:{email:CALENDAR_ACCOUNT,calendar_id:'target',status:'ready'}});
 return {env,row,token,key,access};
}
test('creation claims once, writes only allowlisted calendar and never sends attendees',async()=>{
 const {env,row,access}=await calendarFixture();const calls=[];
 const graph=async(t,path,options)=>{calls.push({path,options});return options?.method==='POST'?{id:'created'}:{id:'target',name:'邮件助手',canEdit:true};};
 const payload=validateEvent(eventForm(),'https://example.test',row.token);
 assert.equal((await createEvent(env,row,0,payload,{access,graph})).completed,true);
 assert.equal((await createEvent(env,row,0,payload,{access,graph})).duplicate,true);
 const writes=calls.filter(x=>x.options?.method==='POST');assert.equal(writes.length,1);assert.equal(writes[0].path,'/me/calendars/target/events');
 assert.ok(writes[0].options.body.transactionId);assert.equal(writes[0].options.body.attendees,undefined);
 const saved=await env.DB.prepare('SELECT * FROM outlook_calendar_events').first();assert.equal(saved.status,'completed');assert.equal(saved.event_id,'created');
});
test('ambiguous network result is durable and a second click never issues another create',async()=>{
 const {env,row,access}=await calendarFixture();let writes=0;
 const graph=async(t,path,options)=>{if(options?.method==='POST'){writes++;throw Error('timeout')}return {id:'target',name:'邮件助手',canEdit:true}};
 const payload=validateEvent(eventForm(),'https://example.test',row.token);
 assert.equal((await createEvent(env,row,0,payload,{access,graph})).uncertain,true);
 await createEvent(env,row,0,payload,{access,graph});assert.equal(writes,1);
 assert.equal((await env.DB.prepare('SELECT status FROM outlook_calendar_events').first()).status,'uncertain');
});
test('old Mac ownership blocks write even when stale form is submitted',async()=>{
 const {env,row,access,key}=await calendarFixture();let writes=0;
 await env.DB.prepare('INSERT INTO outlook_calendar_legacy(message_key) VALUES(?1)').bind(key).run();
 const graph=async(t,p,o)=>{if(o)writes++;return {id:'target',name:'邮件助手',canEdit:true}};
 assert.equal((await createEvent(env,row,0,{}, {access,graph})).duplicate,true);assert.equal(writes,0);
});
test('legacy calendar feedback claims durable Mac ownership and cloud-owned events cannot be handed to Mac',async()=>{
 const {env,row,key,token}=await calendarFixture();
 const url='https://example.test/f/'+token;
 const submit=()=>worker.fetch(new Request(url,{method:'POST',body:new URLSearchParams({label:'calendar'})}),env,{});
 assert.equal((await submit()).status,200);
 assert.ok(await env.DB.prepare('SELECT 1 FROM outlook_calendar_legacy WHERE message_key=?1').bind(key).first());
 await env.DB.prepare("INSERT INTO outlook_calendar_events(message_key,item_index,transaction_id,status,payload_json,created_at) VALUES(?1,0,'t','completed','{}','now')").bind(key).run();
 assert.equal((await submit()).status,409);
});
test('preview is editable, GET never creates events, signed expired or cross-origin submissions are rejected',async()=>{
 const {env,token}=await calendarFixture();const url=new URL('https://example.test/f/'+token+'/calendar');
 const result=await handleOutlookCalendar(new Request(url),env,url,false);assert.equal(result.status,200);const html=await result.text();
 assert.match(html,/<h1>添加日程<\/h1>/);
 assert.doesNotMatch(html,/<input[^>]*name="confirm"/);
 assert.match(html,/<button[^>]*name="confirm"[^>]*>确认加入 Outlook<\/button>/);
 assert.match(html,/保存至：Outlook · 邮件助手/);
 assert.match(html,/<details><summary>使用说明<\/summary>/);
 assert.doesNotMatch(html,/无需 Mac 在线|预览并编辑日程|<p class="warning">仅创建/);
 for(const name of ['title','start','end','timezone','location','notes','reminder','confirm'])assert.ok(html.includes('name="'+name+'"'));
 assert.equal((await env.DB.prepare('SELECT count(*) n FROM outlook_calendar_events').first()).n,0);
 const proof=html.match(/name="proof" value="([^"]+)"/)[1],expires=html.match(/name="expires" value="([^"]+)"/)[1];
 for(const [origin,signature,expiry] of [['https://evil.test',proof,expires],['null','bad',expires],['null',proof,'1000000000']]){
  const response=await handleOutlookCalendar(new Request(url,{method:'POST',headers:{origin},body:eventForm({index:'0',expires:expiry,proof:signature,confirm:'yes'})}),env,url,false);assert.equal(response.status,403);
 }
});
test('calendar link is gated and immediately follows todo within push size limit',()=>{
 const c={importance:'normal',mail_type:'calendar_event',summary:'&'.repeat(500)};
 const before=notification({subject:'s',sender:'a'},c,'a'.repeat(32),'shortcuts://a');assert.doesNotMatch(before.message,/\/calendar/);
 const after=notification({subject:'s',sender:'a'},c,'a'.repeat(32),'shortcuts://a',true);assert.ok(after.message.length<=1024);assert.ok(after.message.indexOf('/calendar')>after.message.indexOf('/todo'));
});
