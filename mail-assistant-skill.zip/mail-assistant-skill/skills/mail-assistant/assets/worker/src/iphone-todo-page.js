const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));

// Never claim a task during page rendering or preview. The shortcut owns the POST.
// A visible document may attempt to launch once; returning to it never relaunches.
export const todoLaunchScript=`(()=>{
const launch=document.getElementById('launch'),status=document.getElementById('status');
if(!launch)return;
const phone=/iPhone|iPad|iPod/.test(navigator.userAgent)||(/Macintosh/.test(navigator.userAgent)&&navigator.maxTouchPoints>1);
if(!phone)return;
let attempted=false,timer;
function showFallback(){document.getElementById('fallback').hidden=false;}
function start(){
 if(attempted||document.hidden)return;
 attempted=true;
 status.textContent='正在打开快捷指令…';
 timer=setTimeout(()=>{showFallback();if(!document.hidden)status.textContent='若没有跳转，请点击下方按钮。';},1800);
 try{location.href=launch.href;}catch{showFallback();status.textContent='浏览器未允许自动打开，请使用下方按钮。';}
}
launch.addEventListener('click',()=>{attempted=true;clearTimeout(timer);});
window.addEventListener('pagehide',()=>{attempted=true;clearTimeout(timer);showFallback();});
document.addEventListener('visibilitychange',()=>{
 if(document.hidden){if(attempted){clearTimeout(timer);showFallback();}}
 else if(attempted){showFallback();status.textContent='正在核对添加结果…';}
 else start();
});
document.getElementById('fallback').hidden=true;
start();
})();`;

// Read-only polling of the authenticated shortcut receipt; returning to the app
// is never treated as proof that a reminder was created.
export const todoStatusScript=`(()=>{
const status=document.getElementById('status'),fallback=document.getElementById('fallback');
let timer,busy=false,attempts=0,completed=false;
async function check(){
 clearTimeout(timer);
 if(document.hidden||busy)return;
 busy=true;
 try{
  const r=await fetch(location.pathname.replace(/\\/$/,'')+'/status',{cache:'no-store',signal:AbortSignal.timeout(10000)});
  if(!r.ok)throw Error('status');
  const data=await r.json();
  completed=data.status==='completed';
  if(completed){status.textContent='✓ 已添加到「邮件待办」';if(fallback)fallback.hidden=true;}
  else if(data.status==='iphone_claimed'){status.textContent='正在等待快捷指令确认添加结果…';if(fallback)fallback.hidden=true;}
  else if(data.status==='pending'){status.textContent='任务已提交，尚未完成。';}
  else if(data.status==='failed'){status.textContent='添加未完成，请先检查「邮件待办」，不要重复运行。';}
 }catch{status.textContent='暂时无法核对结果，请先检查「邮件待办」。';}
 finally{busy=false;if(!completed&&!document.hidden&&++attempts<60)timer=setTimeout(check,2000);
 else if(!completed&&attempts>=60)status.textContent='尚未收到完成回执，请先检查「邮件待办」，不要重复添加。';}
}
function resume(){if(!document.hidden){attempts=0;check();}}
document.addEventListener('visibilitychange',resume);
window.addEventListener('pageshow',resume);
window.addEventListener('focus',resume);
check();
})();`;

export function iphoneTodoPage(launch,task) {
 const nonce=crypto.randomUUID();
 const blocked=Boolean(task);
 const status=task?.status==='completed'?'已加入「邮件待办」':task?.status==='pending'?'这封邮件已交给 Mac 处理':blocked?'这封邮件已有待办任务，请先核对「邮件待办」':'正在准备打开快捷指令…';
 const body=task?.status==='completed'?'':blocked?'<p id="fallback">为避免重复创建，本页不会再次启动。若上次中断，请先检查提醒事项。</p>':
 `<div id="fallback"><a id="launch" href="${esc(launch)}">打开「加入待办」快捷指令</a><details><summary>未安装或无法打开？</summary><p>请在 iPhone 安装并配置「邮件助手-加入待办」，写入 iCloud 的「邮件待办」列表。网页无法检测是否已安装。系统可能要求确认打开。</p></details><p class="note">若已添加，请关闭此页；中断后先检查提醒事项，不要反复运行。不会自动设置提醒时间。</p></div>`;
 return new Response(`<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="color-scheme" content="light dark"><title>加入待办</title><style>body{font:17px -apple-system,sans-serif;background:#f4f5f7;color:#171717;margin:0}main{max-width:480px;margin:32px auto;padding:24px}section{background:white;border-radius:22px;padding:24px}h1{font-size:25px;margin:0 0 12px}p{line-height:1.6;color:#666}a{display:block;padding:16px;border-radius:14px;background:#1877f2;color:white;text-align:center;text-decoration:none}details{margin-top:20px;color:#666;line-height:1.6}.note{font-size:13px}[hidden]{display:none!important}@media(prefers-color-scheme:dark){body{background:#111;color:#eee}section{background:#202124}p,details{color:#bbb}}</style><main><section><h1>加入待办</h1><p id="status" role="status">${esc(status)}</p>${body}</section></main><script nonce="${nonce}">${todoLaunchScript}${todoStatusScript}</script></html>`,{headers:{'content-type':'text/html; charset=utf-8','cache-control':'no-store','referrer-policy':'no-referrer','x-content-type-options':'nosniff','content-security-policy':`default-src 'none'; connect-src 'self'; style-src 'unsafe-inline'; script-src 'nonce-${nonce}'; frame-ancestors 'none'; base-uri 'none'; form-action 'none'`}});
}
