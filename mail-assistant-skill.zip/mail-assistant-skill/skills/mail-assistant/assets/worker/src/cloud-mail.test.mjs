import assert from "node:assert/strict";
import test from "node:test";

import {
  collectMicrosoftDelta,
  isMicrosoftDeltaCursor,
  microsoftDeltaInitialPath,
} from "./cloud-mail.js";

const DELTA = "https://graph.microsoft.com/v1.0/me/mailFolders/inbox/messages/delta?$deltatoken=final";
const NEXT = "https://graph.microsoft.com/v1.0/me/mailFolders/inbox/messages/delta?$skiptoken=next";

test('junk folder uses independent delta baseline with handoff boundary',async()=>{
 const cutoff='2026-10-22T23:00:00.000Z';let requested;
 const d=DELTA.replace('inbox','junkemail');
 await collectMicrosoftDelta('access',null,async target=>{requested=target;return {value:[], '@odata.deltaLink':d}},new Date(),'junkemail',cutoff);
 const u=new URL(requested,'https://graph.microsoft.com');
 assert.equal(u.pathname,'/me/mailFolders/junkemail/messages/delta');
 assert.equal(u.searchParams.get('$filter'),'receivedDateTime ge '+cutoff);
 assert.throws(()=>microsoftDeltaInitialPath(new Date(),'anything'),/unsupported_folder/);
});

test("legacy timestamp cursor starts a bounded two-day delta baseline", () => {
  const path = microsoftDeltaInitialPath(new Date("2026-08-24T12:00:00Z"));
  const url = new URL(path, "https://graph.microsoft.com");
  assert.equal(url.pathname, "/me/mailFolders/inbox/messages/delta");
  assert.equal(url.searchParams.get("changeType"), "created");
  assert.equal(url.searchParams.get("$top"), "50");
  assert.equal(url.searchParams.get("$filter"), "receivedDateTime ge 2026-08-22T12:00:00.000Z");
  assert.equal(isMicrosoftDeltaCursor("2026-08-24T12:00:00Z"), false);
  assert.equal(isMicrosoftDeltaCursor(DELTA), true);
  assert.equal(isMicrosoftDeltaCursor(
    "https://graph.microsoft.com/v1.0/me/mailfolders('folder-id')/messages/delta?$deltatoken=final",
  ), true);
});

test("delta sync follows every page, ignores removals, and commits only final cursor", async () => {
  const requested = [];
  const graph = async (target) => {
    requested.push(target);
    if (requested.length === 1) {
      return {
        value: [{ id: "new-1" }, { id: "deleted", "@removed": { reason: "deleted" } }],
        "@odata.nextLink": NEXT,
      };
    }
    return { value: [{ id: "new-2" }], "@odata.deltaLink": DELTA };
  };

  const result = await collectMicrosoftDelta("access", "2026-08-24T12:00:00Z", graph,
    new Date("2026-08-24T12:00:00Z"));
  assert.deepEqual(result.messages.map((message) => message.id), ["new-1", "new-2"]);
  assert.equal(result.pages, 2);
  assert.equal(result.deltaLink, DELTA);
  assert.equal(requested[1], NEXT);
});

test("delta sync rejects a page sequence without a durable cursor", async () => {
  await assert.rejects(
    collectMicrosoftDelta("access", DELTA, async () => ({ value: [] })),
    /valid deltaLink/,
  );
});

test("delta sync rejects pagination to a non-Graph host", async () => {
  await assert.rejects(
    collectMicrosoftDelta("access", DELTA, async () => ({
      value: [], "@odata.nextLink": "https://example.invalid/steal",
    })),
    /invalid nextLink host/,
  );
});
