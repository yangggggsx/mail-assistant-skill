import test from "node:test";
import assert from "node:assert/strict";

import {
  feedbackActionActive, originalMailRedirect, renderTranslationBlock, retentionCutoffs,
} from "./index.js";
import { scheduleTestHelpers } from "./schedules.js";


test("feedback actions expire after 30 days while the view link may remain valid", () => {
  const now = new Date("2026-08-24T20:00:00.000Z");
  assert.equal(feedbackActionActive({
    created_at: "2026-07-26T20:00:00.000Z",
    expires_at: "2027-07-26T20:00:00.000Z",
  }, now), true);
  assert.equal(feedbackActionActive({
    created_at: "2026-07-24T19:59:59.000Z",
    expires_at: "2027-07-24T19:59:59.000Z",
  }, now), false);
  assert.equal(feedbackActionActive({
    created_at: "2026-08-20T20:00:00.000Z",
    expires_at: "2026-08-23T20:00:00.000Z",
  }, now), false);
});


test("retention cutoffs separate translation snippets observations and link cleanup", () => {
  const cutoff = retentionCutoffs(new Date("2026-08-31T00:00:00.000Z"));
  assert.equal(cutoff.translation, "2026-08-24T00:00:00.000Z");
  assert.equal(cutoff.snippet, "2026-08-24T00:00:00.000Z");
  assert.equal(cutoff.observation, "2026-08-01T00:00:00.000Z");
  assert.equal(cutoff.acknowledgedNote, "2026-08-01T00:00:00.000Z");
  assert.equal(cutoff.expiredLink, "2026-08-01T00:00:00.000Z");
  assert.equal(cutoff.staleOauth, "2026-08-30T00:00:00.000Z");
});


test("completed translations preserve paragraph breaks and escape rich content", () => {
  const rendered = renderTranslationBlock({
    status: "completed",
    translation_text: "第一段\n\n第二段 <不要执行>",
  });
  assert.match(rendered, /class="translation-text"/);
  assert.match(rendered, /第一段<\/div><div class="translation-paragraph">第二段 &lt;不要执行&gt;/);
  assert.doesNotMatch(rendered, /<p>第一段/);
});


test("original mail direct action redirects only to a validated Apple Mail URL", () => {
  const response = originalMailRedirect("message://%3Cexample%40mail%3E");
  assert.equal(response.status, 302);
  assert.equal(response.headers.get("location"), "message://%3Cexample%40mail%3E");
  assert.equal(originalMailRedirect("https://attacker.example/"), null);
});


test("schedule tokens and upload limits are validated defensively", () => {
  assert.equal(scheduleTestHelpers.validToken("A".repeat(32)), true);
  assert.equal(scheduleTestHelpers.validToken("../../secret"), false);
  assert.equal(scheduleTestHelpers.MAX_UPLOAD_BYTES, 20 * 1024 * 1024);
  assert.equal(scheduleTestHelpers.MAX_FILES, 10);
});


test("schedule uploads identify supported files by their signatures", () => {
  const detect = scheduleTestHelpers.detectInputType;
  assert.equal(detect(new TextEncoder().encode("%PDF-1.7")), "application/pdf");
  assert.equal(detect(Uint8Array.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a])), "image/png");
  assert.equal(detect(Uint8Array.from([0xff, 0xd8, 0xff, 0xe0])), "image/jpeg");
  assert.equal(detect(new TextEncoder().encode("RIFF0000WEBPdata")), "image/webp");
  assert.equal(detect(new TextEncoder().encode("0000ftypheic0000")), "image/heic");
  assert.equal(detect(new TextEncoder().encode("not really a png")), null);
});


test("schedule filenames cannot preserve paths or control characters", () => {
  assert.equal(scheduleTestHelpers.cleanFilename("../../private/course\u0000.png", "fallback"), "course.png");
  assert.equal(scheduleTestHelpers.cleanFilename("", "schedule.pdf"), "schedule.pdf");
});


