import test from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {ensureCloudSchedules,runSchedule,applyCourseItem,cloudSchedulePage,confirmCloudSchedule} from './cloud-schedules.js';
import {handleScheduleRoute} from './schedules.js';
import {courseKey,itemKey,normalizeCourse,coursePayload,extractCourse,fingerprint} from './course-extraction.js';
import {CALENDAR_ACCOUNT} from './outlook-calendar-auth.js';
import {auditRecentSchedules,handleCourseMigration} from './calendar-migration.js';
test('calendar write status refreshes promptly without re-submitting',async()=>{
 const page=await(await cloudSchedulePage(env(),{token:'test',filename:'test.pdf',status:'cloud_applying'})).text();
 assert.match(page,/location.reload\(\),2000/);
 assert.doesNotMatch(page,/可以离开|fetch\(|method="post"/);
});
test('recent schedule audit is bounded, admin-only and never writes events',async()=>{
 const e=env();await ensureCloudSchedules(e);
 for(let i=0;i<7;i++)await e.DB.prepare("INSERT INTO cloud_course_bindings VALUES(?1,'course',?2,'target','{}',NULL,'active',NULL,?3)").bind(String(i),'event'+i,String(i)).run();
 const calls=[];const result=await auditRecentSchedules(e,{access:async()=>({access:'test',connection:{email:CALENDAR_ACCOUNT,status:'ready',calendar_id:'target'}}),graph:async(t,p,o={})=>{
  assert.equal(o.method,undefined);calls.push(p);
  return p.includes('/events/')?{subject:'Halloween Party',start:{dateTime:'2026-10-30T19:00:00'},end:{dateTime:'2026-10-30T23:00:00'}}:{id:'target',name:'邮件助手',canEdit:true};
 }});
 assert.equal(result.events.length,5);assert.equal(calls.length,6);
 const u=new URL('https://example.test/api/calendar/schedule-audit');
 assert.equal((await handleCourseMigration(new Request(u),e,u,false)).status,401);
 assert.equal((await handleCourseMigration(new Request(u,{method:'POST'}),e,u,true)).status,405);
});
function env(){const db=new DatabaseSync(':memory:');const prepare=sql=>{let args=[];const q=sql.replace(/\?(\d+)/g,(_,n)=>`$p${n}`),p=()=>Object.fromEntries(args.map((v,i)=>[`$p${i+1}`,v instanceof ArrayBuffer?new Uint8Array(v):v]));return {bind(...v){args=v;return this},async run(){return {meta:{changes:Number(db.prepare(q).run(p()).changes)}}},async first(){return db.prepare(q).get(p())||null},async all(){return {results:db.prepare(q).all(p())}}};};return {API_TOKEN:'secret',OPENAI_API_KEY:'test',MAIL_AI_MODEL:'configured-model',ACTION_QUEUE:{send:async()=>{}},DB:{prepare,batch:async qs=>{db.exec('BEGIN');try{const r=[];for(const q of qs)r.push(await q.run());db.exec('COMMIT');return r;}catch(e){db.exec('ROLLBACK');throw e;}}}};}
const token='a'.repeat(32),job={course_hint:'ESE 5700',term_hint:'Fall 2026',timezone:'America/Chicago'};
const source=(extra={})=>({action:'create',kind:'exam',milestone:'event',item_id:'Exam1',title:'ESE 5700 期中考试',start:'2026-11-10T10:00',end:'2026-11-10T12:00',all_day:false,timezone:'America/Chicago',location:'Room 2',description:'带计算器',source_text:'Exam Nov 10',...extra});
const raw=(events=[source()])=>({course_id:'ESE5700',course_name:'Course',term:'Fall2026',warnings:[],events});
test('live cloud preview recommends due and updates, not assigned or unresolved items',async()=>{
 const events=[source({kind:'homework',milestone:'due'}),source({kind:'homework',milestone:'assigned'}),source({action:'existing'}),source({action:'update'}),source({action:'possible_cancel'}),source({issue:'时间不完整'})];
 const page=await(await cloudSchedulePage(env(),{token:'test',status:'cloud_preview',preview_json:JSON.stringify({...raw(events),warnings:[]})})).text();
 const inputs=[...page.matchAll(/<input type="checkbox" name="item"[^>]*>/g)].map(x=>x[0]);
 assert.equal(inputs.length,6);
 assert.deepEqual(inputs.map(x=>/\bchecked\b/.test(x)),[true,false,false,true,false,false]);
});
test('retired schedule endpoints remain fenced for every method and never touch storage',async()=>{
 const e={DB:{prepare(){throw Error('retired endpoint accessed storage');}}};
 for(const path of ['pull','confirmed','claim','apply-claim','result','complete'])for(const method of ['GET','POST']){
  const url=new URL('https://example.test/api/schedules/'+path);
  assert.equal((await handleScheduleRoute(new Request(url,{method}),e,url,false)).status,401);
  const r=await handleScheduleRoute(new Request(url,{method}),e,url,true);
  const read=['pull','confirmed'].includes(path);
  assert.equal(r.status,read?200:409);
  assert.deepEqual(await r.json(),read?{schedules:[],executor:'cloud'}:{claimed:0,updated:0,error:'moved_to_cloud'});
 }
});
test('general default accepts meetings, activities and deadlines without course metadata or course binding mutation',async()=>{
 const j={token:'general-test',timezone:'America/Chicago'};
 const meeting=source({kind:'meeting',title:'团队会议',description:'https://example.test/meeting'});
 const deadline=source({kind:'deadline',title:'报名截止',end:null});
 const activity=source({kind:'activity',title:'音乐节',all_day:true,start:'2026-11-20',end:null});
 const p=await normalizeCourse(raw([meeting,meeting,deadline,activity,source({action:'cancel'})]),j,[{course_key:'unrelated',status:'active',source_json:'{}'}]);
 assert.equal(p.mode,'general');assert.equal(p.events.length,3);assert.ok(p.events.every(e=>e.action==='create'));
 assert.equal(p.events[0].description,'https://example.test/meeting');assert.equal(p.events[1].milestone,'due');assert.match(p.events[1].issue,/完整/);
 assert.equal(p.events[2].end,'2026-11-21T00:00');assert.ok(p.warnings.some(x=>x.includes('取消通知')));
 assert.equal((await normalizeCourse(raw([meeting]),j)).events[0].item_key,p.events[0].item_key);
 assert.notEqual((await normalizeCourse(raw([meeting]),{...j,token:'another'})).events[0].item_key,p.events[0].item_key);
 let body;await extractCourse(env(),j,[],async(u,o)=>{body=JSON.parse(o.body);return Response.json({status:'completed',output:[{content:[{type:'output_text',text:JSON.stringify(raw())}]}]});});
 assert.match(body.instructions,/通用日程/);assert.match(body.instructions,/不要求课程号/);
 const page=await(await cloudSchedulePage(env(),{token:'test',status:'cloud_preview',preview_json:JSON.stringify(p)})).text();assert.match(page,/通用提取/);assert.match(page,/预览并编辑日程/);
});
async function insertJob(e,status='cloud_pending',preview=null,selected=null){await e.DB.prepare(`INSERT INTO schedule_uploads(token,access_token,filename,content_type,size_bytes,timezone,status,created_at,expires_at,preview_json,selected_json,object_key,course_hint,term_hint) VALUES(?1,'access','schedule.pdf','application/pdf',20,'America/Chicago',?2,?3,'2099',?4,?5,'bundle:test','ESE 5700','Fall 2026')`).bind(token,status,new Date().toISOString(),preview?JSON.stringify(preview):null,selected?JSON.stringify(selected):null).run();}
function provider({conflict=false,timeout=false}={}){let remote=null,writes=0;return {get writes(){return writes;},get remote(){return remote;},set remote(v){remote=v;},deps:{access:async()=>({access:'test',connection:{email:CALENDAR_ACCOUNT,status:'ready',calendar_id:'target'}}),graph:async(t,p,o={})=>{if(p.endsWith('?$select=id,name,canEdit'))return {id:'target',name:'邮件助手',canEdit:true};if(o.method){writes++;if(timeout)throw Error('timeout');if(o.method==='DELETE'){remote=null;return {};}remote={...o.body,id:'event',attendees:[],recurrence:null,'@odata.etag':'etag'};return remote;}if(!remote){const error=Error('gone');error.httpStatus=404;throw error;}return conflict?{...remote,subject:'Manually edited'}:remote;}}};}
test('PDF and image request uses configured model, structured output and complete response only',async()=>{
 const e=env();let body;
 const fake=async(u,o)=>{body=JSON.parse(o.body);return Response.json({status:'completed',output:[{content:[{type:'output_text',text:JSON.stringify(raw())}]}]});};
 await extractCourse(e,job,[{filename:'x.pdf',content_type:'application/pdf',bytes:new Uint8Array([1,2]).buffer},{filename:'x.png',content_type:'image/png',bytes:new Uint8Array([1,2]).buffer}],fake);
 assert.equal(body.model,'configured-model');assert.equal(body.store,false);assert.match(body.input[0].content[0].file_data,/^data:application\/pdf;base64,/);assert.equal(body.input[0].content[1].type,'input_image');assert.match(body.instructions,/不可信/);
 await assert.rejects(extractCourse(e,job,[],async()=>Response.json({status:'incomplete'})),/未完整/);
});
test('stable legacy identities, assigned/due separation, explicit cancellation and no inferred deletion',async()=>{
 assert.equal(await courseKey('ESE 5700','','Fall 2026'),await courseKey('ese5700','','Fall 2026'));
 assert.notEqual(await itemKey('c','homework','HW01','assigned'),await itemKey('c','homework','HW01','due'));
 const p=await normalizeCourse(raw(),job);const e=p.events[0];const binding={item_key:e.item_key,course_key:p.course_key,event_id:'old',status:'active',source_json:JSON.stringify(e),snapshot_json:JSON.stringify(coursePayload(e))};
 assert.equal((await normalizeCourse(raw(),job,[binding])).events[0].action,'existing');
 assert.equal((await normalizeCourse(raw([source({start:'2026-11-11T10:00',end:'2026-11-11T12:00'})]),job,[binding])).events[0].action,'update');
 assert.equal((await normalizeCourse(raw([]),job,[binding])).events[0].action,'possible_cancel');
 assert.equal((await normalizeCourse(raw([source({action:'cancel'})]),job,[binding])).events[0].action,'cancel');
 assert.equal((await normalizeCourse(raw([source({action:'cancel'})]),job,[])).events.length,0);
});
test('missing end is editable, all-day gets exclusive end, DST invalid rejected',async()=>{
 const p=await normalizeCourse(raw([source({end:null})]),job);assert.match(p.events[0].issue,/完整/);
 const day=(await normalizeCourse(raw([source({all_day:true,start:'2026-11-10',end:null})]),job)).events[0];assert.equal(day.end,'2026-11-11T00:00');assert.equal(coursePayload(day).isReminderOn,false);
 assert.throws(()=>coursePayload({...day,all_day:false,start:'2026-03-08T02:30',end:'2026-03-08T04:00'}),/夏令时/);
 await assert.rejects(normalizeCourse(raw([source(),source()]),job),/重复/);
});
test('cloud extraction advances preview and deletes uploaded bytes; Mac endpoints cannot claim',async()=>{
 const e=env();await ensureCloudSchedules(e);await insertJob(e);
 await e.DB.prepare("INSERT INTO schedule_files(job_token,file_index,filename,content_type,size_bytes) VALUES(?1,0,'x.pdf','application/pdf',2)").bind(token).run();
 await e.DB.prepare('INSERT INTO schedule_file_parts VALUES(?1,0,0,?2)').bind(token,new Uint8Array([1,2]).buffer).run();
 let calls=0;await runSchedule(e,token,{extract:async()=>{calls++;return raw();}});await runSchedule(e,token,{extract:async()=>{calls++;return raw();}});
 assert.equal(calls,1);assert.equal((await e.DB.prepare('SELECT status FROM schedule_uploads').first()).status,'cloud_preview');assert.equal((await e.DB.prepare('SELECT count(*) n FROM schedule_files').first()).n,0);
 for(const path of ['pull','confirmed','claim','apply-claim','result','complete']){const url=new URL('https://example.test/api/schedules/'+path);const r=await handleScheduleRoute(new Request(url),e,url,true);const b=await r.json();if(['pull','confirmed'].includes(path))assert.deepEqual(b.schedules,[]);else assert.equal(b.claimed,0);}
});
test('preview edits are signed, selected-only, escaped and cannot force unknown deletion',async()=>{
 const e=env();await ensureCloudSchedules(e);const p=await normalizeCourse(raw(),job);await insertJob(e,'cloud_preview',p);const row=await e.DB.prepare('SELECT * FROM schedule_uploads').first();const page=await (await cloudSchedulePage(e,row)).text();
 const form=new URLSearchParams({expires:page.match(/name="expires" value="([^"]+)"/)[1],proof:page.match(/name="proof" value="([^"]+)"/)[1],confirm:'yes',item:'0'});
 const item=p.events[0];for(const k of ['title','start','end','timezone','location','description'])form.set('0_'+k,item[k]);form.set('0_title','修改后的标题');
 assert.doesNotMatch(page,/<input[^>]*name="confirm"/);
 assert.match(page,/<button[^>]*name="confirm"[^>]*>确认加入 Outlook<\/button>/);
 const url='https://example.test/schedule/'+token+'/confirm';
 assert.equal((await confirmCloudSchedule(new Request(url,{method:'POST',headers:{origin:'https://evil.test'},body:form}),e,token,row)).status,403);
 const good=await confirmCloudSchedule(new Request(url,{method:'POST',headers:{origin:'https://example.test'},body:form}),e,token,row);assert.equal(good.status,303);
 const stored=await e.DB.prepare('SELECT * FROM schedule_uploads').first();assert.equal(JSON.parse(stored.selected_json)[0].title,'修改后的标题');assert.equal((await confirmCloudSchedule(new Request(url,{method:'POST',body:form}),e,token,stored)).status,409);
});
test('native no-referrer POST accepts null origin only with valid preview proof and explicit confirmation',async()=>{
 for(const variant of ['null','missing','same','foreign','cross-site','bad-proof','expired','unconfirmed','wrong-preview']){
  const e=env();await ensureCloudSchedules(e);const p=await normalizeCourse(raw(),job);await insertJob(e,'cloud_preview',p);
  const row=await e.DB.prepare('SELECT * FROM schedule_uploads').first();
  const response=await cloudSchedulePage(e,row),page=await response.text();assert.equal(response.headers.get('referrer-policy'),'no-referrer');
  const f=new URLSearchParams({expires:page.match(/name="expires" value="([^"]+)"/)[1],proof:page.match(/name="proof" value="([^"]+)"/)[1],confirm:'yes',item:'0'});
  for(const k of ['title','start','end','timezone','location','description'])f.set('0_'+k,p.events[0][k]);
  const headers={origin:'null','sec-fetch-site':'same-origin'};
  if(variant==='missing')delete headers.origin;
  if(variant==='same')headers.origin='https://example.test';
  if(variant==='foreign')headers.origin='https://evil.test';
  if(variant==='cross-site')headers['sec-fetch-site']='cross-site';
  if(variant==='bad-proof')f.set('proof','bad');
  if(variant==='expired')f.set('expires','1000000000');
  if(variant==='unconfirmed')f.delete('confirm');
  if(variant==='wrong-preview')row.preview_json=JSON.stringify({...p,warnings:['changed']});
  const r=await confirmCloudSchedule(new Request('https://example.test/schedule/'+token+'/confirm',{method:'POST',headers,body:f}),e,token,row);
  const success=['null','missing','same'].includes(variant);
  assert.equal(r.status,success?303:403,variant);
  assert.equal((await e.DB.prepare('SELECT status FROM schedule_uploads').first()).status,success?'cloud_confirmed':'cloud_preview');
  if(!success){const text=await r.text();assert.match(text,/本次提交没有写入日历/);assert.match(text,new RegExp('/schedule/'+token));}
  else {const providerMock=provider();await runSchedule(e,token,{apply:(env,t,item)=>applyCourseItem(env,t,item,providerMock.deps)});assert.equal(providerMock.writes,1);await runSchedule(e,token,{apply:(env,t,item)=>applyCourseItem(env,t,item,providerMock.deps)});assert.equal(providerMock.writes,1);}
 }
});
test('processing pages do not advise leaving the page',async()=>{
 for(const status of ['cloud_pending','cloud_processing','cloud_confirmed','cloud_applying']){
  const page=await(await cloudSchedulePage({}, {token,filename:'test.pdf',status})).text();
  assert.doesNotMatch(page,/可以离开|云端会继续处理/);
  assert.match(page,/正在云端提取日程|正在同步 Outlook 日历/);
 }
});
test('create is idempotent and silent, replay/unknown never re-POST',async()=>{
 for(const timeout of [false,true]){const e=env();await ensureCloudSchedules(e);const item=(await normalizeCourse(raw(),job)).events[0],p=provider({timeout});await applyCourseItem(e,token,item,p.deps);await applyCourseItem(e,token,item,p.deps);assert.equal(p.writes,1);const op=await e.DB.prepare('SELECT * FROM cloud_course_operations').first();assert.equal(op.status,timeout?'uncertain':'completed');const b=await e.DB.prepare('SELECT * FROM cloud_course_bindings').first();assert.equal(Boolean(b.lock_id),timeout);}
});
test('owned updates/cancels verify baseline and reject manual changes, no attendee invites',async()=>{
 const e=env();await ensureCloudSchedules(e);const item=(await normalizeCourse(raw(),job)).events[0],p=provider();await applyCourseItem(e,token,item,p.deps);
 let b=await e.DB.prepare('SELECT * FROM cloud_course_bindings').first();const updated={...item,action:'update',event_id:b.event_id,base:b.snapshot_json,title:'新标题'};
 await applyCourseItem(e,'b'.repeat(32),updated,p.deps);assert.equal(p.remote.subject,'新标题');assert.equal(p.remote.attendees.length,0);assert.equal(p.remote.isReminderOn,false);
 b=await e.DB.prepare('SELECT * FROM cloud_course_bindings').first();p.remote={...p.remote,subject:'手动标题'};
 await applyCourseItem(e,'c'.repeat(32),{...updated,action:'cancel',base:b.snapshot_json},p.deps);assert.equal(p.writes,2);
 p.remote={...p.remote,subject:'新标题'};await applyCourseItem(e,'d'.repeat(32),{...updated,action:'cancel',base:b.snapshot_json},p.deps);assert.equal(p.writes,3);assert.equal((await e.DB.prepare('SELECT status FROM cloud_course_bindings').first()).status,'deleted');
});
test('fingerprint compares Graph UTC and local payload equivalently',()=>{
 const p=coursePayload({...source(),start:'2026-11-10T10:00',end:'2026-11-10T12:00'});const live={...p,start:{dateTime:'2026-11-10T16:00:00.0000000',timeZone:'UTC'},end:{dateTime:'2026-11-10T18:00:00.0000000',timeZone:'UTC'}};assert.equal(fingerprint(p),fingerprint(live));
});
test('bounded queue applies confirmed selection only, survives redelivery and completes without pushes',async()=>{
 const e=env();await ensureCloudSchedules(e);const p=await normalizeCourse(raw([source(),source({item_id:'Exam2',title:'Exam2'})]),job);
 await insertJob(e,'cloud_confirmed',p,p.events);let writes=0,queued=0;e.ACTION_QUEUE.send=async()=>{queued++;};
 const apply=async(env,token,item)=>{writes++;await env.DB.prepare("INSERT INTO cloud_course_operations(id,job_token,item_key,action,status,created_at) VALUES(?1,?2,?3,'create','completed','now')").bind(item.item_key,token,item.item_key).run();};
 await runSchedule(e,token,{apply});assert.equal(writes,1);assert.equal(queued,1);
 await runSchedule(e,token,{apply});await runSchedule(e,token,{apply});assert.equal(writes,2);
 const row=await e.DB.prepare('SELECT * FROM schedule_uploads').first();assert.equal(row.status,'cloud_completed');assert.equal(JSON.parse(row.result_json).created,2);
});
test('historical binding adoption is exact and never overwrites subsequent cloud ownership',async()=>{
 const e=env();await ensureCloudSchedules(e);const item=(await normalizeCourse(raw(),job)).events[0];
 await e.DB.prepare("INSERT INTO calendar_course_migrations(source_key,source_uid,course_key,item_key,legacy_payload_json,payload_json,calendar_id,transaction_id,event_id,status,created_at,verified_at) VALUES('source','uid',?1,?2,?3,?4,'target','transaction','migrated','verified','now','now')").bind(item.course_key,item.item_key,JSON.stringify(item),JSON.stringify(coursePayload(item))).run();
 await ensureCloudSchedules(e);assert.equal((await e.DB.prepare('SELECT event_id FROM cloud_course_bindings').first()).event_id,'migrated');
 await e.DB.prepare("UPDATE cloud_course_bindings SET status='deleted'").run();await ensureCloudSchedules(e);assert.equal((await e.DB.prepare('SELECT status FROM cloud_course_bindings').first()).status,'deleted');
});
