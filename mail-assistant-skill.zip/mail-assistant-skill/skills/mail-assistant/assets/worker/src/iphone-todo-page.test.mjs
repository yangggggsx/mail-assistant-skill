import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {iphoneTodoPage,todoLaunchScript,todoStatusScript} from './iphone-todo-page.js';
function browser({hidden=false,device=true,blocked=false}={}) {
 const events={},timers=[],navigations=[];
 const nodes={launch:blocked?null:{href:'shortcuts://run-shortcut?name=test',addEventListener:(n,f)=>events['link:'+n]=f},status:{},fallback:{hidden:false}};
 const context={navigator:{userAgent:device?'iPhone':'Android',maxTouchPoints:0},document:{hidden,getElementById:id=>nodes[id],addEventListener:(n,f)=>events[n]=f},window:{addEventListener:(n,f)=>events[n]=f},location:{set href(value){navigations.push(value);}},setTimeout:f=>{timers.push(f);return 1;},clearTimeout:()=>{}};
 vm.runInNewContext(todoLaunchScript,context);
 return {context,nodes,events,timers,navigations};
}
test('visible phone automatically launches once; return never launches or claims again',()=>{
 const b=browser();assert.equal(b.navigations.length,1);assert.equal(b.nodes.fallback.hidden,true);
 b.context.document.hidden=true;b.events.visibilitychange();
 b.context.document.hidden=false;b.events.visibilitychange();
 assert.equal(b.navigations.length,1);assert.equal(b.nodes.fallback.hidden,false);
 assert.doesNotMatch(todoLaunchScript,/fetch\(|requestSubmit/);
});

test('status refresh only reports success after a receipt, handles return and failures without relaunch',async()=>{
 const events={},timers=[],nodes={status:{textContent:''},fallback:{hidden:false}};
 let value='iphone_claimed',calls=0,fail=false;
 const context={document:{hidden:false,getElementById:id=>nodes[id],addEventListener:(n,f)=>events[n]=f},window:{addEventListener:(n,f)=>events[n]=f},location:{pathname:'/f/token/iphone-todo'},AbortSignal,setTimeout:f=>{timers.push(f);return 1},clearTimeout:()=>{},fetch:async url=>{calls++;assert.equal(url,'/f/token/iphone-todo/status');if(fail)throw Error('offline');return Response.json({status:value})}};
 vm.runInNewContext(todoStatusScript,context);
 const flush=()=>new Promise(resolve=>setImmediate(resolve));await flush();
 assert.match(nodes.status.textContent,/等待快捷指令/);assert.equal(nodes.fallback.hidden,true);
 value='completed';events.pageshow();await flush();assert.match(nodes.status.textContent,/✓ 已添加/);
 assert.equal(nodes.fallback.hidden,true);
 fail=true;events.focus();await flush();assert.match(nodes.status.textContent,/无法核对/);
 const before=calls;context.document.hidden=true;events.visibilitychange();await flush();assert.equal(calls,before);
 assert.doesNotMatch(todoStatusScript,/method:\s*['"]POST|location.href\s*=/);
});
test('hidden preview, other devices and owned tasks never auto-launch',()=>{
 for(const opts of [{hidden:true},{device:false},{blocked:true}])assert.equal(browser(opts).navigations.length,0);
 const b=browser({hidden:true});b.context.document.hidden=false;b.events.visibilitychange();assert.equal(b.navigations.length,1);
 const c=browser();c.timers[0]();assert.equal(c.nodes.fallback.hidden,false);
});
test('page uses nonce CSP, escaped launcher and no launcher for already owned tasks',async()=>{
 const page=iphoneTodoPage('shortcuts://run-shortcut?name=test&input=text',null);
 assert.match(page.headers.get('content-security-policy'),/script-src 'nonce-/);
 assert.match(await page.text(),/name=test&amp;input=text/);
 for(const status of ['pending','completed','iphone_claimed','failed']) {
   const html=await iphoneTodoPage('shortcuts://test',{status}).text();
   assert.doesNotMatch(html,/id="launch"/);
 }
});
