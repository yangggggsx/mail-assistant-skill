// Durable, single-owner delivery. Provider acknowledgement is not device receipt.
const json=(v,s=200)=>new Response(JSON.stringify(v),{status:s,headers:{'content-type':'application/json','cache-control':'no-store'}});
export async function ensureDelivery(env) {
  await env.DB.batch([
    env.DB.prepare(`CREATE TABLE IF NOT EXISTS delivery_queue (
      delivery_key TEXT PRIMARY KEY,payload_json TEXT NOT NULL,status TEXT NOT NULL,
      attempts INTEGER NOT NULL DEFAULT 0,next_at TEXT NOT NULL,lease_until TEXT,
      claim_token TEXT,accepted_at TEXT,error_code TEXT,created_at TEXT NOT NULL)`),
    env.DB.prepare('CREATE INDEX IF NOT EXISTS delivery_due ON delivery_queue(status,next_at)'),
    env.DB.prepare(`CREATE TABLE IF NOT EXISTS delivery_handoff (
      id INTEGER PRIMARY KEY CHECK(id=1),owner TEXT NOT NULL CHECK(owner IN ('mac','cloud')),changed_at TEXT NOT NULL)`),
    env.DB.prepare("INSERT OR IGNORE INTO delivery_handoff VALUES(1,'mac',datetime('now'))"),
  ]);
}
export function validatePayload(p,origin) {
  if(!p || typeof p.title!=='string' || !p.title || p.title.length>250 || typeof p.message!=='string' || !p.message || p.message.length>1024) throw new Error('invalid_payload');
  if(![-2,-1,0,1].includes(p.priority) || ![undefined,false,true].includes(p.html)) throw new Error('invalid_payload');
  if(p.url) { const u=new URL(p.url); if(u.origin!==origin || !/^\/(f|d)\/[A-Za-z0-9_-]{32}(\/translate)?$/.test(u.pathname) || u.search || u.hash) throw new Error('invalid_url'); }
  return {title:p.title,message:p.message,priority:p.priority,html:p.html===true,...(p.url?{url:p.url,url_title:String(p.url_title || '查看邮件').slice(0,100)}:{})};
}
export function outcome(status,body) {
  if(status===200 && body?.status===1) return 'accepted';
  if(status===429 || (status>=500 && body?.status===0)) return 'retry';
  if(status>=400 && status<500) return 'blocked';
  return 'uncertain';
}
export function retrySeconds(attempts,retryAfter=0) {
  return Math.max(Math.min(21600,Math.max(0,retryAfter)),Math.min(3600,60*2**Math.min(attempts,6)));
}
export async function enqueueDelivery(env,key,payload,now=new Date().toISOString()) {
  const inserted=await env.DB.prepare("INSERT OR IGNORE INTO delivery_queue(delivery_key,payload_json,status,next_at,created_at) VALUES(?1,?2,'pending',?3,?3)")
    .bind(key,JSON.stringify(payload),now).run();
  const row=await env.DB.prepare('SELECT status,accepted_at,attempts,error_code FROM delivery_queue WHERE delivery_key=?1').bind(key).first();
  return {...row,duplicate:!inserted.meta?.changes};
}
export async function drainDelivery(env,{testOnly=false,fetcher=fetch}={}) {
  await ensureDelivery(env);
  const owner=await env.DB.prepare('SELECT owner FROM delivery_handoff WHERE id=1').first();
  const now=new Date().toISOString();
  // User disabled iPhone todo success notifications; cancel unsent older receipts,
  // retaining keys for deduplication. Never rewrite already accepted/sending rows.
  await env.DB.prepare("UPDATE delivery_queue SET status='cancelled',error_code='success_push_disabled' WHERE delivery_key LIKE 'todo-iphone:%' AND status IN ('pending','retry')").run();
  // Keep delivery keys for dedupe, but discard old delivered notification text.
  await env.DB.prepare("UPDATE delivery_queue SET payload_json='{}' WHERE status='accepted' AND accepted_at<?1 AND payload_json<>'{}'")
    .bind(new Date(Date.now()-7*86400000).toISOString()).run();
  // A crashed POST could have succeeded: stale leases require reconciliation, not resend.
  await env.DB.prepare("UPDATE delivery_queue SET status='uncertain',error_code='lease_expired' WHERE status='sending' AND lease_until<?1").bind(now).run();
  if(!env.PUSHOVER_API_TOKEN || !env.PUSHOVER_USER_KEY) return {configured:false};
  const rows=await env.DB.prepare(`SELECT * FROM delivery_queue WHERE status IN ('pending','retry') AND next_at<=?1
    AND (?2=1 OR delivery_key LIKE 'test:%') ORDER BY created_at LIMIT 10`).bind(now,!testOnly && owner.owner==='cloud'?1:0).all();
  let accepted=0;
  for(const row of rows.results || []) {
    const claim=crypto.randomUUID();
    const lease=new Date(Date.now()+120000).toISOString();
    const lock=await env.DB.prepare("UPDATE delivery_queue SET status='sending',claim_token=?1,lease_until=?2,attempts=attempts+1 WHERE delivery_key=?3 AND status IN ('pending','retry') AND next_at<=?4")
      .bind(claim,lease,row.delivery_key,now).run();
    if(!lock.meta?.changes) continue;
    let state='uncertain',retryAfter=0,code='network_or_timeout';
    try {
      const p=JSON.parse(row.payload_json);
      const fields={token:env.PUSHOVER_API_TOKEN,user:env.PUSHOVER_USER_KEY,title:p.title,message:p.message,priority:String(p.priority)};
      if(p.html) fields.html='1';
      if(p.url) {fields.url=p.url;fields.url_title=p.url_title;}
      const response=await fetcher('https://api.pushover.net/1/messages.json',{method:'POST',body:new URLSearchParams(fields),signal:AbortSignal.timeout(20000)});
      const result=await response.json().catch(()=>null);
      state=outcome(response.status,result);code=`http_${response.status}`;
      retryAfter=Number(response.headers.get('retry-after')) || 0;
    } catch {}
    const attempts=row.attempts+1;
    if(state==='retry' && attempts>=12) state='blocked';
    const next=new Date(Date.now()+retrySeconds(attempts,retryAfter)*1000).toISOString();
    await env.DB.prepare(`UPDATE delivery_queue SET status=?1,next_at=?2,lease_until=NULL,claim_token=NULL,
      accepted_at=?3,error_code=?4 WHERE delivery_key=?5 AND claim_token=?6`)
      .bind(state,next,state==='accepted'?new Date().toISOString():null,state==='accepted'?null:code,row.delivery_key,claim).run();
    accepted+=Number(state==='accepted');
  }
  return {accepted};
}
export async function handleDelivery(request,env,url,authorized) {
  if(!url.pathname.startsWith('/api/delivery/')) return null;
  if(!authorized) return json({error:'unauthorized'},401);
  await ensureDelivery(env);
  if(request.method==='GET' && url.pathname==='/api/delivery/status') {
    const owner=await env.DB.prepare('SELECT * FROM delivery_handoff WHERE id=1').first();
    const counts=await env.DB.prepare('SELECT status,COUNT(*) AS count FROM delivery_queue GROUP BY status').all();
    return json({owner:owner.owner,counts:counts.results || []});
  }
  if(request.method!=='POST') return json({error:'method'},405);
  let b;try { const text=await request.text(); if(text.length>20000) return json({error:'too_large'},413);b=JSON.parse(text); } catch {return json({error:'json'},400);}
  if(url.pathname==='/api/delivery/enqueue') {
    const owner=await env.DB.prepare('SELECT owner FROM delivery_handoff WHERE id=1').first();
    if(owner.owner!=='cloud') return json({error:'handoff_required'},409);
    if(!/^(mail|digest):[a-f0-9]{64}$/.test(b.key || '')) return json({error:'key'},400);
    let p;try{p=validatePayload(b.payload,url.origin);}catch{return json({error:'payload'},400);}
    return json(await enqueueDelivery(env,b.key,p));
  }
  if(url.pathname==='/api/delivery/test') {
    if(!/^[a-z0-9-]{8,64}$/.test(b.test_id || '')) return json({error:'test_id'},400);
    const result=await enqueueDelivery(env,`test:${b.test_id}`,{title:'【云端队列测试】邮件助手',message:'这条通知经过持久化发送队列。重复提交同一测试编号不会再次推送。正式邮件发送权尚未交接。',priority:0,html:false});
    await drainDelivery(env,{testOnly:true});
    return json({...result,...await env.DB.prepare('SELECT status,attempts,accepted_at FROM delivery_queue WHERE delivery_key=?1').bind(`test:${b.test_id}`).first()});
  }
  // Two-phase handoff: caller must quiesce the Mac sender and seed receipts first.
  // No automatic fallback to Mac: uncertain deliveries could otherwise duplicate.
  if(url.pathname==='/api/delivery/handoff') {
    if(b.confirm_mac_sender_stopped!==true || b.owner!=='cloud') return json({error:'confirmation_required'},400);
    await env.DB.prepare("UPDATE delivery_handoff SET owner='cloud',changed_at=?1 WHERE id=1 AND owner='mac'").bind(new Date().toISOString()).run();
    return json({owner:'cloud'});
  }
  if(url.pathname==='/api/delivery/seed-receipts') {
    const owner=await env.DB.prepare('SELECT owner FROM delivery_handoff WHERE id=1').first();
    if(owner.owner!=='mac') return json({error:'already_handed_off'},409);
    if(!Array.isArray(b.keys) || b.keys.length>100 || b.keys.some(k=>!/^mail:[a-f0-9]{64}$/.test(k))) return json({error:'keys'},400);
    if(b.keys.length) await env.DB.batch(b.keys.map(k=>env.DB.prepare("INSERT OR IGNORE INTO delivery_queue(delivery_key,payload_json,status,next_at,accepted_at,created_at) VALUES(?1,'{}','accepted',?2,?2,?2)").bind(k,new Date().toISOString())));
    return json({seeded:b.keys.length});
  }
  return json({error:'not_found'},404);
}
