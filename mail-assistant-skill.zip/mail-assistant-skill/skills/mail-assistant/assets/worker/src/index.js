import {
  cloudAccountStatus,
  cloudJson,
  handleGoogleCallback,
  handleMicrosoftCallback,
  startGoogleOAuth,
  startMicrosoftOAuth,
  syncAllCloudMail,
} from "./cloud-mail.js";
import { cleanupScheduleRetention, handleScheduleRoute } from "./schedules.js";
import {runSchedule,recoverSchedules} from './cloud-schedules.js';
import { handleMailTools, cleanupMailTools } from "./mail-tools.js";
import { handleCloudMigration } from "./cloud-migration.js";
import { handleDelivery, drainDelivery } from "./delivery-queue.js";
import { handlePipeline, runCloudPipeline, ensurePipeline, collectLocalDigest } from "./cloud-pipeline.js";
import { safeOriginalUrl } from "./cloud-content.js";
import {cloudMessage,drainCloudActions,enqueueCloudAction} from './cloud-actions.js';
import {handleRealtime,consumeRealtime,maintainRealtime} from './realtime.js';
import {originalMailPage} from './original-mail.js';
import {translationWaitScript} from './translation-wait.js';
import {handleCalendarAuth} from './outlook-calendar-auth.js';
import {handleOutlookCalendar,ensureCalendarOwnership} from './outlook-calendar.js';
import {ensureCalendar} from './outlook-calendar-auth.js';
import {handleCourseMigration} from './calendar-migration.js';
import {translationMarkup,translationParagraphs} from './translation-links.js';
import {ensureFeedbackFields,feedbackCategories,feedbackImportance,feedbackDefaults,compatibilityLabel} from './feedback-fields.js';

const LABELS = new Set(["urgent", "important", "normal", "newsletter", "spam", "calendar"]);
const DAY_MS = 24 * 60 * 60 * 1000;
const FEEDBACK_ACTION_DAYS = 30;
const TRANSLATION_RETENTION_DAYS = 7;
const CLOUD_SNIPPET_RETENTION_DAYS = 7;
const CLOUD_OBSERVATION_RETENTION_DAYS = 30;

function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      "content-type": "application/json; charset=utf-8",
      "cache-control": "no-store",
      "x-content-type-options": "nosniff",
    },
  });
}

function html(body, status = 200, refresh = false) {
  const nonce=crypto.randomUUID();
  return new Response(`<!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="color-scheme" content="light dark"><title>邮件助手反馈</title>
<style>
body{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;margin:0;background:#f4f5f7;color:#171717}
main{max-width:480px;margin:0 auto;padding:32px 20px}.card{background:#fff;border-radius:22px;padding:24px;box-shadow:0 10px 35px #0001}
h1{font-size:25px;margin:0 0 8px}h2{font-size:18px;margin:0 0 7px}p{color:#666;line-height:1.5;margin:0 0 22px}.grid{display:grid;grid-template-columns:1fr 1fr;gap:12px}
button{width:100%;min-height:52px;border:0;border-radius:14px;background:#eef0f4;color:#111;font-size:17px;font-weight:650}
button:active{transform:scale(.98);background:#dfe3e9}.privacy{font-size:12px;margin-top:20px;color:#888}
textarea{box-sizing:border-box;width:100%;min-height:84px;margin:0 0 14px;padding:12px;border:1px solid #d8dbe2;border-radius:12px;font:15px inherit;resize:vertical}
label{display:block;margin:18px 0 8px;font-weight:600}select{box-sizing:border-box;width:100%;padding:13px;border:1px solid #d8dbe2;border-radius:12px;font:inherit;color:inherit;background:transparent}.save-feedback{background:#1877f2;color:#fff}
.mail{padding:18px 0;border-top:1px solid #e6e7eb}.mail:first-of-type{border-top:0}.meta{font-size:13px;color:#777;margin-bottom:8px}.summary{margin-bottom:14px}
.translation-text{white-space:pre-wrap;overflow-wrap:anywhere;color:#666;line-height:1.6;margin:0 0 22px}
.translation-paragraph{margin-bottom:16px;overflow-anchor:none}.translation-text a{color:#1877f2;text-decoration:underline}
#translation-state{min-height:3em}
.actions{display:flex;gap:9px;flex-wrap:wrap}.action,.actions button{box-sizing:border-box;display:inline-flex;align-items:center;justify-content:center;width:auto;min-height:42px;padding:0 13px;border:0;border-radius:11px;background:#eef0f4;color:#111;text-decoration:none;font-size:14px;font-weight:650}.actions form{margin:0}.action.primary{background:#1877f2;color:#fff}
@media(prefers-color-scheme:dark){body{background:#111;color:#f5f5f5}.card{background:#202124}.grid button,.action,.actions button{background:#303238;color:#fff}p,.translation-text{color:#bbb}.mail{border-color:#383a40}}
</style></head><body><main><div class="card">${body}</div></main>${refresh?`<script nonce="${nonce}">${translationWaitScript}</script>`:''}</body></html>`, {
    status,
    headers: {
      "content-type": "text/html; charset=utf-8",
      "cache-control": "no-store",
      "content-security-policy": `default-src 'none'; style-src 'unsafe-inline'; ${refresh?`script-src 'nonce-${nonce}'; connect-src 'self';`:''} form-action 'self'; base-uri 'none'; frame-ancestors 'none'`,
      "referrer-policy": "no-referrer",
      "x-content-type-options": "nosniff",
      "x-frame-options": "DENY",
    },
  });
}

function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>"']/g, (character) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;",
  })[character]);
}

function validMailUrl(value) {
  const url = String(value || "").trim();
  return url.startsWith("message://") && url.length <= 1024 ? url : safeOriginalUrl(url);
}

export function renderTranslationBlock(translation) {
  if (translation?.status === "completed") {
    return `<div class="mail"><h2>中文翻译</h2><div class="translation-text">${translationMarkup(translation.translation_text || "暂无内容")}</div><p class="privacy">仅翻译可读正文，附件与图片未包含；长邮件最多处理 12000 字符。</p></div>`;
  }
  if (translation?.status === "pending") {
    return `<div class="mail"><h2>中文翻译</h2><p id="translation-state" role="status">${translation.cloud ? '正在准备全文，先看上方摘要；译文会逐段出现。' : '此旧邮件仍由 Mac 处理，在线时通常约两分钟。'}</p><div id="translation-partial" class="translation-text">${translationMarkup(translation.translation_text || '')}</div><div id="translation-error"></div><p class="privacy">仅翻译可读正文，附件与图片未包含；长邮件最多处理 12000 字符。无需刷新，不另发完成推送。</p></div>`;
  }
  if (translation?.status === "failed") {
    return `<div class="mail"><h2>翻译暂时失败</h2><p>${escapeHtml(translation.error || "请稍后重试")}</p></div>`;
  }
  return "";
}

export function originalMailRedirect(mailUrl) {
  const target = validMailUrl(mailUrl);
  if (!target) return null;
  return new Response(null, {
    status: 302,
    headers: {
      "location": target,
      "cache-control": "no-store",
      "referrer-policy": "no-referrer",
      "x-content-type-options": "nosniff",
    },
  });
}

async function ensureTranslationSchema(env) {
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS translations (
    token TEXT PRIMARY KEY,
    status TEXT NOT NULL,
    translation_text TEXT,
    error TEXT,
    requested_at TEXT NOT NULL,
    completed_at TEXT
  )`).run();
  await env.DB.prepare("CREATE INDEX IF NOT EXISTS idx_translations_pending ON translations(status,requested_at)").run();
}

function authorized(request, env) {
  const value = request.headers.get("authorization") || "";
  return Boolean(env.API_TOKEN) && value === `Bearer ${env.API_TOKEN}`;
}

function randomToken() {
  const bytes = new Uint8Array(24);
  crypto.getRandomValues(bytes);
  return btoa(String.fromCharCode(...bytes)).replaceAll("+", "-").replaceAll("/", "_").replaceAll("=", "");
}

export function feedbackActionActive(row, now = new Date()) {
  const createdAt = new Date(row?.created_at || 0);
  const viewExpiresAt = new Date(row?.expires_at || 0);
  return Number.isFinite(createdAt.getTime())
    && Number.isFinite(viewExpiresAt.getTime())
    && now <= viewExpiresAt
    && now.getTime() - createdAt.getTime() <= FEEDBACK_ACTION_DAYS * DAY_MS;
}

export function retentionCutoffs(now = new Date()) {
  const before = (days) => new Date(now.getTime() - days * DAY_MS).toISOString();
  return {
    now: now.toISOString(),
    translation: before(TRANSLATION_RETENTION_DAYS),
    snippet: before(CLOUD_SNIPPET_RETENTION_DAYS),
    observation: before(CLOUD_OBSERVATION_RETENTION_DAYS),
    acknowledgedNote: before(FEEDBACK_ACTION_DAYS),
    expiredLink: before(FEEDBACK_ACTION_DAYS),
    staleOauth: before(1),
  };
}

export async function cleanupRetention(env, now = new Date()) {
  await ensureTranslationSchema(env);
  await ensureFeedbackFields(env);
  const cutoff = retentionCutoffs(now);
  const results = await env.DB.batch([
    env.DB.prepare(`DELETE FROM translations WHERE
      (completed_at IS NOT NULL AND completed_at<?1) OR requested_at<?1`).bind(cutoff.translation),
    env.DB.prepare(`DELETE FROM feedback_links WHERE token IN (
      SELECT i.feedback_token FROM digest_items i JOIN digest_pages p ON p.token=i.digest_token
      WHERE p.expires_at<?1
    )`).bind(cutoff.now),
    env.DB.prepare(`DELETE FROM digest_items WHERE digest_token IN (
      SELECT token FROM digest_pages WHERE expires_at<?1
    )`).bind(cutoff.now),
    env.DB.prepare("DELETE FROM digest_pages WHERE expires_at<?1").bind(cutoff.now),
    env.DB.prepare(`UPDATE feedback_links SET note=NULL
      WHERE acknowledged_at IS NOT NULL AND acknowledged_at<?1`).bind(cutoff.acknowledgedNote),
    env.DB.prepare("DELETE FROM feedback_links WHERE expires_at<?1").bind(cutoff.expiredLink),
    env.DB.prepare('DELETE FROM feedback_dimensions WHERE NOT EXISTS(SELECT 1 FROM feedback_links f WHERE f.token=feedback_dimensions.token)'),
    env.DB.prepare("DELETE FROM oauth_states WHERE expires_at<?1").bind(cutoff.staleOauth),
    env.DB.prepare(`UPDATE cloud_mail_observations SET snippet=NULL
      WHERE snippet IS NOT NULL AND first_observed_at<?1`).bind(cutoff.snippet),
    env.DB.prepare("DELETE FROM cloud_mail_observations WHERE first_observed_at<?1").bind(cutoff.observation),
  ]);
  return { operations: results.length, cutoffs: cutoff };
}

async function createLink(request, env, url) {
  let body;
  try { body = await request.json(); } catch { return json({ error: "invalid_json" }, 400); }
  const messageKey = String(body.message_key || "").toLowerCase();
  if (!/^[0-9a-f]{64}$/.test(messageKey)) return json({ error: "invalid_message_key" }, 400);
  const mailUrl = validMailUrl(body.mail_url);

  const token = randomToken();
  const createdAt = new Date();
  const expiresAt = new Date(createdAt.getTime() + 365 * 24 * 60 * 60 * 1000);
  await env.DB.prepare(`INSERT INTO feedback_links
    (token,message_key,created_at,expires_at,mail_url) VALUES(?1,?2,?3,?4,?5)`)
    .bind(token, messageKey, createdAt.toISOString(), expiresAt.toISOString(), mailUrl || null).run();
  await env.DB.prepare("DELETE FROM feedback_links WHERE expires_at < ?1")
    .bind(new Date(createdAt.getTime() - 30 * 24 * 60 * 60 * 1000).toISOString()).run();
  return json({ url: `${url.origin}/f/${token}`, expires_at: expiresAt.toISOString() });
}

async function createDigest(request, env, url) {
  let body;
  try { body = await request.json(); } catch { return json({ error: "invalid_json" }, 400); }
  const rawItems = Array.isArray(body.items) ? body.items.slice(0, 40) : [];
  if (!rawItems.length) return json({ error: "empty_digest" }, 400);
  const items = [];
  for (const raw of rawItems) {
    const messageKey = String(raw.message_key || "").toLowerCase();
    const category = String(raw.category || "normal");
    if (!/^[0-9a-f]{64}$/.test(messageKey) || !LABELS.has(category) || category === "calendar") {
      return json({ error: "invalid_digest_item" }, 400);
    }
    items.push({
      messageKey,
      subject: String(raw.subject || "无标题邮件").slice(0, 300),
      sender: String(raw.sender || "未知发件人").slice(0, 300),
      category,
      summary: String(raw.summary || "").slice(0, 600),
      mailUrl: validMailUrl(raw.mail_url),
    });
  }
  if(body.collect_only===true) return json(await collectLocalDigest(env,items));
  const digestToken = randomToken();
  const createdAt = new Date();
  const expiresAt = new Date(createdAt.getTime() + 7 * 24 * 60 * 60 * 1000);
  const statements = [env.DB.prepare(
    "INSERT INTO digest_pages(token,created_at,expires_at) VALUES(?1,?2,?3)"
  ).bind(digestToken, createdAt.toISOString(), expiresAt.toISOString())];
  items.forEach((item, index) => {
    const feedbackToken = randomToken();
    statements.push(env.DB.prepare(`INSERT INTO feedback_links
      (token,message_key,created_at,expires_at,mail_url) VALUES(?1,?2,?3,?4,?5)`)
      .bind(feedbackToken, item.messageKey, createdAt.toISOString(), expiresAt.toISOString(), item.mailUrl || null));
    statements.push(env.DB.prepare(`INSERT INTO digest_items
      (digest_token,position,message_key,subject,sender,category,summary,mail_url,feedback_token)
      VALUES(?1,?2,?3,?4,?5,?6,?7,?8,?9)`)
      .bind(digestToken, index + 1, item.messageKey, item.subject, item.sender,
        item.category, item.summary, item.mailUrl || null, feedbackToken));
  });
  await env.DB.batch(statements);
  const staleBefore = new Date(createdAt.getTime() - 30 * 24 * 60 * 60 * 1000).toISOString();
  await env.DB.prepare(`DELETE FROM digest_items WHERE digest_token IN
    (SELECT token FROM digest_pages WHERE expires_at < ?1)`).bind(staleBefore).run();
  await env.DB.prepare("DELETE FROM digest_pages WHERE expires_at < ?1").bind(staleBefore).run();
  return json({ url: `${url.origin}/d/${digestToken}`, expires_at: expiresAt.toISOString() });
}

async function pullFeedback(env, url) {
  const requested = Math.min(100, Math.max(1, Number(url.searchParams.get("limit") || 50)));
  const result = await env.DB.prepare(`SELECT id,message_key,label,note,submitted_at
    FROM feedback_links WHERE label IS NOT NULL AND acknowledged_at IS NULL
    ORDER BY id LIMIT ?1`).bind(requested).all();
  return json({ feedback: result.results || [] });
}

async function acknowledge(request, env) {
  let body;
  try { body = await request.json(); } catch { return json({ error: "invalid_json" }, 400); }
  const ids = Array.isArray(body.ids) ? body.ids.map(Number).filter(Number.isInteger).slice(0, 100) : [];
  if (!ids.length) return json({ acknowledged: 0 });
  const now = new Date().toISOString();
  await env.DB.batch(ids.map((id) => env.DB.prepare(
    "UPDATE feedback_links SET acknowledged_at=?1 WHERE id=?2 AND acknowledged_at IS NULL"
  ).bind(now, id)));
  return json({ acknowledged: ids.length });
}

async function feedbackPage(env, token) {
  await ensureFeedbackFields(env);
  const row = await env.DB.prepare(`SELECT f.*,d.mail_category,d.importance FROM feedback_links f LEFT JOIN feedback_dimensions d ON d.token=f.token WHERE f.token=?1`).bind(token).first();
  if (!row) return html("<h1>链接无效</h1><p>这条反馈链接不存在。</p>", 404);
  const actionActive = feedbackActionActive(row);
  const hasCloud=await env.DB.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='cloud_messages'").first();
  const mail=hasCloud?await env.DB.prepare('SELECT subject,classification_json FROM cloud_messages WHERE message_key=?1').bind(row.message_key).first():null;
  let classification={};try{classification=JSON.parse(mail?.classification_json||'{}');}catch{}
  const current=feedbackDefaults(row,classification);
  const options=(entries,value)=>entries.map(([key,label])=>`<option value="${escapeHtml(key)}"${key===value?' selected':''}>${escapeHtml(label)}</option>`).join('');
  const feedbackForm = actionActive ? `<form method="post">
    <input type="hidden" name="format" value="2">
    <label for="mail-category">邮件类别</label><select id="mail-category" name="mail_category" required>${options(feedbackCategories.map(x=>[x,x]),current.category)}</select>
    <label for="importance">重要程度</label><select id="importance" name="importance" required>${options(Object.entries(feedbackImportance),current.importance)}</select>
    <label for="note">补充说明（可选）</label><textarea id="note" name="note" maxlength="500" placeholder="例如：这是验证成功通知，不需要单独推送。">${escapeHtml(row.note || "")}</textarea>
    <button class="save-feedback" type="submit">保存反馈</button></form>` : `<p>此链接的反馈期限已过，无法修改。</p>`;
  return html(`<h1>反馈 / 改分类</h1>${mail?.subject?`<p>${escapeHtml(mail.subject)}</p>`:''}<p>${row.submitted_at?'已保存你的反馈，可继续修改。':'已预选当前分类；也可以只补充说明后保存。'}</p>
    ${feedbackForm}
    <div class="privacy">类别和重要程度分别记录。反馈用于后续分类参考，不会自动删除或移动邮件、创建待办或修改日历，也不会重新推送这封邮件。云端邮件的补充说明会随反馈保存在云端。</div>`);
}

function translationPageBody(token, row, translation) {
  const openMail = row.mail_url
    ? `<a class="action primary" href="/f/${escapeHtml(token)}/original">打开原邮件</a>` : "";
  const feedback = `<a class="action" href="/f/${escapeHtml(token)}">反馈 / 改分类</a>`;
  let content = renderTranslationBlock(translation);
  if (!content) {
    content = "<h1>正在翻译</h1><p>本机将在约两分钟内处理。可以稍后重新打开本页查看译文。</p>";
  }
  const retry = translation?.status === "failed" && feedbackActionActive(row)
    ? `<form method="post" action="/f/${escapeHtml(token)}/translate"><button>重新翻译</button></form>` : "";
  const context=translation?.status==='pending' && translation.subject
    ? `<section class="mail"><h2>${escapeHtml(translation.subject)}</h2><p><strong>已有中文摘要 · 非全文翻译</strong></p><p>${escapeHtml(translation.summary || '这封邮件暂无中文摘要，完整译文正在准备中。')}</p></section>` : '';
  return `${context}${content}<div class="actions">${openMail}${feedback}${retry}</div>`;
}

async function openOriginalMail(env, token) {
  const row = await env.DB.prepare(
    "SELECT mail_url,message_key FROM feedback_links WHERE token=?1"
  ).bind(token).first();
  if (!row) return html("<h1>链接无效</h1><p>这条邮件链接不存在。</p>", 404);
  const mail = await env.DB.prepare('SELECT message_id,original_url FROM cloud_messages WHERE message_key=?1').bind(row.message_key).first();
  const page = originalMailPage(mail?.message_id, row.mail_url || mail?.original_url);
  if (!page) return html("<h1>无法打开原邮件</h1><p>这条记录没有可用的原邮件链接。</p>", 404);
  return page;
}

async function viewOrRequestTranslation(env, token) {
  await ensureTranslationSchema(env);
  const row = await env.DB.prepare(
    "SELECT message_key,created_at,expires_at,mail_url FROM feedback_links WHERE token=?1"
  ).bind(token).first();
  if (!row) return html("<h1>链接无效</h1><p>这条邮件链接不存在。</p>", 404);
  let translation = await env.DB.prepare(
    "SELECT status,translation_text,error FROM translations WHERE token=?1"
  ).bind(token).first();
  if (!translation) {
    if (!feedbackActionActive(row)) {
      return html("<h1>翻译请求已过期</h1><p>原邮件入口仍可继续使用。</p>", 410);
    }
    const now = new Date().toISOString();
    const inserted=await env.DB.prepare(`INSERT INTO translations(token,status,translation_text,error,requested_at,completed_at)
      VALUES(?1,'pending',NULL,NULL,?2,NULL) ON CONFLICT(token) DO NOTHING`).bind(token, now).run();
    translation = { status: "pending", translation_text: null, error: null };
    if(inserted.meta?.changes && await cloudMessage(env,row.message_key)) await enqueueCloudAction(env,'translate',token);
  }
  const mail=await cloudMessage(env,row.message_key);
  translation.cloud=Boolean(mail);
  if(mail && translation.status==='pending'){
    translation.subject=mail.subject || '无标题邮件';
    try{const c=JSON.parse(mail.classification_json || '{}');translation.summary=typeof c.summary==='string'?c.summary:'';}catch{translation.summary='';}
  }
  return html(translationPageBody(token, row, translation),200,translation.status==='pending');
}

async function translationStatus(env, token) {
  const row=await env.DB.prepare('SELECT message_key,created_at,expires_at,mail_url FROM feedback_links WHERE token=?1').bind(token).first();
  if(!row)return json({error:'not_found'},404);
  const translation=await env.DB.prepare('SELECT status,translation_text,error FROM translations WHERE token=?1').bind(token).first();
  if(!translation)return json({error:'not_found'},404);
  return json({status:translation.status,paragraphs:translationParagraphs(translation.translation_text),error:translation.status==='failed'?translation.error:null,...(['completed','failed'].includes(translation.status)?{html:translationPageBody(token,row,translation)}:translation.translation_text?{partial:translation.translation_text}:{})});
}

// Read-only bounded SSE. Reconnecting never starts another model request.
async function translationEvents(env,token){
  const first=await translationStatus(env,token);if(!first.ok)return first;
  const initial=await first.json();let cancelled=false;
  const encoder=new TextEncoder();
  const stream=new ReadableStream({async start(controller){
    let previous='';
    try{
      for(let i=0;i<20&&!cancelled;i++){
        const data=i===0?initial:await (await translationStatus(env,token)).json();
        const serialized=JSON.stringify(data);
        if(cancelled)break;
        if(serialized!==previous){controller.enqueue(encoder.encode('data: '+serialized+'\n\n'));previous=serialized;}
        if(data.status==='completed'||data.status==='failed'||data.error==='not_found')break;
        controller.enqueue(encoder.encode(': keepalive\n\n'));
        await new Promise(resolve=>setTimeout(resolve,1000));
      }
    }catch{if(!cancelled)controller.enqueue(encoder.encode('event: fallback\ndata: {}\n\n'));}
    finally{if(!cancelled)controller.close();}
  },cancel(){cancelled=true;}});
  return new Response(stream,{headers:{'content-type':'text/event-stream','cache-control':'no-store, no-transform','x-content-type-options':'nosniff'}});
}

async function requestTranslation(env, token) {
  await ensureTranslationSchema(env);
  const row = await env.DB.prepare(
    "SELECT message_key,created_at,expires_at,mail_url FROM feedback_links WHERE token=?1"
  ).bind(token).first();
  if (!row) return html("<h1>链接无效</h1><p>这条邮件链接不存在。</p>", 404);
  if (!feedbackActionActive(row)) return html("<h1>翻译请求已过期</h1><p>原邮件入口仍可继续使用。</p>", 410);
  const now = new Date().toISOString();
  const inserted=await env.DB.prepare(`INSERT INTO translations(token,status,translation_text,error,requested_at,completed_at)
    VALUES(?1,'pending',NULL,NULL,?2,NULL)
    ON CONFLICT(token) DO UPDATE SET status='pending',translation_text=NULL,error=NULL,requested_at=excluded.requested_at,completed_at=NULL WHERE translations.status='failed'`)
    .bind(token, now).run();
  if(inserted.meta?.changes && await cloudMessage(env,row.message_key)) await enqueueCloudAction(env,'translate',token);
  return viewOrRequestTranslation(env,token);
}

async function pullTranslations(env, url) {
  await ensureTranslationSchema(env);
  const requested = Math.min(20, Math.max(1, Number(url.searchParams.get("limit") || 10)));
  const result = await env.DB.prepare(`SELECT t.token,f.message_key,t.requested_at
    FROM translations t JOIN feedback_links f ON f.token=t.token
    WHERE t.status='pending' AND NOT EXISTS(SELECT 1 FROM cloud_messages m WHERE m.message_key=f.message_key) ORDER BY t.requested_at LIMIT ?1`).bind(requested).all();
  return json({ translations: (result.results || []).map((item) => ({
    ...item, feedback_url: `${url.origin}/f/${item.token}`,
  })) });
}

async function completeTranslation(request, env) {
  await ensureTranslationSchema(env);
  let body;
  try { body = await request.json(); } catch { return json({ error: "invalid_json" }, 400); }
  const token = String(body.token || "");
  const status = body.status === "completed" ? "completed" : "failed";
  if (!/^[A-Za-z0-9_-]{32}$/.test(token)) return json({ error: "invalid_token" }, 400);
  const text = String(body.translation_text || "").slice(0, 12000);
  const error = String(body.error || "").slice(0, 1000);
  const result = await env.DB.prepare(`UPDATE translations SET status=?1,translation_text=?2,error=?3,completed_at=?4
    WHERE token=?5 AND status='pending' AND NOT EXISTS(SELECT 1 FROM cloud_messages m JOIN feedback_links f ON f.message_key=m.message_key WHERE f.token=translations.token)`).bind(status, text || null, error || null, new Date().toISOString(), token).run();
  return json({ updated: result.meta?.changes || 0 });
}

async function digestPage(env, token) {
  const page = await env.DB.prepare("SELECT expires_at FROM digest_pages WHERE token=?1").bind(token).first();
  if (!page) return html("<h1>简报不存在</h1><p>链接无效或已经清理。</p>", 404);
  if (page.expires_at < new Date().toISOString()) return html("<h1>简报已过期</h1><p>简报链接有效期为 7 天。</p>", 410);
  const result = await env.DB.prepare(`SELECT position,subject,sender,category,summary,mail_url,feedback_token
    FROM digest_items WHERE digest_token=?1 ORDER BY position`).bind(token).all();
  const labels = { urgent: "紧急", important: "重要", normal: "普通", newsletter: "订阅", spam: "垃圾候选" };
  const items = (result.results || []).map((item) => {
    const openMail = item.mail_url
      ? `<a class="action primary" href="/f/${escapeHtml(item.feedback_token)}/original">打开原邮件</a>` : "";
    return `<section class="mail"><h2>${escapeHtml(item.subject)}</h2>
      <div class="meta">${escapeHtml(labels[item.category] || item.category)} · ${escapeHtml(item.sender)}</div>
      <p class="summary">${escapeHtml(item.summary)}</p><div class="actions">${openMail}
      <a class="action" href="/f/${escapeHtml(item.feedback_token)}">反馈 / 改分类</a>
      <a class="action" href="/f/${escapeHtml(item.feedback_token)}/copy">复制到 AI</a>
      <a class="action" href="/f/${escapeHtml(item.feedback_token)}/todo">加入待办</a>
      <form method="post" action="/f/${escapeHtml(item.feedback_token)}"><button name="label" value="calendar">处理日历变更</button></form>
      </div></section>`;
  }).join("");
  return html(`<h1>邮件简报</h1><p>共 ${(result.results || []).length} 封。可直接打开 Apple Mail 原邮件、反馈分类；点击“处理日历变更”即确认新增、取消或改期。</p>${items}
    <div class="privacy">链接有效期为 7 天；点击复制到 AI 后会临时缓存可复制正文七天。</div>`);
}

async function submitFeedback(request, env, token) {
  const form = await request.formData();
  if(form.get('format')==='2'){
    const category=String(form.get('mail_category')||''),importance=String(form.get('importance')||''),note=String(form.get('note')||'').trim();
    if(!feedbackCategories.includes(category)||!Object.hasOwn(feedbackImportance,importance)||note.length>500)return html('<h1>反馈无效</h1><p>请选择类别和重要程度，补充说明不超过 500 字。</p>',400);
    await ensureFeedbackFields(env);
    const row=await env.DB.prepare('SELECT created_at,expires_at FROM feedback_links WHERE token=?1').bind(token).first();
    if(!row||!feedbackActionActive(row))return html('<h1>无法提交</h1><p>链接不存在或反馈期限已过。</p>',410);
    const now=new Date().toISOString();
    await env.DB.batch([
      env.DB.prepare('INSERT INTO feedback_dimensions(token,mail_category,importance,submitted_at) VALUES(?1,?2,?3,?4) ON CONFLICT(token) DO UPDATE SET mail_category=excluded.mail_category,importance=excluded.importance,submitted_at=excluded.submitted_at').bind(token,category,importance,now),
      env.DB.prepare('UPDATE feedback_links SET label=?1,note=?2,submitted_at=?3,acknowledged_at=NULL WHERE token=?4').bind(compatibilityLabel(category,importance),note,now,token)
    ]);
    return new Response(null,{status:303,headers:{location:'/f/'+token,'cache-control':'no-store'}});
  }
  const label = String(form.get("label") || "");
  const note = String(form.get("note") || "").trim().slice(0, 500);
  if (!LABELS.has(label)) return html("<h1>分类无效</h1><p>请返回后重新选择。</p>", 400);
  const now = new Date().toISOString();
  const actionCutoff = new Date(Date.now() - FEEDBACK_ACTION_DAYS * DAY_MS).toISOString();
  if(label==='calendar'){await ensureCalendar(env);await ensureCalendarOwnership(env);}
  const statement = env.DB.prepare(`UPDATE feedback_links SET label=?1,note=?2,submitted_at=?3,acknowledged_at=NULL
    WHERE token=?4 AND expires_at>?3 AND created_at>?5 ${label==='calendar'?"AND NOT EXISTS(SELECT 1 FROM outlook_calendar_events e WHERE e.message_key=feedback_links.message_key)":''}`).bind(label, note, now, token, actionCutoff);
  const result=label==='calendar'?(await env.DB.batch([statement,env.DB.prepare("INSERT OR IGNORE INTO outlook_calendar_legacy(message_key) SELECT message_key FROM feedback_links WHERE token=?1 AND label='calendar' AND submitted_at=?2").bind(token,now)]))[0]:await statement.run();
  if (!result.meta?.changes) return html("<h1>无法提交</h1><p>链接可能已提交或已经过期。</p>", 409);
  await ensureFeedbackFields(env);
  await env.DB.prepare('DELETE FROM feedback_dimensions WHERE token=?1').bind(token).run();
  const message = label === "calendar"
    ? "已确认处理日历变更；Mac 会在约两分钟内安全匹配并新增、取消或改期。"
    : "反馈已记录；Mac 会在约两分钟内吸收。";
  return html(`<h1>提交成功 ✓</h1><p>${message}</p><div class="actions">
    <a class="action primary" href="/f/${escapeHtml(token)}">返回反馈页面</a></div>`);
}

export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);
    const courseMigrationResponse=await handleCourseMigration(request,env,url,authorized(request,env));
    if(courseMigrationResponse)return courseMigrationResponse;
    const calendarAuth=await handleCalendarAuth(request,env,url,authorized(request,env));
    if(calendarAuth)return calendarAuth;
    const calendarResponse=await handleOutlookCalendar(request,env,url,authorized(request,env));
    if(calendarResponse)return calendarResponse;
    const realtimeResponse=await handleRealtime(request,env,url,authorized(request,env));
    if(realtimeResponse)return realtimeResponse;
    const pipelineResponse=await handlePipeline(request,env,url,authorized(request,env));
    if(pipelineResponse) return pipelineResponse;
    const deliveryResponse=await handleDelivery(request,env,url,authorized(request,env));
    if(deliveryResponse) return deliveryResponse;
    const migrationResponse = await handleCloudMigration(request,env,url,authorized(request,env));
    if(migrationResponse) return migrationResponse;
    const mailToolsResponse = await handleMailTools(request, env, url, authorized(request, env),ctx);
    if (mailToolsResponse) return mailToolsResponse;
    const scheduleResponse = await handleScheduleRoute(request, env, url, authorized(request, env));
    if (scheduleResponse) return scheduleResponse;
    if (url.pathname === "/oauth/google/callback" && request.method === "GET") {
      return handleGoogleCallback(request, env);
    }
    if (url.pathname === "/oauth/microsoft/callback" && request.method === "GET") {
      return handleMicrosoftCallback(request, env);
    }
    const feedbackMatch = url.pathname.match(/^\/f\/([A-Za-z0-9_-]{32})$/);
    if (feedbackMatch && request.method === "GET") return feedbackPage(env, feedbackMatch[1]);
    if (feedbackMatch && request.method === "POST") return submitFeedback(request, env, feedbackMatch[1]);
    const translationMatch = url.pathname.match(/^\/f\/([A-Za-z0-9_-]{32})\/translate$/);
    const translationStatusMatch=url.pathname.match(/^\/f\/([A-Za-z0-9_-]{32})\/translate\/status$/);
    if(translationStatusMatch && request.method==='GET')return translationStatus(env,translationStatusMatch[1]);
    const translationEventsMatch=url.pathname.match(/^\/f\/([A-Za-z0-9_-]{32})\/translate\/events$/);
    if(translationEventsMatch&&request.method==='GET')return translationEvents(env,translationEventsMatch[1]);
    const originalMatch = url.pathname.match(/^\/f\/([A-Za-z0-9_-]{32})\/original$/);
    if (originalMatch && request.method === "GET") return openOriginalMail(env, originalMatch[1]);
    if (translationMatch && request.method === "GET") return viewOrRequestTranslation(env, translationMatch[1]);
    if (translationMatch && request.method === "POST") return requestTranslation(env, translationMatch[1]);
    const digestMatch = url.pathname.match(/^\/d\/([A-Za-z0-9_-]{32})$/);
    if (digestMatch && request.method === "GET") return digestPage(env, digestMatch[1]);

    if (url.pathname.startsWith("/api/")) {
      if (!authorized(request, env)) return json({ error: "unauthorized" }, 401);
      if (url.pathname === "/api/link" && request.method === "POST") return createLink(request, env, url);
      if (url.pathname === "/api/digest" && request.method === "POST") return createDigest(request, env, url);
      if (url.pathname === "/api/pull" && request.method === "GET") return pullFeedback(env, url);
      if (url.pathname === "/api/ack" && request.method === "POST") return acknowledge(request, env);
      if (url.pathname === "/api/translations/pull" && request.method === "GET") return pullTranslations(env, url);
      if (url.pathname === "/api/translations/result" && request.method === "POST") return completeTranslation(request, env);
      if (url.pathname === "/api/oauth/google/start" && request.method === "POST") return startGoogleOAuth(env, url.origin);
      if (url.pathname === "/api/oauth/microsoft/start" && request.method === "POST") return startMicrosoftOAuth(env, url.origin);
      if (url.pathname === "/api/cloud/accounts" && request.method === "GET") return cloudAccountStatus(env);
      if (url.pathname === "/api/cloud/sync" && request.method === "POST") return cloudJson({ results: await syncAllCloudMail(env) });
    }
    if (url.pathname === "/health") return json({ ok: true });
    return html("<h1>邮件助手反馈</h1><p>服务运行正常。</p>", 404);
  },
  async queue(batch,env) {
    const schedules=batch.messages.filter(m=>m.body?.type==='schedule');
    for(const message of schedules){try{await runSchedule(env,message.body.token);message.ack();}catch{message.retry({delaySeconds:60});}}
    const messages=batch.messages.filter(m=>m.body?.type!=='schedule');
    if(messages.length)await consumeRealtime({...batch,messages},env);
  },
  async scheduled(_controller, env, ctx) {
    ctx.waitUntil((async () => {
      try { await cleanupRetention(env); } catch (error) { console.error("retention cleanup failed", error); }
      try { await cleanupMailTools(env); } catch (error) { console.error("mail tools cleanup failed", error); }
      try { await cleanupScheduleRetention(env); } catch (error) { console.error("schedule cleanup failed", error); }
      try { await recoverSchedules(env); } catch { console.error('course queue recovery failed'); }
      // Delivery retry is independent of mailbox provider availability.
      await drainDelivery(env);
      await ensurePipeline(env);
      try { await maintainRealtime(env); } catch { console.error('notification subscription maintenance failed'); }
      await ensureTranslationSchema(env);
      try { await drainCloudActions(env); } catch { console.error('cloud action drain failed'); }
      const pipeline=await env.DB.prepare('SELECT enabled FROM cloud_pipeline_config WHERE id=1').first();
      if(pipeline.enabled) {
        await runCloudPipeline(env);
        await drainDelivery(env);
      } else await syncAllCloudMail(env);
    })());
  },
};
