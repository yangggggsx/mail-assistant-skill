import test from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {handleMailTools,ensureMailTools} from './mail-tools.js';
import {iphoneTodoLaunch} from './iphone-todo.js';
function envDB(){
 const db=new DatabaseSync(':memory:');
 const prepare=sql=>{let args=[];const stmt=()=>db.prepare(sql.replace(/\?(\d+)/g,(_,n)=>`$p${n}`));const params=()=>Object.fromEntries(args.map((v,i)=>[`$p${i+1}`,v]));return {bind(...v){args=v;return this},async run(){return {meta:{changes:Number(stmt().run(params()).changes)}}},async first(){return stmt().get(params())||null},async all(){return {results:stmt().all(params())}}};};
 return {API_TOKEN:'test-only',DB:{prepare,batch:qs=>Promise.all(qs.map(q=>q.run()))}};
}
test('direct test is admin-only, idempotent and uses a signed shortcut URL without claiming',async()=>{
 const env=envDB(),url=new URL('https://example.test/api/mail-tools/iphone-direct-test');
 const body={confirm:true,test_id:'iphone-direct-20261023-test'};
 const call=auth=>handleMailTools(new Request(url,{method:'POST',body:JSON.stringify(body)}),env,url,auth);
 assert.equal((await call(false)).status,401);
 await env.DB.prepare('CREATE TABLE feedback_links(token TEXT,message_key TEXT,expires_at TEXT)').run();
 await env.DB.prepare('CREATE TABLE cloud_messages(message_key TEXT,subject TEXT,feedback_token TEXT,created_at TEXT)').run();
 await env.DB.prepare('INSERT INTO feedback_links VALUES(?1,?2,?3)').bind('A'.repeat(32),'b'.repeat(64),'2099-01-01').run();
 await env.DB.prepare('INSERT INTO cloud_messages VALUES(?1,?2,?3,?4)').bind('b'.repeat(64),'Test','A'.repeat(32),'2026-10-22').run();
 assert.equal((await call(true)).status,200);
 const row=await env.DB.prepare('SELECT payload_json FROM delivery_queue').first();
 const payload=JSON.parse(row.payload_json),launch=new URL(payload.url);
 assert.equal(launch.protocol,'shortcuts:');assert.equal(launch.searchParams.get('name'),'邮件助手-加入待办');
 const claim=new URL(launch.searchParams.get('text'));
 assert.equal(claim.origin,url.origin);assert.match(claim.searchParams.get('proof'),/^[a-f0-9]{64}$/);
 assert.equal(await env.DB.prepare('SELECT * FROM mail_tools').first(),null);
 assert.equal((await (await call(true)).json()).duplicate,true);
 assert.equal((await env.DB.prepare('SELECT COUNT(*) AS n FROM delivery_queue').first()).n,1);
});
test('iPhone task is exclusive, signed, and receipt is idempotent without success push',async()=>{
 const env=envDB(),token='A'.repeat(32),key='b'.repeat(64);
 await ensureMailTools(env);
 await env.DB.prepare('CREATE TABLE feedback_links(token TEXT,message_key TEXT,expires_at TEXT)').run();
 await env.DB.prepare('CREATE TABLE cloud_messages(message_key TEXT,subject TEXT,classification_json TEXT)').run();
 await env.DB.prepare('INSERT INTO feedback_links VALUES(?1,?2,?3)').bind(token,key,'2099-01-01').run();
 await env.DB.prepare('INSERT INTO cloud_messages VALUES(?1,?2,?3)').bind(key,'Test','{"summary":"Summary"}').run();
 const call=(url,body)=>handleMailTools(new Request(url,body===undefined?{}:{method:'POST',body:JSON.stringify(body)}),env,new URL(url),false);
 const defaultUrl=`https://example.test/f/${token}/todo`;
 const statusUrl=`https://example.test/f/${token}/iphone-todo/status`;
 assert.deepEqual(await(await call(statusUrl)).json(),{status:'not_started'});
 assert.equal((await call(statusUrl,{})).status,405);
 for(const body of [undefined,{}]) {
   const redirect=await call(defaultUrl,body);
   assert.equal(redirect.status,303);
   assert.equal(redirect.headers.get('location'),`/f/${token}/iphone-todo`);
 }
 const page=await(await call(`https://example.test/f/${token}/iphone-todo`)).text();
 assert.equal(await env.DB.prepare('SELECT * FROM mail_tools').first(),null);
 const launch=new URL(page.match(/href="([^"]+)"/)[1].replaceAll('&amp;','&'));
 const claimUrl=launch.searchParams.get('text');
 assert.equal((await call(claimUrl+'&proof=bad')).status,405); // GET never mutates
 const bad=new URL(claimUrl);bad.searchParams.set('proof','bad');
 assert.equal((await call(bad,{})).status,403);
 const r=await call(claimUrl,{});assert.equal(r.status,200);const payload=await r.json();
 assert.deepEqual(await(await call(statusUrl)).json(),{status:'iphone_claimed'});
 assert.equal(payload.list,'邮件待办');assert.match(payload.notes,/MailAssistant:/);
 assert.equal(payload.format,1);
 assert.equal((await call(claimUrl,{})).status,409);
 assert.equal((await env.DB.prepare("SELECT * FROM mail_tools WHERE status='pending'").first()),null);
 assert.equal((await call(payload.receipt_url,{claim:'wrong',status:'completed'})).status,409);
 for(let i=0;i<2;i++)assert.equal((await call(payload.receipt_url,{claim:payload.claim,status:'completed'})).status,200);
 assert.deepEqual(await(await call(statusUrl)).json(),{status:'completed'});
 assert.equal(await env.DB.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='delivery_queue'").first(),null);
 assert.equal((await call(claimUrl,{})).status,409);
 const ownedPage=await(await call(`https://example.test/f/${token}/iphone-todo`)).text();
 assert.doesNotMatch(ownedPage,/id="launch"/);
});

test('default todo preserves existing Mac ownership and completed result',async()=>{
 const env=envDB(),token='A'.repeat(32),key='b'.repeat(64);
 await ensureMailTools(env);
 await env.DB.prepare('CREATE TABLE feedback_links(token TEXT,message_key TEXT,expires_at TEXT)').run();
 await env.DB.prepare('CREATE TABLE cloud_messages(message_key TEXT)').run();
 await env.DB.prepare('INSERT INTO feedback_links VALUES(?1,?2,?3)').bind(token,key,'2099-01-01').run();
 await env.DB.prepare('INSERT INTO cloud_messages VALUES(?1)').bind(key).run();
 await env.DB.prepare("INSERT INTO mail_tools(message_key,kind,token,status,requested_at) VALUES(?1,'todo',?2,'pending','2026-10-22')").bind(key,token).run();
 const url=new URL(`https://example.test/f/${token}/todo`);
 for(const status of ['pending','completed']) {
   await env.DB.prepare('UPDATE mail_tools SET status=?1').bind(status).run();
   const response=await handleMailTools(new Request(url),env,url,false);
   assert.equal(response.status,200);
   assert.match(await response.text(),status==='pending'?/等待 Mac 处理/:/已加入「邮件待办」/);
 }
 await env.DB.prepare("UPDATE mail_tools SET status='iphone_claimed'").run();
 assert.equal((await handleMailTools(new Request(url),env,url,false)).status,303);
 await env.DB.prepare('DELETE FROM mail_tools').run();
 await env.DB.prepare('DELETE FROM cloud_messages').run();
 assert.equal((await handleMailTools(new Request(url),env,url,false)).status,200);
 assert.equal(await env.DB.prepare('SELECT * FROM mail_tools').first(),null);
});

test('durable direct v2 link rejects tampering, issues short receipt, stays exclusive and respects expiry',async()=>{
 const env=envDB(),token='C'.repeat(32),key='d'.repeat(64);
 await ensureMailTools(env);
 await env.DB.prepare('CREATE TABLE feedback_links(token TEXT,message_key TEXT,expires_at TEXT)').run();
 await env.DB.prepare('CREATE TABLE cloud_messages(message_key TEXT,subject TEXT,classification_json TEXT)').run();
 await env.DB.prepare('INSERT INTO feedback_links VALUES(?1,?2,?3)').bind(token,key,'2099-01-01').run();
 await env.DB.prepare('INSERT INTO cloud_messages VALUES(?1,?2,?3)').bind(key,'Package ready',JSON.stringify({todo:{title:'去取快递',notes:'取件地点：前台。'}})).run();
 const call=(url,body)=>handleMailTools(new Request(url,body===undefined?{}:{method:'POST',body:JSON.stringify(body)}),env,new URL(url),false);
 const claimUrl=new URL(await iphoneTodoLaunch(env,'https://example.test',token,true)).searchParams.get('text');
 assert.equal(new URL(claimUrl).searchParams.has('expires'),false);
 const bad=new URL(claimUrl);bad.searchParams.set('proof','bad');
 assert.equal((await call(bad,{format:2})).status,403);
 assert.equal((await call(claimUrl)).status,405);
 assert.equal((await call(claimUrl,{format:'2'})).status,400);
 assert.equal(await env.DB.prepare('SELECT * FROM mail_tools').first(),null);
 const payload=await(await call(claimUrl,{format:2})).json();
 assert.ok(Number(new URL(payload.receipt_url).searchParams.get('expires'))<=Math.floor(Date.now()/1000)+1800);
 assert.equal(payload.format,2);assert.equal(payload.title,'去取快递');assert.equal(payload.notes,'取件地点：前台。');
 assert.ok(payload.url.includes(payload.marker));assert.doesNotMatch(payload.notes,/MailAssistant|https/);
 assert.equal((await call(claimUrl,{format:2})).status,409);
 assert.equal((await call(payload.receipt_url,{claim:payload.claim,status:'completed'})).status,200);
 await env.DB.prepare("UPDATE feedback_links SET expires_at='2000-01-01'").run();
 assert.equal((await call(claimUrl,{format:2})).status,410);
});
