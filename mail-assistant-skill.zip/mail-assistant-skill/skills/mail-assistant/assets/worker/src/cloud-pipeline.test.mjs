import test from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync} from 'node:fs';
import {ensurePipeline,processObservation,runCloudPipeline,handlePipeline,notification,verificationOnly,queueCloudDigest,collectLocalDigest} from './cloud-pipeline.js';
function environment() {
  const db=new DatabaseSync(':memory:');db.exec(readFileSync(new URL('../schema.sql',import.meta.url),'utf8'));
  const prepare=sql=>{
    let args=[];const normalized=sql.replace(/\?(\d+)/g,(_,n)=>`$p${n}`);
    const params=()=>Object.fromEntries(args.map((v,i)=>[`$p${i+1}`,v]));
    return {bind(...v){args=v;return this;},async run(){return {meta:{changes:Number(db.prepare(normalized).run(params()).changes)}};},async first(){return db.prepare(normalized).get(params())||null;},async all(){return {results:db.prepare(normalized).all(params())};}};
  };
  return {DB:{prepare,batch:async qs=>{db.exec('BEGIN');try{const r=await Promise.all(qs.map(q=>q.run()));db.exec('COMMIT');return r;}catch(e){db.exec('ROLLBACK');throw e;}}}};
}
const mail={message_key:'a'.repeat(64),message_id:'<test@example.com>',account_email:'test@example.com',sender:'sender',subject:'test',received_at:new Date().toISOString(),body:'正文',original_url:'https://outlook.live.com/mail/test',matched_legacy:false};
const classification={category:'normal',importance:'normal',mail_type:'other',action_required:false,delivery_recommendation:'confirm',confidence:.9,summary:'摘要',reason:'普通',suggested_action:'查看',calendar:{candidate:false,events:[]}};
test('saved classification survives retry without another model call or duplicate delivery',async()=>{
  const env=environment();env.API_TOKEN='test-only';await ensurePipeline(env);let calls=0;
  const deps={reader:async()=>mail,classifier:async()=>{calls++;return {classification,usage:{}};}};
  await processObservation(env,{id:1},deps);await processObservation(env,{id:1},deps);
  assert.equal(calls,1);assert.equal((await env.DB.prepare('SELECT count(*) AS n FROM delivery_queue').first()).n,1);
  const payload=JSON.parse((await env.DB.prepare('SELECT payload_json FROM delivery_queue').first()).payload_json);
  assert.equal(payload.url,undefined);
  assert.equal(payload.url_title,undefined);
  assert.match(payload.message,/加入待办/);
  assert.doesNotMatch(payload.message,/待办（网页备用）/);
  assert.ok(payload.message.length<=1024);
  assert.equal((await env.DB.prepare('SELECT count(*) AS n FROM feedback_links').first()).n,1);
});
test('historical hashes never classify or enqueue',async()=>{
  const env=environment();await ensurePipeline(env);
  assert.equal(await processObservation(env,{id:1},{reader:async()=>({...mail,matched_legacy:true}),classifier:()=>{throw Error('must not call');}}),'duplicate');
  assert.equal((await env.DB.prepare('SELECT count(*) AS n FROM cloud_messages').first()).n,0);
});
test('OTP is silent but security anomaly must still be analyzed',async()=>{
  assert.equal(verificationOnly({subject:'Your verification code',body:'123456'}),true);
  assert.equal(verificationOnly({subject:'Your verification code',body:'We detected suspicious login activity'}),false);
  assert.equal(verificationOnly({subject:'Sale',body:'Save with code 123456'}),false);
  const env=environment();await ensurePipeline(env);
  assert.equal(await processObservation(env,{id:1},{reader:async()=>({...mail,subject:'验证码 123456'}),classifier:()=>{throw Error('not expected');}}),'suppressed');
  assert.equal((await env.DB.prepare('SELECT count(*) AS n FROM delivery_queue').first()).n,0);
});
test('payload escapes HTML and keeps all action links within provider limit',()=>{
  const p=notification({...mail,sender:'<script>',subject:'s'}, {...classification,summary:'&'.repeat(3000)},'t'.repeat(32));
  assert.ok(p.message.length<=1024);assert.ok(p.message.includes('/todo'));assert.ok(p.message.includes('&lt;script&gt;'));assert.ok(!p.message.includes('<script>'));
});
test('category leads title; only important and urgent show badges; routing stays unchanged',()=>{
  for(const importance of ['normal','low','important','urgent']){
    const p=notification(mail,{...classification,importance,mail_type:'shipping',notification:{label:'快递物流',title:'包裹已到取件点',lead:'请到前台领取包裹。',details:['取件码：123456'],source:'UPS'}},'t'.repeat(32));
    assert.equal(p.title,`【快递物流${importance==='important'?'｜重要':importance==='urgent'?'｜紧急':''}】包裹已到取件点`);
    assert.match(p.message,/<b>请到前台领取包裹。<\/b>\n取件码：123456\n来源：UPS/);
    assert.doesNotMatch(p.message,/test@example|邮箱：|需要处理：|摘要：|建议：/);
    assert.equal(p.priority,0); // Display importance must not change legacy delivery priority.
  }
});
test('long formatted notification retains balanced markup and every existing action',()=>{
  const p=notification(mail,{...classification,notification:{label:'退款售后',title:'退款已发起',lead:'<&😀'.repeat(300),details:['&'.repeat(100),'背景'.repeat(100)],source:'<商家>'}},'t'.repeat(32),'shortcuts://run-shortcut');
  assert.ok(p.message.length<=1024);
  assert.match(p.message,/^<b>.*<\/b>\n/s);
  assert.doesNotMatch(p.message,/<商家>/);
  for(const path of ['/original','/translate','/copy','/todo'])assert.ok(p.message.includes(path));
  assert.equal(p.url,undefined);
  assert.equal(p.url_title,undefined);
});
test('legacy classification uses summary without speculative suggested action or mailbox address',()=>{
  const p=notification({...mail,sender:'no-reply@walmart.com'},{...classification,mail_type:'transaction',summary:'退款已发起，尚未确认到账。',suggested_action:'立即检查账户'},'t'.repeat(32));
  assert.match(p.title,/^【订单交易】/);
  assert.match(p.message,/来源：walmart.com/);
  assert.doesNotMatch(p.message,/立即检查账户|no-reply@/);
});
test('disabled pipeline does not touch providers; enabled pipeline uses cutover and persists retries',async()=>{
  const env=environment();await ensurePipeline(env);let synced=0;
  const sync=async()=>{synced++;return [];};
  assert.equal((await runCloudPipeline(env,{sync})).skipped,true);assert.equal(synced,0);
  await env.DB.prepare("UPDATE cloud_pipeline_config SET enabled=1,cutover='2026-01-01' WHERE id=1").run();
  for(const [id,date] of [[1,'2025-01-01'],[2,new Date().toISOString()]]) await env.DB.prepare(`INSERT INTO cloud_mail_observations(id,provider,account_email,external_message_id,received_at,first_observed_at,source) VALUES(?1,'google','a',?2,?3,?3,'test')`).bind(id,String(id),date).run();
  await runCloudPipeline(env,{sync,reader:async()=>{throw Error('provider error with secret');}});
  const rows=(await env.DB.prepare('SELECT * FROM cloud_processing').all()).results;
  assert.equal(rows.length,1);assert.equal(rows[0].observation_id,2);assert.equal(rows[0].status,'retry');assert.equal(rows[0].attempts,1);assert.ok(!rows[0].error_code.includes('secret'));
});
test('parallel workers cannot both own pipeline lease',async()=>{
  const env=environment();await ensurePipeline(env);
  await env.DB.prepare("UPDATE cloud_pipeline_config SET enabled=1,cutover='2026-01-01',lease_until='2999-01-01',lease_token='other' WHERE id=1").run();
  assert.equal((await runCloudPipeline(env,{sync:()=>{throw Error('not called');}})).skipped,true);
});
test('digest queue is idempotent and keeps links',async()=>{
  const env=environment();await ensurePipeline(env);
  await processObservation(env,{id:1},{reader:async()=>mail,classifier:async()=>({classification:{...classification,category:'newsletter'},usage:{}})});
  const morning=new Date('2026-10-22T13:10:00Z');await queueCloudDigest(env,morning);await queueCloudDigest(env,morning);
  assert.equal((await env.DB.prepare('SELECT count(*) AS n FROM delivery_queue').first()).n,1);
  assert.equal((await env.DB.prepare('SELECT count(*) AS n FROM digest_items').first()).n,1);
});
test('pipeline endpoints require authentication',async()=>{
  const u=new URL('https://example.com/api/cloud/pipeline/messages');
  assert.equal((await handlePipeline(new Request(u),{},u,false)).status,401);
});
test('unified digest merges sources, deduplicates and defers late arrivals',async()=>{
  const env=environment();await ensurePipeline(env);
  await processObservation(env,{id:1},{reader:async()=>mail,classifier:async()=>({classification:{...classification,category:'newsletter'},usage:{}})});
  const item={messageKey:'b'.repeat(64),subject:'local',sender:'sender',category:'spam',summary:'review',mailUrl:'message://test'};
  await collectLocalDigest(env,[item,item,{...item,messageKey:mail.message_key}]);
  await queueCloudDigest(env,new Date('2026-10-22T13:00:00Z'));
  assert.equal((await env.DB.prepare('SELECT count(*) n FROM delivery_queue').first()).n,0);
  await queueCloudDigest(env,new Date('2026-10-22T13:10:00Z'));
  assert.equal((await env.DB.prepare('SELECT count(*) n FROM digest_items').first()).n,2);
  await collectLocalDigest(env,[{...item,messageKey:'c'.repeat(64)}]);
  await queueCloudDigest(env,new Date('2026-10-22T13:20:00Z'));
  assert.equal((await env.DB.prepare('SELECT count(*) n FROM delivery_queue').first()).n,1);
  await queueCloudDigest(env,new Date('2026-10-22T21:10:00Z'));
  assert.equal((await env.DB.prepare('SELECT count(*) n FROM delivery_queue').first()).n,2);
});
